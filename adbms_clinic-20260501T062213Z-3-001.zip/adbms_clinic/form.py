import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, request, render_template_string
from clinic_db import save_form_data

app = Flask(__name__)

HTML_FORM = """
<!DOCTYPE html>
<html>
<head>
    <title>Medical Form</title>
</head>
<body>

<h2>Medical Form</h2>

{% if error %}
<p style="color:red;">{{ error }}</p>
{% endif %}

<form method="POST" action="/submit">

<h3>Student Info</h3>
Email: <br>
<input type="email" name="email" required><br><br>

SR-Code: <br>
<input type="text" name="sr_code" required><br><br>

Control No: <br>
<input type="text" name="control_no" required><br><br>

<h3>Purpose</h3>
<input type="radio" name="purpose" value="OJT Medical" required> OJT Medical <br>
<input type="radio" name="purpose" value="Pre-employment"> Pre-employment <br>
<input type="radio" name="purpose" value="APE"> Annual Physical Exam <br>
<input type="radio" name="purpose" value="Sports"> Sports <br>

<br>

<h3>Basic Info</h3>
Last Name: <br>
<input type="text" name="last_name" required><br><br>

First Name: <br>
<input type="text" name="first_name" required><br><br>

Middle Name: <br>
<input type="text" name="middle_name"><br><br>

Age: <br>
<input type="number" name="age" required><br><br>

Sex: <br>
<select name="sex" required>
    <option value="">Select</option>
    <option>Male</option>
    <option>Female</option>
</select><br><br>

Civil Status: <br>
<select name="civil_status" required>
    <option value="">Select</option>
    <option>Single</option>
    <option>Married</option>
</select><br><br>

Address: <br>
<input type="text" name="address"><br><br>

Height (cm): <br>
<input type="number" name="height_cm"><br><br>

Weight (kg): <br>
<input type="number" name="weight_kg"><br><br>

<input type="submit" value="Submit">

</form>

</body>
</html>
"""

SUCCESS_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <title>Success</title>
</head>
<body>

<h2>Form Submitted</h2>

<p>Success! Your medical form has been received.</p>
<p>Please proceed to the clinic window.</p>

</body>
</html>
"""


@app.route('/form')
def show_form():
    return render_template_string(HTML_FORM, error=None)


@app.route('/submit', methods=['POST'])
def submit_form():
    data = {
        'control_no':   request.form.get('control_no'),
        'email':        request.form.get('email'),
        'sr_code':      request.form.get('sr_code'),
        'purpose':      request.form.get('purpose'),
        'last_name':    request.form.get('last_name'),
        'first_name':   request.form.get('first_name'),
        'middle_name':  request.form.get('middle_name'),
        'age':          request.form.get('age'),
        'sex':          request.form.get('sex'),
        'civil_status': request.form.get('civil_status'),
        'address':      request.form.get('address'),
        'height_cm':    request.form.get('height_cm') or None,
        'weight_kg':    request.form.get('weight_kg') or None,
    }

    try:
        save_form_data(data)
        return SUCCESS_PAGE
    except Exception as e:
        return render_template_string(HTML_FORM, error=f"Submission failed: {str(e)}")


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)