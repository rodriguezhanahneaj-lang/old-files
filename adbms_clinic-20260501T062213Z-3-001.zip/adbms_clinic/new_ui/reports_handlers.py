# reports_handlers.py
import tkinter as tk
from tkinter import ttk, messagebox
from tkinter.scrolledtext import ScrolledText
from datetime import datetime
from collections import defaultdict
from utils import show_centered_popup

def show_reports(self):
    """Display reports"""
    self.clear_content_area()
    
    tk.Label(self.content_area, text="Reports & Analytics", 
            font=('Arial', 18, 'bold'), bg='white', 
            fg=self.batstateu_colors['primary']).pack(pady=20)
    
    notebook = ttk.Notebook(self.content_area)
    notebook.pack(expand=True, fill='both', padx=20, pady=10)
    
    patient_report_tab = tk.Frame(notebook, bg='white')
    notebook.add(patient_report_tab, text="Patient Reports")
    self.create_patient_reports_tab(patient_report_tab)
    
    inventory_report_tab = tk.Frame(notebook, bg='white')
    notebook.add(inventory_report_tab, text="Inventory Reports")
    self.create_inventory_reports_tab(inventory_report_tab)
    
    medical_report_tab = tk.Frame(notebook, bg='white')
    notebook.add(medical_report_tab, text="Medical Records Report")
    self.create_medical_reports_tab(medical_report_tab)

def create_patient_reports_tab(self, parent):
    """Create patient reports tab"""
    report_frame = tk.Frame(parent, bg='white')
    report_frame.pack(fill='both', expand=True, padx=20, pady=20)
    
    stats_frame = tk.Frame(report_frame, bg='white')
    stats_frame.pack(fill='x', pady=10)
    
    today_visits = len([s for s in self.patients if s['timestamp'].startswith(datetime.now().strftime('%Y-%m-%d'))])
    pending = len([r for r in self.medical_records if r['status'] == 'Pending'])
    completed = len([r for r in self.medical_records if r['status'] == 'Completed'])
    
    stats = [
        ("Today's Visits", today_visits, self.batstateu_colors['info']),
        ("Pending Cases", pending, self.batstateu_colors['warning']),
        ("Completed Cases", completed, self.batstateu_colors['success']),
    ]
    
    for i, (label, value, color) in enumerate(stats):
        card = tk.Frame(stats_frame, bg=color, width=180, height=100, relief='raised', borderwidth=1)
        card.grid(row=0, column=i, padx=10, pady=10)
        card.pack_propagate(False)
        
        tk.Label(card, text=label, font=('Arial', 11), bg=color, fg='white').pack(pady=10)
        tk.Label(card, text=str(value), font=('Arial', 24, 'bold'), bg=color, fg='white').pack()
    
    def generate_daily_report():
        report_text = f"""
        ========== DAILY PATIENT REPORT ==========
        Date: {datetime.now().strftime('%Y-%m-%d')}
        
        Total Check-ins Today: {today_visits}
        Pending Medical Forms: {pending}
        Completed Consultations: {completed}
        
        Patient List:
        """
        for patient in self.patients:
            if patient['timestamp'].startswith(datetime.now().strftime('%Y-%m-%d')):
                report_text += f"\n  - {patient['name']} ({patient['sr_code']}) - {patient['status']}"
        
        report_window = show_centered_popup(parent, "Daily Report", 500, 400)
        text_area = ScrolledText(report_window, wrap=tk.WORD, width=60, height=20)
        text_area.pack(padx=10, pady=10, fill='both', expand=True)
        text_area.insert('1.0', report_text)
        text_area.configure(state='disabled')
    
    tk.Button(report_frame, text="📊 Generate Daily Report", 
             command=generate_daily_report,
             bg=self.batstateu_colors['primary'], fg='white',
             font=('Arial', 12, 'bold'), padx=20, pady=10).pack(pady=20)

def create_inventory_reports_tab(self, parent):
    """Create inventory reports tab"""
    report_frame = tk.Frame(parent, bg='white')
    report_frame.pack(fill='both', expand=True, padx=20, pady=20)
    
    low_stock_frame = tk.LabelFrame(report_frame, text="LOW STOCK ITEMS (Below 50 units)", 
                                    font=('Arial', 12, 'bold'), bg='white', fg='red')
    low_stock_frame.pack(fill='x', pady=10)
    
    low_stock_items = [item for item in self.inventory_items if not item.get('deleted', False) and item['quantity'] < 50]
    
    if low_stock_items:
        for item in low_stock_items:
            item_frame = tk.Frame(low_stock_frame, bg='#ffeeee')
            item_frame.pack(fill='x', padx=10, pady=5)
            
            tk.Label(item_frame, text=f"⚠️ {item['name']}", font=('Arial', 10, 'bold'), 
                    bg='#ffeeee', fg='red').pack(side='left', padx=10)
            tk.Label(item_frame, text=f"Quantity: {item['quantity']} {item['unit']}", 
                    font=('Arial', 10), bg='#ffeeee').pack(side='left', padx=20)
            tk.Label(item_frame, text=f"Expiry: {item['expiry_date']}", 
                    font=('Arial', 10), bg='#ffeeee').pack(side='left', padx=20)
    else:
        tk.Label(low_stock_frame, text="No low stock items", 
                font=('Arial', 11), bg='white', fg='green').pack(pady=20)
    
    inventory_summary_frame = tk.LabelFrame(report_frame, text="Inventory Summary", 
                                            font=('Arial', 12, 'bold'), bg='white')
    inventory_summary_frame.pack(fill='x', pady=10)
    
    total_items = len([i for i in self.inventory_items if not i.get('deleted', False)])
    total_quantity = sum(i['quantity'] for i in self.inventory_items if not i.get('deleted', False))
    total_value = sum(i['quantity'] * i.get('price', 0) for i in self.inventory_items if not i.get('deleted', False))
    
    summary_text = f"""
    Total Items in Inventory: {total_items}
    Total Units in Stock: {total_quantity}
    Total Inventory Value: ₱{total_value:.2f}
    Items Expiring Within 6 Months: {len([i for i in self.inventory_items if i['expiry_date'] != 'N/A' and not i.get('deleted', False)])}
    """
    
    tk.Label(inventory_summary_frame, text=summary_text, font=('Arial', 11), 
            bg='white', justify='left').pack(anchor='w', padx=10, pady=10)
    
    def generate_inventory_report():
        report_text = f"""
        ========== INVENTORY REPORT ==========
        Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        Generated by: {self.current_user}
        
        --- LOW STOCK ITEMS ---
        """
        for item in low_stock_items:
            report_text += f"\n  - {item['name']}: {item['quantity']} {item['unit']} (Expires: {item['expiry_date']})"
        
        report_text += "\n\n--- ALL ITEMS ---"
        for item in self.inventory_items:
            if not item.get('deleted', False):
                price = item.get('price', 0)
                report_text += f"\n  - {item['name']}: {item['quantity']} {item['unit']} | Price: ₱{price:.2f} | Status: {item['status']}"
        
        report_text += "\n\n--- TRANSACTION HISTORY SUMMARY ---"
        report_text += f"\nTotal Transactions: {len(self.inventory_history)}"
        
        action_counts = defaultdict(int)
        for record in self.inventory_history:
            action_counts[record['action']] += 1
        
        for action, count in action_counts.items():
            report_text += f"\n  - {action}: {count}"
        
        report_window = show_centered_popup(parent, "Inventory Report", 600, 500)
        text_area = ScrolledText(report_window, wrap=tk.WORD, width=70, height=25)
        text_area.pack(padx=10, pady=10, fill='both', expand=True)
        text_area.insert('1.0', report_text)
        text_area.configure(state='disabled')
    
    tk.Button(report_frame, text="📊 Generate Full Inventory Report", 
             command=generate_inventory_report,
             bg=self.batstateu_colors['info'], fg='white',
             font=('Arial', 11, 'bold'), padx=15, pady=8).pack(pady=10)

def create_medical_reports_tab(self, parent):
    """Create medical records report tab"""
    report_frame = tk.Frame(parent, bg='white')
    report_frame.pack(fill='both', expand=True, padx=20, pady=20)
    
    range_frame = tk.Frame(report_frame, bg='white')
    range_frame.pack(fill='x', pady=10)
    
    tk.Label(range_frame, text="Date Range (YYYY-MM-DD):", font=('Arial', 11), bg='white').pack(side='left', padx=5)
    
    from_entry = tk.Entry(range_frame, width=12, font=('Arial', 11))
    from_entry.pack(side='left', padx=5)
    from_entry.insert(0, datetime.now().strftime('%Y-%m-01'))
    
    tk.Label(range_frame, text="to", font=('Arial', 11), bg='white').pack(side='left', padx=5)
    
    to_entry = tk.Entry(range_frame, width=12, font=('Arial', 11))
    to_entry.pack(side='left', padx=5)
    to_entry.insert(0, datetime.now().strftime('%Y-%m-%d'))
    
    stats_frame = tk.Frame(report_frame, bg='white')
    stats_frame.pack(fill='x', pady=20)
    
    total_records = len(self.medical_records)
    pending = len([r for r in self.medical_records if r['status'] == 'Pending'])
    in_progress = len([r for r in self.medical_records if r['status'] == 'In Progress'])
    completed = len([r for r in self.medical_records if r['status'] == 'Completed'])
    
    stats = [
        ("Total Records", total_records, self.batstateu_colors['primary']),
        ("Pending", pending, self.batstateu_colors['warning']),
        ("In Progress", in_progress, self.batstateu_colors['info']),
        ("Completed", completed, self.batstateu_colors['success']),
    ]
    
    stats_inner = tk.Frame(stats_frame, bg='white')
    stats_inner.pack()
    
    for i, (label, value, color) in enumerate(stats):
        card = tk.Frame(stats_inner, bg=color, width=130, height=80, relief='raised', borderwidth=1)
        card.grid(row=0, column=i, padx=5, pady=5)
        card.pack_propagate(False)
        
        tk.Label(card, text=label, font=('Arial', 10), bg=color, fg='white').pack(pady=5)
        tk.Label(card, text=str(value), font=('Arial', 18, 'bold'), bg=color, fg='white').pack()
    
    def generate_medical_report():
        from_dt = from_entry.get()
        to_dt = to_entry.get()
        
        filtered_records = [r for r in self.medical_records 
                           if from_dt <= r['submission_date'][:10] <= to_dt]
        
        report_text = f"""
        ========== MEDICAL RECORDS REPORT ==========
        Date Range: {from_dt} to {to_dt}
        Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        
        --- SUMMARY ---
        Total Medical Records: {len(filtered_records)}
        Pending: {len([r for r in filtered_records if r['status'] == 'Pending'])}
        In Progress: {len([r for r in filtered_records if r['status'] == 'In Progress'])}
        Completed: {len([r for r in filtered_records if r['status'] == 'Completed'])}
        
        --- COMMON SYMPTOMS ---
        """
        
        symptom_count = {}
        for record in filtered_records:
            for symptom in record['symptoms']:
                symptom_count[symptom] = symptom_count.get(symptom, 0) + 1
        
        for symptom, count in sorted(symptom_count.items(), key=lambda x: x[1], reverse=True)[:5]:
            report_text += f"\n  - {symptom}: {count} cases"
        
        report_text += "\n\n--- RECORDS LIST ---"
        for record in filtered_records:
            report_text += f"\n  - {record['submission_date'][:10]} | {record['patient_name']} | {record['status']}"
        
        report_window = show_centered_popup(parent, "Medical Records Report", 600, 500)
        text_area = ScrolledText(report_window, wrap=tk.WORD, width=70, height=25)
        text_area.pack(padx=10, pady=10, fill='both', expand=True)
        text_area.insert('1.0', report_text)
        text_area.configure(state='disabled')
    
    tk.Button(report_frame, text="📊 Generate Medical Records Report", 
             command=generate_medical_report,
             bg=self.batstateu_colors['success'], fg='white',
             font=('Arial', 12, 'bold'), padx=20, pady=10).pack(pady=20)