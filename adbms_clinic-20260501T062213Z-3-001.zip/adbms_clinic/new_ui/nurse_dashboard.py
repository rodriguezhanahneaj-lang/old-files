# nurse_dashboard.py
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from utils import clear_window  # <-- ADD THIS IMPORT
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.patches as mpatches
from matplotlib.ticker import MaxNLocator


# ── Chart color palette ───────────────────────────────────────────────────────
_C = {
    "teal":        "#1D9E75",
    "teal_light":  "#E1F5EE",
    "blue":        "#378ADD",
    "blue_light":  "#E6F1FB",
    "coral":       "#D85A30",
    "coral_light": "#FAECE7",
    "purple":      "#7F77DD",
    "amber":       "#BA7517",
    "amber_light": "#FAEEDA",
    "card_bg":     "#FFFFFF",
    "grid":        "#EBEBEB",
    "text":        "#2C2C2A",
    "muted":       "#888780",
}
_PIE_COLORS = ["#7F77DD", "#AFA9EC", "#1D9E75", "#5DCAA5", "#378ADD", "#85B7EB"]
 
 
# ── Helpers ───────────────────────────────────────────────────────────────────
 
def _canvas_pack(fig, parent):
    """
    Pack matplotlib canvas directly into the LabelFrame.
    No extra border, no extra surrounding box.
    """
    canvas = FigureCanvasTkAgg(fig, master=parent)
    canvas.draw()

    widget = canvas.get_tk_widget()
    widget.configure(
        bg='white',
        highlightthickness=0,
        bd=0
    )
    widget.pack(expand=True, fill='both', padx=10, pady=10)

    return canvas
 
 
def _style_ax(ax, xlabel="", ylabel=""):
    ax.set_facecolor("white")

    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)

    ax.grid(True, linestyle='--', alpha=0.5)

    ax.tick_params(axis='both', labelsize=8)

    for spine in ax.spines.values():
        spine.set_linewidth(0.8)
        spine.set_color("#cccccc")

def _no_chart_data(ax, text="No data available"):
    ax.text(
        0.5,
        0.5,
        text,
        ha="center",
        va="center",
        transform=ax.transAxes,
        fontsize=10,
        color="#777777"
    )
    ax.set_xticks([])
    ax.set_yticks([])
 
 
def _small_header(parent, title, subtitle, accent_color, bg="white"):
    """Thin colored accent bar + bold title + muted subtitle. No heavy box."""
    hdr = tk.Frame(parent, bg=bg)
    hdr.pack(fill="x", padx=8, pady=(6, 0))
    tk.Frame(hdr, bg=accent_color, width=3).pack(side="left", fill="y", padx=(0, 6))
    txt = tk.Frame(hdr, bg=bg)
    txt.pack(side="left")
    tk.Label(txt, text=title, bg=bg,
             fg=_C["text"], font=("Segoe UI", 9, "bold")).pack(anchor="w")
    tk.Label(txt, text=subtitle, bg=bg,
             fg=_C["muted"], font=("Segoe UI", 7)).pack(anchor="w")
 
 
def cancel_dashboard_refresh(self):
    """Safely cancel the active dashboard auto-refresh job, if any."""
    job_id = getattr(self, 'dashboard_refresh_job', None)
    if not job_id:
        return
    try:
        self.root.after_cancel(job_id)
    except ValueError:
        pass
    finally:
        self.dashboard_refresh_job = None
 

def show_nurse_dashboard(self):
    """Display nurse main dashboard"""
    cancel_dashboard_refresh(self)
    self._dashboard_built = False

    clear_window(self.root)
    
    header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=80)
    header_frame.pack(fill='x')
    header_frame.pack_propagate(False)
    
    tk.Label(header_frame, text="NURSE DASHBOARD", 
            font=('Arial', 18, 'bold'), bg=self.batstateu_colors['primary'], 
            fg='white').pack(side='left', padx=20, pady=20)
    
    tk.Label(header_frame, text=f"Welcome, {self.current_user or 'Nurse'}", 
            font=('Arial', 12), bg=self.batstateu_colors['primary'], 
            fg=self.batstateu_colors['secondary']).pack(side='left', padx=50, pady=20)
    
    logout_btn = tk.Button(header_frame, text="Logout", 
                         bg='white', fg=self.batstateu_colors['primary'],
                         font=('Arial', 10), cursor='hand2', command=self.show_role_selection)
    logout_btn.pack(side='right', padx=20, pady=20)
    
    main_container = tk.Frame(self.root, bg=self.batstateu_colors['bg'])
    main_container.pack(expand=True, fill='both')
    
    sidebar = tk.Frame(main_container, bg=self.batstateu_colors['primary'], width=220)
    sidebar.pack(side='left', fill='y')
    sidebar.pack_propagate(False)
    
    menu_items = [
        ("🏠 DASHBOARD", self.show_nurse_dashboard_content),
        ("📋 MEDICAL RECORDS", self.show_combined_medical_records),
        ("📦 INVENTORY", self.show_inventory_home),
        ("📊 REPORTS", self.show_reports),
        ("👨‍🎓 STUDENT RECORDS", self.show_student_records),
    ]
    
    for item, command in menu_items:
        btn = tk.Button(sidebar, text=item, bg=self.batstateu_colors['primary'],
                      fg='white', font=('Arial', 11, 'bold' if 'INVENTORY' in item or 'MEDICAL' in item or 'STUDENT' in item else 'normal'),
                      bd=0, activebackground=self.batstateu_colors['secondary'],
                      activeforeground=self.batstateu_colors['primary'],
                      cursor='hand2', width=20, anchor='w', padx=15, pady=10,
                      command=command)
        btn.pack(pady=5, padx=5)
    
    self.content_area = tk.Frame(main_container, bg='white')
    self.content_area.pack(side='right', expand=True, fill='both', padx=20, pady=20)
    
    self.show_nurse_dashboard_content()

def show_nurse_dashboard_content(self):
    """
    Build the dashboard widgets on the first call.
    On subsequent calls (triggered by the auto-refresh) only update data
    in-place — no widgets are destroyed, so there is zero flicker.
    """
    cancel_dashboard_refresh(self)
 
    # ── First-time build ──────────────────────────────────────────────────────
    dashboard_widgets_exist = (
        getattr(self, '_dashboard_built', False) and
        hasattr(self, '_stat_value_labels') and
        len(self._stat_value_labels) > 0 and
        self._stat_value_labels[0].winfo_exists()
    )
    if not dashboard_widgets_exist:
        self._dashboard_built = True
        self.clear_content_area()          # clean slate when navigating back
 
        # Title
        tk.Label(self.content_area,
                 text="Welcome to the Clinic Management System",
                 font=('Arial', 20, 'bold'), bg='white',
                 fg=self.batstateu_colors['primary']).pack(pady=20)
 
        # ── Stat cards ────────────────────────────────────────────────────────
        stats_frame = tk.Frame(self.content_area, bg='white')
        stats_frame.pack(pady=10)
 
        stat_labels = [
            ("Today's Visits",   self.batstateu_colors['info']),
            ("Waiting Patients", self.batstateu_colors['warning']),
            ("Pending Forms",    self.batstateu_colors['danger']),
            ("Completed",        self.batstateu_colors['success']),
        ]
 
        # Store references so we can update the value labels later
        self._stat_value_labels = []
 
        for i, (label, color) in enumerate(stat_labels):
            card = tk.Frame(stats_frame, bg=color, width=200, height=120,
                            relief='raised', borderwidth=1)
            card.grid(row=0, column=i, padx=10, pady=10)
            card.pack_propagate(False)
            tk.Label(card, text=label, font=('Arial', 12),
                     bg=color, fg='white').pack(pady=10)
            val_lbl = tk.Label(card, text="—", font=('Arial', 28, 'bold'),
                               bg=color, fg='white')
            val_lbl.pack()
            self._stat_value_labels.append(val_lbl)
 
        # Section title
        tk.Label(self.content_area, text="Dashboard Charts",
                 font=('Arial', 16, 'bold'), bg='white',
                 fg=self.batstateu_colors['primary']).pack(pady=(15, 5))
 
        #Charts container
        charts_container = tk.Frame(self.content_area, bg='white')
        charts_container.pack(expand=True, fill='both', padx=20, pady=10)

        # Build charts once and store axes + canvases for live updates
        _build_dashboard_charts(self, charts_container)
 
    # ── Data refresh (runs every time, including first time) ──────────────────
    _refresh_dashboard_data(self)
 
    # Schedule next silent refresh in 10 s
    self.dashboard_refresh_job = self.root.after(10_000, self.show_nurse_dashboard_content)
 
 
def _refresh_dashboard_data(self):
    """Pull fresh data from DB and update dashboard without rebuilding widgets."""

    # Keep connector/backend calls
    stats = self.get_dashboard_stats()

    values = [
        stats["TodayVisits"],
        stats["WaitingPatients"],
        stats["PendingForms"],
        stats["CompletedCases"],
    ]

    for lbl, val in zip(self._stat_value_labels, values):
        try:
            if lbl.winfo_exists():
                lbl.config(text=str(val))
        except tk.TclError:
            pass

    # Keep connector/backend calls
    monthly_visits = self.get_checkin_visits_per_month()
    stock_counts = self.get_stock_counts()
    medical_causes = self.get_common_medical_cause()
    year_level_visits = self.get_year_level_visits()

    # ------------------------------------------------------------
    # 1. Check-in Visits per Month
    # ------------------------------------------------------------
    ax = self._ax1
    ax.cla()

    months = [r["MonthName"] for r in monthly_visits]
    visits = [int(r["TotalVisits"]) for r in monthly_visits]

    _style_ax(ax, xlabel="Month", ylabel="Number of Visits")
    ax.set_title("Monthly Check-in Visits", fontsize=12)

    if visits:
        x = list(range(len(months)))

        ax.plot(
            x,
            visits,
            marker='o',
            linestyle='-',
            color='#1a4d8c',
            linewidth=2
        )

        ax.fill_between(
            x,
            visits,
            alpha=0.2,
            color='#1a4d8c'
        )

        ax.set_xticks(x)
        ax.set_xticklabels(months, rotation=45, ha='right', fontsize=8)
    else:
        _no_chart_data(ax)

    try:
        self._fig1.tight_layout()
    except Exception:
        pass

    self._canvas1.draw_idle()

    # ------------------------------------------------------------
    # 2. Stock Counts
    # ------------------------------------------------------------
    ax = self._ax2
    ax.cla()

    sorted_stock = sorted(
        stock_counts,
        key=lambda x: int(x["StockQuantity"])
    )

    items = [r["ItemName"] for r in sorted_stock]
    stocks = [int(r["StockQuantity"]) for r in sorted_stock]

    _style_ax(ax, xlabel="Item Name", ylabel="No. of Items")
    ax.set_title("Inventory Stock Counts", fontsize=12)

    if stocks:
        bars = ax.bar(
            items,
            stocks,
            color='#2ecc71',
            edgecolor='black'
        )

        offset = max(stocks) * 0.02 if max(stocks) > 0 else 0.2

        for bar, value in zip(bars, stocks):
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + offset,
                str(value),
                ha='center',
                va='bottom',
                fontsize=8
            )

        ax.margins(y=0.15)

        for label in ax.get_xticklabels():
            label.set_rotation(45)
            label.set_ha('right')
            label.set_fontsize(8)
    else:
        _no_chart_data(ax)

    try:
        self._fig2.tight_layout()
    except Exception:
        pass

    self._canvas2.draw_idle()

    # ------------------------------------------------------------
    # 3. Common Medical Causes
    # ------------------------------------------------------------
    ax = self._ax3
    ax.cla()

    causes = [r["MedicalCause"] for r in medical_causes]
    cases = [int(r["TotalCases"]) for r in medical_causes]

    _style_ax(ax, xlabel="Number of Occurrences", ylabel="Symptoms / Diagnosis")
    ax.set_title("Top Medical Complaints", fontsize=12)

    if cases:
        combined = list(zip(causes, cases))
        combined.sort(key=lambda x: x[1], reverse=True)
        combined = combined[:10]

        labels, counts = zip(*combined)

        bars = ax.barh(
            labels,
            counts,
            color='#e74c3c',
            edgecolor='black'
        )

        ax.invert_yaxis()

        offset = max(counts) * 0.02 if max(counts) > 0 else 0.2

        for bar, value in zip(bars, counts):
            ax.text(
                bar.get_width() + offset,
                bar.get_y() + bar.get_height() / 2,
                str(value),
                ha='left',
                va='center',
                fontsize=9
            )

        ax.margins(x=0.15)
    else:
        _no_chart_data(ax)

    try:
        self._fig3.tight_layout()
    except Exception:
        pass

    self._canvas3.draw_idle()

    # ------------------------------------------------------------
    # 4. Year Level Visits
    # ------------------------------------------------------------
    ax = self._ax4
    ax.cla()
    ax.set_facecolor("white")

    year_levels = [r["YearLevel"] for r in year_level_visits]
    year_visits = [int(r["TotalVisits"]) for r in year_level_visits]

    ax.set_title("Visits by Year Level", fontsize=12)

    if year_visits and sum(year_visits) > 0:
        labels = [
            f"{year} (n={count})"
            for year, count in zip(year_levels, year_visits)
        ]

        wedges, texts, autotexts = ax.pie(
            year_visits,
            labels=labels,
            colors=_PIE_COLORS[:len(year_levels)],
            autopct='%1.1f%%',
            startangle=90,
            wedgeprops={
                "edgecolor": "white",
                "linewidth": 1.5
            },
            textprops={
                "fontsize": 8
            }
        )

        for autotext in autotexts:
            autotext.set_color("white")
            autotext.set_fontsize(8)

        ax.axis("equal")
    else:
        _no_chart_data(ax)

    try:
        self._fig4.tight_layout()
    except Exception:
        pass

    self._canvas4.draw_idle()
    
 
def _build_dashboard_charts(self, parent):
    """
    Create dashboard charts once.
    Design updated to match reports_handlers style:
    - simple LabelFrame containers
    - no bulky inner chart card/box
    - no custom small header
    - no divider lines
    - connectors/data refresh logic are untouched
    """

    chart_frame = tk.Frame(parent, bg='white')
    chart_frame.pack(expand=True, fill='both')

    for c in range(2):
        chart_frame.columnconfigure(c, weight=1, uniform="dashboard_chart_cols")

    for r in range(2):
        chart_frame.rowconfigure(r, weight=1, uniform="dashboard_chart_rows")

    # 1. Monthly Check-in Visits
    frame1 = tk.LabelFrame(
        chart_frame,
        text="Monthly Check-in Visits",
        font=('Arial', 12, 'bold'),
        bg='white',
        fg=self.batstateu_colors['primary'],
        padx=5,
        pady=5
    )
    frame1.grid(row=0, column=0, sticky="nsew", padx=(0, 10), pady=(0, 10))

    self._fig1 = Figure(figsize=(6, 3.5), dpi=100)
    self._fig1.patch.set_facecolor('white')
    self._ax1 = self._fig1.add_subplot(111)
    self._canvas1 = _canvas_pack(self._fig1, frame1)

    # 2. Stock Counts
    frame2 = tk.LabelFrame(
        chart_frame,
        text="Stock Counts",
        font=('Arial', 12, 'bold'),
        bg='white',
        fg=self.batstateu_colors['primary'],
        padx=5,
        pady=5
    )
    frame2.grid(row=0, column=1, sticky="nsew", padx=(10, 0), pady=(0, 10))

    self._fig2 = Figure(figsize=(6, 3.5), dpi=100)
    self._fig2.patch.set_facecolor('white')
    self._ax2 = self._fig2.add_subplot(111)
    self._canvas2 = _canvas_pack(self._fig2, frame2)

    # 3. Common Medical Causes
    frame3 = tk.LabelFrame(
        chart_frame,
        text="Most Common Medical Complaints / Symptoms",
        font=('Arial', 12, 'bold'),
        bg='white',
        fg=self.batstateu_colors['primary'],
        padx=5,
        pady=5
    )
    frame3.grid(row=1, column=0, sticky="nsew", padx=(0, 10), pady=(10, 0))

    self._fig3 = Figure(figsize=(6, 3.5), dpi=100)
    self._fig3.patch.set_facecolor('white')
    self._ax3 = self._fig3.add_subplot(111)
    self._canvas3 = _canvas_pack(self._fig3, frame3)

    # 4. Year Level Visits
    frame4 = tk.LabelFrame(
        chart_frame,
        text="Visits by Year Level",
        font=('Arial', 12, 'bold'),
        bg='white',
        fg=self.batstateu_colors['primary'],
        padx=5,
        pady=5
    )
    frame4.grid(row=1, column=1, sticky="nsew", padx=(10, 0), pady=(10, 0))

    self._fig4 = Figure(figsize=(6, 3.5), dpi=100)
    self._fig4.patch.set_facecolor('white')
    self._ax4 = self._fig4.add_subplot(111)
    self._ax4.set_facecolor('white')
    self._canvas4 = _canvas_pack(self._fig4, frame4)
 
   
# Keep create_dashboard_charts as an alias in case it's called elsewhere
def create_dashboard_charts(self, parent):
    _build_dashboard_charts(self, parent)

def clear_content_area(self):
    """Clear the nurse content area"""
    cancel_dashboard_refresh(self)

    if hasattr(self, 'content_area'):
        for widget in self.content_area.winfo_children():
            widget.destroy()
