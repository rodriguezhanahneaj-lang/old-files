import tkinter as tk
from tkinter import ttk, messagebox
import random
import time

def show_centered_popup(parent, title, width, height):
    """Create a centered popup window"""
    popup = tk.Toplevel(parent)
    popup.title(title)
    popup.geometry(f"{width}x{height}")
    popup.configure(bg='white')
    popup.transient(parent)
    popup.grab_set()
    
    popup.update_idletasks()
    x = (popup.winfo_screenwidth() // 2) - (width // 2)
    y = (popup.winfo_screenheight() // 2) - (height // 2)
    popup.geometry(f"{width}x{height}+{x}+{y}")
    return popup

def clear_window(root):
    """Clear all widgets from the given window"""
    for widget in root.winfo_children():
        widget.destroy()