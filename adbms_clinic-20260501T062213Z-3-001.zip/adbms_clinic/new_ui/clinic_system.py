import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import random

# Import all mixins
from patient_checkin import PatientCheckinMixin
from nurse_auth import NurseAuthMixin
from nurse_dashboard import NurseDashboardMixin
from nurse_records import NurseRecordsMixin
from inventory import InventoryMixin
from documents import DocumentMixin
from reports import ReportsMixin


class ClinicManagementSystem(PatientCheckinMixin, NurseAuthMixin,
                             NurseDashboardMixin, NurseRecordsMixin,
                             InventoryMixin, DocumentMixin, ReportsMixin):
    def __init__(self, root):
        self.root = root
        self.root.title("BatStateU Clinic Management System")
        self.root.geometry("1280x720")
        self.root.resizable(True, True)

        # Colors
        self.batstateu_colors = {
            'primary': '#800000',
            'secondary': '#FFD1DC',
            'bg': '#f5f5f5',
            'white': '#ffffff',
            'text': '#333333',
            'success': '#28a745',
            'danger': '#dc3545',
            'warning': '#ffc107',
            'info': '#17a2b8',
            'dark': '#2c3e50'
        }

        # Data stores
        self.current_user = None
        self.current_user_role = None
        self.patients = []
        self.medical_records = []
        self.inventory_items = []
        self.medical_documents = []
        self.nurses = []
        self.student_records = []
        self.cart_items = []
        self.inventory_history = []
        self.cart_history = []
        self.login_attempts = {}
        self.email_verification_codes = {}
        self.qr_codes = {}

        # Load samples
        self.load_sample_inventory()
        self.load_sample_nurse()
        self.load_sample_student_records()

        self.setup_styles()
        self.show_role_selection()

    # ------------------------------------------------------------------
    #  Basic helpers used across all modules
    # ------------------------------------------------------------------
    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def show_centered_popup(self, parent, title, width, height):
        popup = tk.Toplevel(parent)
        popup.title(title)
        popup.geometry(f"{width}x{height}")
        popup.configure(bg='white')
        popup.transient(parent)
        popup.grab_set()
        popup.update_idletasks()
        x = (popup.winfo_screenwidth() // 2) - (width // 2)
        y = (popup.winfo_screenheight() // 2) - (height // 2)
        popup.geometry(f"{width}x{height}+{x}+{y}")
        return popup

    def clear_content_area(self):
        if hasattr(self, 'content_area'):
            for widget in self.content_area.winfo_children():
                widget.destroy()

    # ------------------------------------------------------------------
    #  Role selection (kept here because it’s the entry point)
    # ------------------------------------------------------------------
    def show_role_selection(self):
        self.clear_window()

        header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=120)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)

        tk.Label(header_frame, text="BATANGAS STATE UNIVERSITY",
                 font=('Arial', 22, 'bold'), bg=self.batstateu_colors['primary'],
                 fg='white').pack(pady=10)
        tk.Label(header_frame, text="The National Engineering University - ARASOF Nasugbu Campus",
                 font=('Arial', 12), bg=self.batstateu_colors['primary'],
                 fg='white').pack()

        main_frame = tk.Frame(self.root, bg=self.batstateu_colors['bg'])
        main_frame.pack(expand=True, fill='both', padx=50, pady=50)

        tk.Label(main_frame, text="Welcome to Clinic Management System",
                 font=('Arial', 28, 'bold'), bg=self.batstateu_colors['bg'],
                 fg=self.batstateu_colors['primary']).pack(pady=30)
        tk.Label(main_frame, text="Please select your role to continue:",
                 font=('Arial', 14), bg=self.batstateu_colors['bg']).pack(pady=20)

        button_frame = tk.Frame(main_frame, bg=self.batstateu_colors['bg'])
        button_frame.pack(pady=30)

        patient_btn = tk.Button(button_frame, text="PATIENTS",
                                font=('Arial', 16, 'bold'), bg=self.batstateu_colors['primary'],
                                fg='white', width=15, height=2, cursor='hand2',
                                command=self.show_patient_checkin)
        patient_btn.pack(side='left', padx=20)

        nurse_btn = tk.Button(button_frame, text="NURSE",
                              font=('Arial', 16, 'bold'), bg=self.batstateu_colors['secondary'],
                              fg=self.batstateu_colors['primary'], width=15, height=2, cursor='hand2',
                              command=self.show_nurse_login)
        nurse_btn.pack(side='left', padx=20)

        footer_frame = tk.Frame(self.root, bg=self.batstateu_colors['dark'], height=60)
        footer_frame.pack(fill='x', side='bottom')
        footer_frame.pack_propagate(False)

        tk.Label(footer_frame,
                 text="Health Services: +63 43 416 0350 local 215 | healthservices.nasugbu@g.batstate-u.edu.ph",
                 font=('Arial', 9), bg=self.batstateu_colors['dark'], fg='white').pack(pady=10)

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('Title.TLabel', font=('Arial', 24, 'bold'),
                        foreground=self.batstateu_colors['primary'])
        style.configure('Heading.TLabel', font=('Arial', 16, 'bold'),
                        foreground=self.batstateu_colors['primary'])
        style.configure('Subheading.TLabel', font=('Arial', 12, 'bold'))
        style.configure('Card.TFrame', relief='solid', borderwidth=1,
                        background=self.batstateu_colors['white'])

    # ------------------------------------------------------------------
    #  Sample data loaders (shared)
    # ------------------------------------------------------------------
    def load_sample_nurse(self):
        self.nurses.append({
            'name': 'Sample Nurse',
            'emp_id': 'NURSE001',
            'email': 'nurse@batstateu.edu.ph',
            'username': 'nurse',
            'password': 'nurse123',
            'created_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })

    def load_sample_inventory(self):
        self.inventory_items = [
            {'id': '001', 'name': 'Paracetamol', 'quantity': 500, 'unit': 'tablets',
             'status': 'In Stock', 'expiry_date': '2025-12-31', 'manufacturing_date': '2023-01-15',
             'deleted': False, 'description': 'Pain reliever and fever reducer', 'price': 5.00},
            {'id': '002', 'name': 'Bandages', 'quantity': 50, 'unit': 'boxes',
             'status': 'Low Stock ⚠️', 'expiry_date': '2026-06-30', 'manufacturing_date': '2024-01-10',
             'deleted': False, 'description': 'Sterile gauze bandages', 'price': 25.00},
            {'id': '003', 'name': 'Ethyl Alcohol', 'quantity': 120, 'unit': 'bottles',
             'status': 'In Stock', 'expiry_date': '2025-10-15', 'manufacturing_date': '2024-02-20',
             'deleted': False, 'description': '70% Isopropyl Alcohol', 'price': 45.00},
            {'id': '004', 'name': 'Gauze Pads', 'quantity': 30, 'unit': 'packs',
             'status': 'Low Stock ⚠️', 'expiry_date': '2026-03-20', 'manufacturing_date': '2024-01-05',
             'deleted': False, 'description': 'Sterile gauze pads 4x4', 'price': 15.00},
            {'id': '005', 'name': 'Digital Thermometer', 'quantity': 15, 'unit': 'pieces',
             'status': 'In Stock', 'expiry_date': 'N/A', 'manufacturing_date': '2023-06-10',
             'deleted': False, 'description': 'Digital oral thermometer', 'price': 120.00},
            {'id': '006', 'name': 'Face Mask', 'quantity': 200, 'unit': 'pieces',
             'status': 'In Stock', 'expiry_date': '2025-12-31', 'manufacturing_date': '2024-03-01',
             'deleted': False, 'description': 'Surgical face mask', 'price': 3.00},
            {'id': '007', 'name': 'Vitamin C', 'quantity': 80, 'unit': 'tablets',
             'status': 'In Stock', 'expiry_date': '2025-08-15', 'manufacturing_date': '2024-01-20',
             'deleted': False, 'description': 'Immune booster', 'price': 8.00},
        ]
        for item in self.inventory_items:
            self.add_history_record(
                item['id'],
                item['name'],
                'CREATE',
                f"Initial stock added: {item['quantity']} {item['unit']}",
                item['quantity']
            )

    def load_sample_student_records(self):
        self.student_records = [
            {'sr_code': '20-01234', 'full_name': 'Jade Rick Msusi', 'year': '3rd Year', 'program': 'BSIT', 'checkin_counts': 5},
            {'sr_code': '20-05678', 'full_name': 'Mari', 'year': '2nd Year', 'program': 'BSCS', 'checkin_counts': 3},
            {'sr_code': '21-09012', 'full_name': 'Jose Rizal', 'year': '1st Year', 'program': 'BSIS', 'checkin_counts': 1},
        ]

    def add_history_record(self, item_id, item_name, action, details, quantity_change=0):
        record = {
            'id': len(self.inventory_history) + 1,
            'item_id': item_id,
            'item_name': item_name,
            'action': action,
            'details': details,
            'quantity_change': quantity_change,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'user': self.current_user if self.current_user else 'System'
        }
        self.inventory_history.append(record)