import tkinter as tk
from tkinter import ttk, messagebox


class NurseRecordsMixin:
    def show_combined_medical_records(self):
        self.clear_content_area()

        tk.Label(self.content_area, text="MEDICAL RECORDS",
                 font=('Arial', 18, 'bold'), bg='white',
                 fg=self.batstateu_colors['primary']).pack(pady=20)

        notebook = ttk.Notebook(self.content_area)
        notebook.pack(expand=True, fill='both', padx=20, pady=10)

        patient_queue_tab = tk.Frame(notebook, bg='white')
        notebook.add(patient_queue_tab, text="Patient Queue")
        self.create_patient_queue_tab(patient_queue_tab)

        medical_records_tab = tk.Frame(notebook, bg='white')
        notebook.add(medical_records_tab, text="Medical Records List")
        self.create_medical_records_tab(medical_records_tab)

    def create_patient_queue_tab(self, parent):
        search_frame = tk.Frame(parent, bg='white')
        search_frame.pack(pady=10, fill='x', padx=10)
        tk.Label(search_frame, text="Search:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
        search_entry = tk.Entry(search_frame, font=('Arial', 11), width=20)
        search_entry.pack(side='left', padx=5)

        columns = ('Control No.', 'SR-Code', 'Name', 'Year', 'Program', 'Status', 'Time')
        tree = ttk.Treeview(parent, columns=columns, show='headings', height=12)
        col_widths = {'Control No.': 130, 'SR-Code': 100, 'Name': 150, 'Year': 80, 'Program': 80, 'Status': 100, 'Time': 130}
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=col_widths.get(col, 100))

        for patient in self.patients:
            tree.insert('', tk.END, values=(
                patient['control_number'],
                patient['sr_code'],
                patient['name'],
                patient['year'],
                patient['program'],
                patient.get('status', 'Waiting'),
                patient['timestamp']
            ))

        tree.pack(pady=10, padx=10, fill='both', expand=True)
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        scrollbar.pack(side='right', fill='y')
        tree.configure(yscrollcommand=scrollbar.set)

        action_frame = tk.Frame(parent, bg='white')
        action_frame.pack(pady=15)

        def search_queue():
            term = search_entry.get().lower()
            for item in tree.get_children():
                tree.delete(item)
            for patient in self.patients:
                if term in patient['control_number'].lower() or term in patient['name'].lower() or term in patient['sr_code'].lower():
                    tree.insert('', tk.END, values=(
                        patient['control_number'],
                        patient['sr_code'],
                        patient['name'],
                        patient['year'],
                        patient['program'],
                        patient.get('status', 'Waiting'),
                        patient['timestamp']
                    ))

        def start_consultation():
            selected = tree.selection()
            if selected:
                item = tree.item(selected[0])
                control_no = item['values'][0]
                for patient in self.patients:
                    if patient['control_number'] == control_no:
                        patient['status'] = 'In Consultation'
                        break
                tree.item(selected[0], values=(item['values'][0], item['values'][1], item['values'][2],
                                               item['values'][3], item['values'][4], 'In Consultation',
                                               item['values'][6]))
                messagebox.showinfo("Success", "Patient status updated to 'In Consultation'")
            else:
                messagebox.showwarning("Warning", "Please select a patient")

        def complete_consultation():
            selected = tree.selection()
            if selected:
                item = tree.item(selected[0])
                control_no = item['values'][0]
                for patient in self.patients:
                    if patient['control_number'] == control_no:
                        patient['status'] = 'Completed'
                        break
                tree.item(selected[0], values=(item['values'][0], item['values'][1], item['values'][2],
                                               item['values'][3], item['values'][4], 'Completed',
                                               item['values'][6]))
                self.show_document_type_selection(control_no)
            else:
                messagebox.showwarning("Warning", "Please select a patient")

        tk.Button(action_frame, text="🔍 Search", command=search_queue,
                  bg=self.batstateu_colors['info'], fg='white',
                  font=('Arial', 10), padx=10, pady=5).pack(side='left', padx=5)
        tk.Button(action_frame, text="▶ Start Consultation", command=start_consultation,
                  bg=self.batstateu_colors['warning'], fg='black',
                  font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)
        tk.Button(action_frame, text="✓ Complete & Create Document", command=complete_consultation,
                  bg=self.batstateu_colors['success'], fg='white',
                  font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)

    def create_medical_records_tab(self, parent):
        search_frame = tk.Frame(parent, bg='white')
        search_frame.pack(pady=10, fill='x', padx=10)
        tk.Label(search_frame, text="Search by Control No. or Name:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
        search_entry = tk.Entry(search_frame, font=('Arial', 11), width=20)
        search_entry.pack(side='left', padx=5)

        columns = ('Control No.', 'Patient Name', 'SR-Code', 'Symptoms', 'Temperature', 'Status', 'Date')
        tree = ttk.Treeview(parent, columns=columns, show='headings', height=12)
        col_widths = {'Control No.': 120, 'Patient Name': 150, 'SR-Code': 100, 'Symptoms': 120, 'Temperature': 80, 'Status': 100, 'Date': 130}
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=col_widths.get(col, 100))

        for record in self.medical_records:
            symptoms_str = ', '.join(record['symptoms'][:2])
            if len(record['symptoms']) > 2:
                symptoms_str += f" +{len(record['symptoms']) - 2}"
            tree.insert('', tk.END, values=(
                record['control_number'],
                record['patient_name'],
                record['sr_code'],
                symptoms_str,
                record.get('temperature', 'N/A'),
                record['status'],
                record['submission_date']
            ))

        tree.pack(pady=10, padx=10, fill='both', expand=True)
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        scrollbar.pack(side='right', fill='y')
        tree.configure(yscrollcommand=scrollbar.set)

        def search_records():
            term = search_entry.get().lower()
            for item in tree.get_children():
                tree.delete(item)
            for record in self.medical_records:
                if term in record['control_number'].lower() or term in record['patient_name'].lower():
                    symptoms_str = ', '.join(record['symptoms'][:2])
                    if len(record['symptoms']) > 2:
                        symptoms_str += f" +{len(record['symptoms']) - 2}"
                    tree.insert('', tk.END, values=(
                        record['control_number'],
                        record['patient_name'],
                        record['sr_code'],
                        symptoms_str,
                        record.get('temperature', 'N/A'),
                        record['status'],
                        record['submission_date']
                    ))

        def view_record_details():
            selected = tree.selection()
            if selected:
                item = tree.item(selected[0])
                control_no = item['values'][0]
                self.view_medical_record_detail(control_no)
            else:
                messagebox.showwarning("Warning", "Please select a record")

        tk.Button(search_frame, text="🔍 Search", command=search_records,
                  bg=self.batstateu_colors['info'], fg='white',
                  font=('Arial', 10), padx=10, pady=5).pack(side='left', padx=5)
        tk.Button(search_frame, text="📄 View Details", command=view_record_details,
                  bg=self.batstateu_colors['primary'], fg='white',
                  font=('Arial', 10), padx=10, pady=5).pack(side='left', padx=5)

    def view_medical_record_detail(self, control_no):
        record = None
        for r in self.medical_records:
            if r['control_number'] == control_no:
                record = r
                break
        if not record:
            messagebox.showerror("Error", "Record not found")
            return
        detail_window = self.show_centered_popup(self.root, f"Medical Record - {control_no}", 600, 700)
        tk.Label(detail_window, text="Medical Record Details",
                 font=('Arial', 16, 'bold'), bg='white',
                 fg=self.batstateu_colors['primary']).pack(pady=20)
        info_frame = tk.Frame(detail_window, bg='white')
        info_frame.pack(pady=20, padx=30, fill='both', expand=True)
        details = [
            ("Control Number:", record['control_number']),
            ("Patient Name:", record['patient_name']),
            ("SR-Code:", record['sr_code']),
            ("Year:", record.get('year', 'N/A')),
            ("Program:", record.get('program', 'N/A')),
            ("Submission Date:", record['submission_date']),
            ("Status:", record['status']),
            ("Temperature:", record.get('temperature', 'N/A')),
            ("Blood Pressure:", record.get('blood_pressure', 'N/A')),
            ("Allergies:", record.get('allergies', 'None')),
            ("Symptoms:", ', '.join(record['symptoms']) if record['symptoms'] else 'None'),
            ("Other Symptoms:", record.get('other_symptoms', 'None')),
            ("Medical History:", record.get('medical_history', 'None')),
        ]
        for i, (label, value) in enumerate(details):
            tk.Label(info_frame, text=label, font=('Arial', 11, 'bold'),
                     bg='white').grid(row=i, column=0, sticky='w', pady=5, padx=10)
            tk.Label(info_frame, text=str(value), font=('Arial', 11),
                     bg='white', wraplength=350, justify='left').grid(row=i, column=1, sticky='w', pady=5, padx=10)

        def update_status(new_status):
            record['status'] = new_status
            messagebox.showinfo("Success", f"Status updated to {new_status}")
            detail_window.destroy()
            self.show_combined_medical_records()

        status_frame = tk.Frame(detail_window, bg='white')
        status_frame.pack(pady=20)
        tk.Button(status_frame, text="Mark as In Progress",
                  command=lambda: update_status("In Progress"),
                  bg=self.batstateu_colors['warning'], fg='black',
                  font=('Arial', 11)).pack(side='left', padx=5)
        tk.Button(status_frame, text="Mark as Completed",
                  command=lambda: update_status("Completed"),
                  bg=self.batstateu_colors['success'], fg='white',
                  font=('Arial', 11)).pack(side='left', padx=5)

    def show_student_records(self):
        self.clear_content_area()
        tk.Label(self.content_area, text="STUDENT RECORDS",
                 font=('Arial', 18, 'bold'), bg='white',
                 fg=self.batstateu_colors['primary']).pack(pady=20)

        search_frame = tk.Frame(self.content_area, bg='white')
        search_frame.pack(pady=10, fill='x', padx=20)
        tk.Label(search_frame, text="Search:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
        search_entry = tk.Entry(search_frame, font=('Arial', 11), width=20)
        search_entry.pack(side='left', padx=5)
        tk.Label(search_frame, text="Program:", font=('Arial', 11), bg='white').pack(side='left', padx=15)
        program_filter = ttk.Combobox(search_frame, values=['All', 'BSIT', 'BSCS', 'BSIS', 'BSEMC', 'BSECE', 'BSME', 'BSCE', 'BSEE'], width=10, state='readonly')
        program_filter.set('All')
        program_filter.pack(side='left', padx=5)
        tk.Label(search_frame, text="Year:", font=('Arial', 11), bg='white').pack(side='left', padx=15)
        year_filter = ttk.Combobox(search_frame, values=['All', '1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year'], width=10, state='readonly')
        year_filter.set('All')
        year_filter.pack(side='left', padx=5)

        tree_frame = tk.Frame(self.content_area, bg='white')
        tree_frame.pack(fill='both', expand=True, padx=20, pady=10)
        columns = ('SR Code', 'Full Name', 'Year', 'Program', 'Check-in Counts')
        tree = ttk.Treeview(tree_frame, columns=columns, show='headings', height=15)
        col_widths = {'SR Code': 120, 'Full Name': 200, 'Year': 100, 'Program': 100, 'Check-in Counts': 120}
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=col_widths.get(col, 100))
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        scrollbar.pack(side='right', fill='y')
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side='left', fill='both', expand=True)

        def refresh_student_records():
            for item in tree.get_children():
                tree.delete(item)
            term = search_entry.get().lower()
            prog = program_filter.get()
            yr = year_filter.get()
            for student in sorted(self.student_records, key=lambda x: x['sr_code']):
                if term and term not in student['sr_code'].lower() and term not in student['full_name'].lower():
                    continue
                if prog != 'All' and student['program'] != prog:
                    continue
                if yr != 'All' and student['year'] != yr:
                    continue
                tree.insert('', tk.END, values=(
                    student['sr_code'],
                    student['full_name'],
                    student['year'],
                    student['program'],
                    student['checkin_counts']
                ))

        def reset_filters():
            search_entry.delete(0, tk.END)
            program_filter.set('All')
            year_filter.set('All')
            refresh_student_records()

        button_frame = tk.Frame(self.content_area, bg='white')
        button_frame.pack(pady=10)
        tk.Button(button_frame, text="🔍 Search", command=refresh_student_records,
                  bg=self.batstateu_colors['info'], fg='white',
                  font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)
        tk.Button(button_frame, text="🔄 Reset", command=reset_filters,
                  bg=self.batstateu_colors['warning'], fg='black',
                  font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)

        def export_student_records():
            export_text = "SR Code,Full Name,Year,Program,Check-in Counts\n"
            for student in self.student_records:
                export_text += f"{student['sr_code']},{student['full_name']},{student['year']},{student['program']},{student['checkin_counts']}\n"
            filename = f"student_records_{tk.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(export_text)
            messagebox.showinfo("Export", f"Student records exported to {filename}")

        tk.Button(button_frame, text="📎 Export to CSV", command=export_student_records,
                  bg=self.batstateu_colors['success'], fg='white',
                  font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)

        summary_label = tk.Label(self.content_area, text=f"Total Students: {len(self.student_records)}",
                                 font=('Arial', 11), bg='white', fg='gray')
        summary_label.pack(pady=10)

        search_entry.bind('<KeyRelease>', lambda e: refresh_student_records())
        program_filter.bind('<<ComboboxSelected>>', lambda e: refresh_student_records())
        year_filter.bind('<<ComboboxSelected>>', lambda e: refresh_student_records())

        refresh_student_records()