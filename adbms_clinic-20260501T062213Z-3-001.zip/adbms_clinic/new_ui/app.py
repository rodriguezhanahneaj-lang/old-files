# app.py
import tkinter as tk
from tkinter import ttk, messagebox, font
import os
from config import BATSTATEU_COLORS
from clinic_db import get_connection
from backend.dashboard import (
    get_dashboard_stats,
    get_checkin_visits_per_month,
    get_stock_counts,
    get_common_medical_cause,
    get_year_level_visits,
    get_peak_time_per_month,
)
from utils import clear_window, show_centered_popup
from data_manager import add_history_record, load_sample_inventory, load_sample_nurse, load_sample_student_records
from patient_module import show_patient_checkin, show_medical_form
from nurse_module import (show_nurse_login, show_email_verification, show_nurse_signup_with_email,
                                 is_account_locked, record_failed_attempt, reset_failed_attempts,
                                 show_forgot_password, show_verify_otp, show_reset_password)
from nurse_dashboard import (
    show_nurse_dashboard,
    show_nurse_dashboard_content,
    create_dashboard_charts,
    clear_content_area,
)

from inventory_handlers import (show_inventory_home, add_to_cart, remove_from_cart, clear_cart,
                                refresh_cart_display, checkout_cart, show_inventory_history,
                                show_add_inventory_item, show_modify_inventory_item, soft_delete_item,
                                show_cart_history, show_cart_popup, on_cart_popup_close,
                                remove_from_cart_popup, clear_cart_popup, checkout_from_popup)
from medical_handlers import (show_combined_medical_records, load_patient_queue, create_patient_queue_tab,
                              create_medical_records_tab, show_document_type_selection,
                              show_document_creation_form, show_view_document, view_medical_record_detail, _generate_printable_document)
from student_handlers import show_student_records
from reports_handlers import show_reports, create_patient_reports_tab, create_inventory_reports_tab, create_medical_reports_tab

# Try to import PIL for PNG/JPEG support
try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

class ClinicManagementSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("BatStateU Clinic Management System")
        self.root.geometry("1280x720")
        self.root.resizable(True, True)
        
        self.batstateu_colors = BATSTATEU_COLORS
        
        # Store data
        self.current_user = None
        self.current_user_role = None
        self.patients = [] 
        self.medical_records = []
        self.inventory_items = []
        self.medical_documents = []
        self.nurses = []
        self.student_records = []
        self.cart_items = []
        self.inventory_history = []
        self.cart_history = []
        self.login_attempts = {}
        self.email_verification_codes = {}
        self.qr_codes = {}

        
        
        # Load sample data
        self.load_sample_inventory()
        self.load_sample_nurse()
        self.load_sample_student_records()
        
        # Setup styles
        self.setup_styles()
        
        # Start with role selection
        self.show_role_selection()

    def show_centered_popup(self, parent, title, width, height):
        from utils import show_centered_popup as util_popup
        return util_popup(parent, title, width, height)
    
    def setup_styles(self):
        """Configure ttk styles for consistent UI"""
        style = ttk.Style()
        style.theme_use('clam')
        
        style.configure('Title.TLabel', font=('Arial', 24, 'bold'), 
                       foreground=self.batstateu_colors['primary'])
        style.configure('Heading.TLabel', font=('Arial', 16, 'bold'), 
                       foreground=self.batstateu_colors['primary'])
        style.configure('Subheading.TLabel', font=('Arial', 12, 'bold'))
        style.configure('Card.TFrame', relief='solid', borderwidth=1, 
                       background=self.batstateu_colors['white'])
    
    def clear_window(self):
        clear_window(self.root)

    def get_db_connection(self):
        return get_connection()
    
    def show_role_selection(self):
        """Display role selection screen with logo on the left"""
        self.clear_window()
        
        header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=140)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        # Load logo (bsu.png)
        logo_image = None
        logo_path = "bsu.png"
        if os.path.exists(logo_path):
            try:
                if PIL_AVAILABLE:
                    img = Image.open(logo_path)
                    # Resize to fit (e.g., 80x80)
                    img = img.resize((80, 80), Image.Resampling.LANCZOS)
                    logo_image = ImageTk.PhotoImage(img)
                else:
                    # Fallback: try tkinter's PhotoImage (works for GIF, PPM, PGM)
                    if logo_path.lower().endswith(('.gif', '.ppm', '.pgm')):
                        logo_image = tk.PhotoImage(file=logo_path)
                    else:
                        print("Pillow not installed. Cannot load PNG/JPEG logo.")
            except Exception as e:
                print(f"Error loading logo: {e}")
        
        # Top row: logo and title side by side
        top_row = tk.Frame(header_frame, bg=self.batstateu_colors['primary'])
        top_row.pack(fill='x', pady=10)
        
        if logo_image:
            logo_label = tk.Label(top_row, image=logo_image, bg=self.batstateu_colors['primary'])
            logo_label.image = logo_image  # keep reference
            logo_label.pack(side='left', padx=(20, 10))
        
        title_label = tk.Label(top_row, text="BATANGAS STATE UNIVERSITY", 
                               font=('Arial', 22, 'bold'), bg=self.batstateu_colors['primary'], 
                               fg='white')
        title_label.pack(side='left', padx=(0, 20))
        
        # Campus subtitle (below the title row)
        tk.Label(header_frame, text="The National Engineering University - ARASOF Nasugbu Campus", 
                font=('Arial', 12), bg=self.batstateu_colors['primary'], 
                fg='white').pack()
        
        main_frame = tk.Frame(self.root, bg=self.batstateu_colors['bg'])
        main_frame.pack(expand=True, fill='both', padx=50, pady=50)
        
        tk.Label(main_frame, text="Welcome to Clinic Management System", 
                font=('Arial', 28, 'bold'), bg=self.batstateu_colors['bg'], 
                fg=self.batstateu_colors['primary']).pack(pady=30)
        
        tk.Label(main_frame, text="Please select your role to continue:", 
                font=('Arial', 14), bg=self.batstateu_colors['bg']).pack(pady=20)
        
        button_frame = tk.Frame(main_frame, bg=self.batstateu_colors['bg'])
        button_frame.pack(pady=30)
        
        patient_btn = tk.Button(button_frame, text="PATIENTS", 
                               font=('Arial', 16, 'bold'), bg=self.batstateu_colors['primary'],
                               fg='white', width=15, height=2, cursor='hand2',
                               command=self.show_patient_checkin)
        patient_btn.pack(side='left', padx=20)
        
        nurse_btn = tk.Button(button_frame, text="NURSE", 
                             font=('Arial', 16, 'bold'), bg=self.batstateu_colors['secondary'],
                             fg=self.batstateu_colors['primary'], width=15, height=2, cursor='hand2',
                             command=self.show_nurse_login)
        nurse_btn.pack(side='left', padx=20)
        
        footer_frame = tk.Frame(self.root, bg=self.batstateu_colors['dark'], height=60)
        footer_frame.pack(fill='x', side='bottom')
        footer_frame.pack_propagate(False)
        
        tk.Label(footer_frame, 
                text="Health Services: +63 43 416 0350 local 215 | healthservices.nasugbu@g.batstate-u.edu.ph",
                font=('Arial', 9), bg=self.batstateu_colors['dark'], fg='white').pack(pady=10)

# Attach all external methods to the class
ClinicManagementSystem.show_patient_checkin = show_patient_checkin
ClinicManagementSystem.show_medical_form = show_medical_form
ClinicManagementSystem.show_nurse_login = show_nurse_login
ClinicManagementSystem.show_email_verification = show_email_verification
ClinicManagementSystem.show_nurse_signup_with_email = show_nurse_signup_with_email
ClinicManagementSystem.is_account_locked = is_account_locked
ClinicManagementSystem.record_failed_attempt = record_failed_attempt
ClinicManagementSystem.reset_failed_attempts = reset_failed_attempts
ClinicManagementSystem.show_forgot_password = show_forgot_password
ClinicManagementSystem.show_verify_otp = show_verify_otp
ClinicManagementSystem.show_reset_password = show_reset_password
ClinicManagementSystem.show_nurse_dashboard = show_nurse_dashboard
ClinicManagementSystem.show_nurse_dashboard_content = show_nurse_dashboard_content
ClinicManagementSystem.create_dashboard_charts = create_dashboard_charts
ClinicManagementSystem.clear_content_area = clear_content_area
ClinicManagementSystem.get_dashboard_stats = get_dashboard_stats
ClinicManagementSystem.get_checkin_visits_per_month = get_checkin_visits_per_month
ClinicManagementSystem.get_stock_counts = get_stock_counts
ClinicManagementSystem.get_common_medical_cause = get_common_medical_cause
ClinicManagementSystem.get_year_level_visits = get_year_level_visits
ClinicManagementSystem.get_peak_time_per_month = get_peak_time_per_month
ClinicManagementSystem.show_inventory_home = show_inventory_home
ClinicManagementSystem.add_to_cart = add_to_cart
ClinicManagementSystem.remove_from_cart = remove_from_cart
ClinicManagementSystem.clear_cart = clear_cart
ClinicManagementSystem.refresh_cart_display = refresh_cart_display
ClinicManagementSystem.checkout_cart = checkout_cart
ClinicManagementSystem.show_inventory_history = show_inventory_history
ClinicManagementSystem.show_add_inventory_item = show_add_inventory_item
ClinicManagementSystem.show_modify_inventory_item = show_modify_inventory_item
ClinicManagementSystem.soft_delete_item = soft_delete_item
ClinicManagementSystem.show_cart_history = show_cart_history
ClinicManagementSystem.show_cart_popup = show_cart_popup
ClinicManagementSystem.on_cart_popup_close = on_cart_popup_close
ClinicManagementSystem.remove_from_cart_popup = remove_from_cart_popup
ClinicManagementSystem.clear_cart_popup = clear_cart_popup
ClinicManagementSystem.checkout_from_popup = checkout_from_popup
ClinicManagementSystem.show_combined_medical_records = show_combined_medical_records
ClinicManagementSystem.load_patient_queue = load_patient_queue
ClinicManagementSystem.create_patient_queue_tab = create_patient_queue_tab
ClinicManagementSystem.create_medical_records_tab = create_medical_records_tab
ClinicManagementSystem.show_document_type_selection = show_document_type_selection
ClinicManagementSystem.show_document_creation_form = show_document_creation_form
ClinicManagementSystem.show_view_document = show_view_document
ClinicManagementSystem.view_medical_record_detail = view_medical_record_detail
ClinicManagementSystem._generate_printable_document = _generate_printable_document
ClinicManagementSystem.show_student_records = show_student_records
ClinicManagementSystem.show_reports = show_reports
ClinicManagementSystem.create_patient_reports_tab = create_patient_reports_tab
ClinicManagementSystem.create_inventory_reports_tab = create_inventory_reports_tab
ClinicManagementSystem.create_medical_reports_tab = create_medical_reports_tab

# Data manager methods
ClinicManagementSystem.add_history_record = add_history_record
ClinicManagementSystem.load_sample_inventory = load_sample_inventory
ClinicManagementSystem.load_sample_nurse = load_sample_nurse
ClinicManagementSystem.load_sample_student_records = load_sample_student_records
