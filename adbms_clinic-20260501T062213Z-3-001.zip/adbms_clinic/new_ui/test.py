import tkinter as tk
from tkinter import ttk, messagebox, font
from tkinter.scrolledtext import ScrolledText
from datetime import datetime
import random
import json
import os
import time
from collections import defaultdict

class ClinicManagementSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("BatStateU Clinic Management System")
        self.root.geometry("1280x720")
        self.root.resizable(True, True)
        
        # Configure colors
        self.batstateu_colors = {
            'primary': '#800000',      
            'secondary': '#FFD1DC',   
            'bg': '#f5f5f5',
            'white': '#ffffff',
            'text': '#333333',
            'success': '#28a745',
            'danger': '#dc3545',
            'warning': '#ffc107',
            'info': '#17a2b8',
            'dark': '#2c3e50'
        }
        
        # Store data
        self.current_user = None
        self.current_user_role = None
        self.patients = [] 
        self.medical_records = []
        self.inventory_items = []
        self.medical_documents = []
        self.nurses = []
        
        # Student Records
        self.student_records = []  # columns: sr_code, full_name, year, program, checkin_counts
        
        # Inventory cart for checkout
        self.cart_items = []
        
        # Inventory transaction history
        self.inventory_history = []
        
        # Cart checkout history
        self.cart_history = []
        
        # Login attempt tracking
        self.login_attempts = {}
        
        # Email verification storage
        self.email_verification_codes = {}
        
        # Generate QR code placeholder
        self.qr_codes = {}
        
        # Load sample inventory
        self.load_sample_inventory()
        
        # Load sample nurse account for testing
        self.load_sample_nurse()
        
        # Load sample student records
        self.load_sample_student_records()
        
        # Setup styles
        self.setup_styles()
        
        # Start with role selection
        self.show_role_selection()
    
    def load_sample_nurse(self):
        """Load a sample nurse account for testing"""
        self.nurses.append({
            'name': 'Sample Nurse',
            'emp_id': 'NURSE001',
            'email': 'nurse@batstateu.edu.ph',
            'username': 'nurse',
            'password': 'nurse123',
            'created_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    
    def load_sample_inventory(self):
        """Load sample inventory items with history records"""
        self.inventory_items = [
            {'id': '001', 'name': 'Paracetamol', 'quantity': 500, 'unit': 'tablets', 
             'status': 'In Stock', 'expiry_date': '2025-12-31', 'manufacturing_date': '2023-01-15', 
             'deleted': False, 'description': 'Pain reliever and fever reducer', 'price': 5.00},
            {'id': '002', 'name': 'Bandages', 'quantity': 50, 'unit': 'boxes', 
             'status': 'Low Stock ⚠️', 'expiry_date': '2026-06-30', 'manufacturing_date': '2024-01-10',
             'deleted': False, 'description': 'Sterile gauze bandages', 'price': 25.00},
            {'id': '003', 'name': 'Ethyl Alcohol', 'quantity': 120, 'unit': 'bottles', 
             'status': 'In Stock', 'expiry_date': '2025-10-15', 'manufacturing_date': '2024-02-20',
             'deleted': False, 'description': '70% Isopropyl Alcohol', 'price': 45.00},
            {'id': '004', 'name': 'Gauze Pads', 'quantity': 30, 'unit': 'packs', 
             'status': 'Low Stock ⚠️', 'expiry_date': '2026-03-20', 'manufacturing_date': '2024-01-05',
             'deleted': False, 'description': 'Sterile gauze pads 4x4', 'price': 15.00},
            {'id': '005', 'name': 'Digital Thermometer', 'quantity': 15, 'unit': 'pieces', 
             'status': 'In Stock', 'expiry_date': 'N/A', 'manufacturing_date': '2023-06-10',
             'deleted': False, 'description': 'Digital oral thermometer', 'price': 120.00},
            {'id': '006', 'name': 'Face Mask', 'quantity': 200, 'unit': 'pieces', 
             'status': 'In Stock', 'expiry_date': '2025-12-31', 'manufacturing_date': '2024-03-01',
             'deleted': False, 'description': 'Surgical face mask', 'price': 3.00},
            {'id': '007', 'name': 'Vitamin C', 'quantity': 80, 'unit': 'tablets', 
             'status': 'In Stock', 'expiry_date': '2025-08-15', 'manufacturing_date': '2024-01-20',
             'deleted': False, 'description': 'Immune booster', 'price': 8.00},
        ]
        
        # Add initial history records
        for item in self.inventory_items:
            self.add_history_record(
                item['id'], 
                item['name'],
                'CREATE', 
                f"Initial stock added: {item['quantity']} {item['unit']}",
                item['quantity']
            )
    
    def load_sample_student_records(self):
        """Load sample student records for testing"""
        self.student_records = [
            {'sr_code': '20-01234', 'full_name': 'Jade Rick Msusi', 'year': '3rd Year', 'program': 'BSIT', 'checkin_counts': 5},
            {'sr_code': '20-05678', 'full_name': 'Mari', 'year': '2nd Year', 'program': 'BSCS', 'checkin_counts': 3},
            {'sr_code': '21-09012', 'full_name': 'Jose Rizal', 'year': '1st Year', 'program': 'BSIS', 'checkin_counts': 1},
        ]
    
    def add_history_record(self, item_id, item_name, action, details, quantity_change=0):
        """Add a record to inventory transaction history"""
        history_record = {
            'id': len(self.inventory_history) + 1,
            'item_id': item_id,
            'item_name': item_name,
            'action': action,
            'details': details,
            'quantity_change': quantity_change,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'user': self.current_user if self.current_user else 'System'
        }
        self.inventory_history.append(history_record)
    
    def setup_styles(self):
        """Configure ttk styles for consistent UI"""
        style = ttk.Style()
        style.theme_use('clam')
        
        style.configure('Title.TLabel', font=('Arial', 24, 'bold'), 
                       foreground=self.batstateu_colors['primary'])
        style.configure('Heading.TLabel', font=('Arial', 16, 'bold'), 
                       foreground=self.batstateu_colors['primary'])
        style.configure('Subheading.TLabel', font=('Arial', 12, 'bold'))
        style.configure('Card.TFrame', relief='solid', borderwidth=1, 
                       background=self.batstateu_colors['white'])
    
    def clear_window(self):
        """Clear all widgets from the root window"""
        for widget in self.root.winfo_children():
            widget.destroy()
    
    def show_centered_popup(self, parent, title, width, height):
        """Create a centered popup window"""
        popup = tk.Toplevel(parent)
        popup.title(title)
        popup.geometry(f"{width}x{height}")
        popup.configure(bg='white')
        popup.transient(parent)
        popup.grab_set()
        
        popup.update_idletasks()
        x = (popup.winfo_screenwidth() // 2) - (width // 2)
        y = (popup.winfo_screenheight() // 2) - (height // 2)
        popup.geometry(f"{width}x{height}+{x}+{y}")
        
        return popup
    
    def generate_verification_code(self):
        """Generate a 6-digit verification code"""
        return str(random.randint(100000, 999999))
    
    def send_verification_email(self, email, code):
        """Simulate sending verification email"""
        messagebox.showinfo("Email Verification", 
                           f"Verification code sent to:\n{email}\n\nYour code is: {code}")
    
    def show_role_selection(self):
        """Display role selection screen"""
        self.clear_window()
        
        header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=120)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="BATANGAS STATE UNIVERSITY", 
                font=('Arial', 22, 'bold'), bg=self.batstateu_colors['primary'], 
                fg='white').pack(pady=10)
        tk.Label(header_frame, text="The National Engineering University - ARASOF Nasugbu Campus", 
                font=('Arial', 12), bg=self.batstateu_colors['primary'], 
                fg='white').pack()
        
        main_frame = tk.Frame(self.root, bg=self.batstateu_colors['bg'])
        main_frame.pack(expand=True, fill='both', padx=50, pady=50)
        
        tk.Label(main_frame, text="Welcome to Clinic Management System", 
                font=('Arial', 28, 'bold'), bg=self.batstateu_colors['bg'], 
                fg=self.batstateu_colors['primary']).pack(pady=30)
        
        tk.Label(main_frame, text="Please select your role to continue:", 
                font=('Arial', 14), bg=self.batstateu_colors['bg']).pack(pady=20)
        
        button_frame = tk.Frame(main_frame, bg=self.batstateu_colors['bg'])
        button_frame.pack(pady=30)
        
        patient_btn = tk.Button(button_frame, text="PATIENTS", 
                               font=('Arial', 16, 'bold'), bg=self.batstateu_colors['primary'],
                               fg='white', width=15, height=2, cursor='hand2',
                               command=self.show_patient_checkin)
        patient_btn.pack(side='left', padx=20)
        
        nurse_btn = tk.Button(button_frame, text="NURSE", 
                             font=('Arial', 16, 'bold'), bg=self.batstateu_colors['secondary'],
                             fg=self.batstateu_colors['primary'], width=15, height=2, cursor='hand2',
                             command=self.show_nurse_login)
        nurse_btn.pack(side='left', padx=20)
        
        footer_frame = tk.Frame(self.root, bg=self.batstateu_colors['dark'], height=60)
        footer_frame.pack(fill='x', side='bottom')
        footer_frame.pack_propagate(False)
        
        tk.Label(footer_frame, 
                text="Health Services: +63 43 416 0350 local 215 | healthservices.nasugbu@g.batstate-u.edu.ph",
                font=('Arial', 9), bg=self.batstateu_colors['dark'], fg='white').pack(pady=10)
    
    # ==================== PATIENT SECTION ====================
    
    def show_patient_checkin(self):
        """Display patient check-in screen"""
        self.clear_window()
        
        header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=80)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="PATIENT CHECK-IN", 
                font=('Arial', 18, 'bold'), bg=self.batstateu_colors['primary'], 
                fg='white').pack(side='left', padx=20, pady=20)
        
        back_btn = tk.Button(header_frame, text="← Back to Role Selection", 
                           bg='white', fg=self.batstateu_colors['primary'],
                           font=('Arial', 10), cursor='hand2', command=self.show_role_selection)
        back_btn.pack(side='right', padx=20, pady=20)
        
        main_frame = tk.Frame(self.root, bg=self.batstateu_colors['bg'])
        main_frame.pack(expand=True, fill='both', padx=50, pady=30)
        
        form_frame = tk.Frame(main_frame, bg='white', relief='solid', borderwidth=1)
        form_frame.pack(pady=30, ipadx=50, ipady=30)
        
        tk.Label(form_frame, text="Patient Check-in Form", 
                font=('Arial', 20, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        fields_frame = tk.Frame(form_frame, bg='white')
        fields_frame.pack(pady=20)
        
        tk.Label(fields_frame, text="SR-Code:", font=('Arial', 12), bg='white').grid(row=0, column=0, sticky='w', pady=10, padx=10)
        sr_code_entry = tk.Entry(fields_frame, font=('Arial', 12), width=30, relief='solid', borderwidth=1)
        sr_code_entry.grid(row=0, column=1, pady=10, padx=10)
        
        tk.Label(fields_frame, text="Full Name:", font=('Arial', 12), bg='white').grid(row=1, column=0, sticky='w', pady=10, padx=10)
        name_entry = tk.Entry(fields_frame, font=('Arial', 12), width=30, relief='solid', borderwidth=1)
        name_entry.grid(row=1, column=1, pady=10, padx=10)
        
        tk.Label(fields_frame, text="Year Level:", font=('Arial', 12), bg='white').grid(row=3, column=0, sticky='w', pady=10, padx=10)
        year_combo = ttk.Combobox(fields_frame, font=('Arial', 12), width=28, 
                                  values=['1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year'])
        year_combo.grid(row=3, column=1, pady=10, padx=10)
        year_combo.set('1st Year')
        
        tk.Label(fields_frame, text="Program:", font=('Arial', 12), bg='white').grid(row=4, column=0, sticky='w', pady=10, padx=10)
        program_combo = ttk.Combobox(fields_frame, font=('Arial', 12), width=28,
                                     values=['BSIT', 'BSCS', 'BSIS', 'BSEMC', 'BSECE', 'BSME', 'BSCE', 'BSEE'])
        program_combo.grid(row=4, column=1, pady=10, padx=10)
        program_combo.set('BSIT')
        
        def generate_control_number():
            if not sr_code_entry.get() or not name_entry.get():
                messagebox.showerror("Error", "Please fill in SR-Code and Name fields")
                return
            
            control_num = f"CN-{datetime.now().strftime('%Y%m%d')}-{random.randint(1000, 9999)}"
            qr_data = f"BATSTATEU-CLINIC|{control_num}|{sr_code_entry.get()}|{name_entry.get()}"
            self.qr_codes[control_num] = qr_data
            
            # Update or create student record for check-in count
            sr_code = sr_code_entry.get().strip()
            full_name = name_entry.get().strip()
            year = year_combo.get()
            program = program_combo.get()
            
            student_found = False
            for student in self.student_records:
                if student['sr_code'] == sr_code:
                    student['checkin_counts'] += 1
                    student_found = True
                    break
            
            if not student_found:
                self.student_records.append({
                    'sr_code': sr_code,
                    'full_name': full_name,
                    'year': year,
                    'program': program,
                    'checkin_counts': 1
                })
            
            patient_data = {
                'sr_code': sr_code,
                'name': full_name,
                'year': year,
                'program': program,
                'control_number': control_num,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'status': 'Waiting'
            }
            self.patients.append(patient_data)
            
            popup = self.show_centered_popup(self.root, "Check-in Successful", 500, 450)
            
            success_frame = tk.Frame(popup, bg='white')
            success_frame.pack(expand=True, fill='both', pady=30)
            
            tk.Label(success_frame, text="✓", font=('Arial', 48, 'bold'), 
                    bg='white', fg=self.batstateu_colors['success']).pack()
            
            tk.Label(success_frame, text="CHECK-IN SUCCESSFUL", 
                    font=('Arial', 16, 'bold'), bg='white', 
                    fg=self.batstateu_colors['success']).pack(pady=10)
            
            tk.Label(success_frame, text="Your Control Number is:", 
                    font=('Arial', 12), bg='white').pack()
            
            tk.Label(success_frame, text=control_num, 
                    font=('Arial', 24, 'bold'), bg='white', 
                    fg=self.batstateu_colors['primary']).pack(pady=10)
            
            qr_frame = tk.Frame(success_frame, bg='#f0f0f0', width=100, height=100, relief='solid', borderwidth=1)
            qr_frame.pack(pady=10)
            qr_frame.pack_propagate(False)
            tk.Label(qr_frame, text="[QR CODE]\nScan to access\nmedical form", font=('Arial', 8), 
                    bg='#f0f0f0').pack(expand=True)
            
            button_frame_popup = tk.Frame(popup, bg='white')
            button_frame_popup.pack(pady=20)
            
            medical_btn = tk.Button(button_frame_popup, text="📋 Fill Medical Form", 
                                   bg=self.batstateu_colors['secondary'], 
                                   fg=self.batstateu_colors['primary'],
                                   font=('Arial', 11, 'bold'), width=18,
                                   cursor='hand2',
                                   command=lambda: [popup.destroy(), self.show_medical_form(patient_data)])
            medical_btn.pack(side='left', padx=5)
            
            close_btn = tk.Button(popup, text="Close", 
                                 bg=self.batstateu_colors['primary'], fg='white',
                                 font=('Arial', 12, 'bold'), width=15,
                                 command=popup.destroy)
            close_btn.pack(pady=15)
            
            sr_code_entry.delete(0, tk.END)
            name_entry.delete(0, tk.END)
            year_combo.set('1st Year')
            program_combo.set('BSIT')
        
        submit_btn = tk.Button(form_frame, text="CHECK-IN", 
                              bg=self.batstateu_colors['primary'], fg='white',
                              font=('Arial', 14, 'bold'), width=20, height=2,
                              cursor='hand2', command=generate_control_number)
        submit_btn.pack(pady=20)
    
    def show_medical_form(self, patient_data):
        """Display medical form for patient with complete fields from Google Form"""
        self.clear_window()
        
        header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=80)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="MEDICAL FORM", 
                font=('Arial', 18, 'bold'), bg=self.batstateu_colors['primary'], 
                fg='white').pack(side='left', padx=20, pady=20)
        
        tk.Label(header_frame, text=f"Control No: {patient_data['control_number']}", 
                font=('Arial', 12), bg=self.batstateu_colors['primary'], 
                fg=self.batstateu_colors['secondary']).pack(side='right', padx=20, pady=20)
        
        # Create scrollable canvas for long form
        canvas = tk.Canvas(self.root, bg=self.batstateu_colors['bg'])
        scrollbar = ttk.Scrollbar(self.root, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=self.batstateu_colors['bg'])
        
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # CONTROL NUMBER SECTION
        control_frame = tk.LabelFrame(scrollable_frame, text="CONTROL NUMBER", 
                                       font=('Arial', 12, 'bold'), bg=self.batstateu_colors['bg'],
                                       fg='red')
        control_frame.pack(fill=tk.X, padx=20, pady=10)
        
        control_info_frame = tk.Frame(control_frame, bg=self.batstateu_colors['bg'])
        control_info_frame.pack(pady=10, padx=20)
        
        tk.Label(control_info_frame, text=f"Control Number: {patient_data['control_number']}", 
                font=('Arial', 12, 'bold'), bg=self.batstateu_colors['bg'], 
                fg=self.batstateu_colors['primary']).pack(anchor='w')
        
        tk.Label(control_info_frame, text="Format: ALxx-xxxx or ALxx-xxx (e.g AL26-1234)", 
                font=('Arial', 9), bg=self.batstateu_colors['bg'], fg='gray').pack(anchor='w')
        
        tk.Label(control_info_frame, text="Please take note of your own control number. Thank you.", 
                font=('Arial', 9, 'italic'), bg=self.batstateu_colors['bg'], fg='red').pack(anchor='w')
        
        # BASIC INFORMATION SECTION
        basic_frame = tk.LabelFrame(scrollable_frame, text="BASIC INFORMATION", 
                                    font=('Arial', 12, 'bold'), bg=self.batstateu_colors['bg'])
        basic_frame.pack(fill=tk.X, padx=20, pady=10)
        
        entries = {}
        
        # Name fields
        name_fields = [
            ("LAST NAME *", "last_name_entry"),
            ("FIRST NAME *", "first_name_entry"),
            ("MIDDLE NAME", "middle_name_entry"),
        ]
        
        for i, (label, key) in enumerate(name_fields):
            row_frame = tk.Frame(basic_frame, bg=self.batstateu_colors['bg'])
            row_frame.pack(fill=tk.X, pady=5, padx=20)
            
            tk.Label(row_frame, text=label, font=('Arial', 11), 
                    bg=self.batstateu_colors['bg'], width=15, anchor='w').pack(side='left')
            
            entry = tk.Entry(row_frame, font=('Arial', 11), width=40)
            entry.pack(side='left', padx=10)
            entries[key] = entry
            
            if "MIDDLE" in label:
                hint = tk.Label(row_frame, text="Leave it blank if does not apply", 
                               font=('Arial', 8), bg=self.batstateu_colors['bg'], fg='gray')
                hint.pack(side='left', padx=10)
            
            # Pre-fill with patient data if available
            if key == "last_name_entry":
                name_parts = patient_data['name'].split()
                if name_parts:
                    entry.insert(0, name_parts[-1] if len(name_parts) > 1 else name_parts[0])
            elif key == "first_name_entry":
                name_parts = patient_data['name'].split()
                if name_parts:
                    entry.insert(0, name_parts[0])
        
        # Age, Sex, Civil Status
        demographics_frame = tk.Frame(basic_frame, bg=self.batstateu_colors['bg'])
        demographics_frame.pack(fill=tk.X, pady=10, padx=20)
        
        tk.Label(demographics_frame, text="AGE *", font=('Arial', 11), 
                bg=self.batstateu_colors['bg']).grid(row=0, column=0, sticky='w', padx=5, pady=5)
        age_entry = tk.Entry(demographics_frame, font=('Arial', 11), width=15)
        age_entry.grid(row=0, column=1, padx=5, pady=5)
        entries['age_entry'] = age_entry
        
        tk.Label(demographics_frame, text="SEX *", font=('Arial', 11), 
                bg=self.batstateu_colors['bg']).grid(row=0, column=2, sticky='w', padx=(20,5), pady=5)
        sex_var = tk.StringVar(value="Male")
        sex_frame = tk.Frame(demographics_frame, bg=self.batstateu_colors['bg'])
        sex_frame.grid(row=0, column=3, padx=5, pady=5)
        tk.Radiobutton(sex_frame, text="Male", variable=sex_var, value="Male", 
                      bg=self.batstateu_colors['bg']).pack(side='left')
        tk.Radiobutton(sex_frame, text="Female", variable=sex_var, value="Female", 
                      bg=self.batstateu_colors['bg']).pack(side='left')
        entries['sex_var'] = sex_var
        
        tk.Label(demographics_frame, text="CIVIL STATUS *", font=('Arial', 11), 
                bg=self.batstateu_colors['bg']).grid(row=0, column=4, sticky='w', padx=(20,5), pady=5)
        civil_var = tk.StringVar(value="Single")
        civil_frame = tk.Frame(demographics_frame, bg=self.batstateu_colors['bg'])
        civil_frame.grid(row=0, column=5, padx=5, pady=5)
        tk.Radiobutton(civil_frame, text="Single", variable=civil_var, value="Single", 
                      bg=self.batstateu_colors['bg']).pack(side='left')
        tk.Radiobutton(civil_frame, text="Married", variable=civil_var, value="Married", 
                      bg=self.batstateu_colors['bg']).pack(side='left')
        entries['civil_var'] = civil_var
        
        # Address
        address_frame = tk.Frame(basic_frame, bg=self.batstateu_colors['bg'])
        address_frame.pack(fill=tk.X, pady=5, padx=20)
        
        tk.Label(address_frame, text="ADDRESS *", font=('Arial', 11), 
                bg=self.batstateu_colors['bg'], width=15, anchor='w').pack(side='left')
        address_entry = tk.Entry(address_frame, font=('Arial', 11), width=60)
        address_entry.pack(side='left', padx=10)
        entries['address_entry'] = address_entry
        
        # Height & Weight
        measurements_frame = tk.Frame(basic_frame, bg=self.batstateu_colors['bg'])
        measurements_frame.pack(fill=tk.X, pady=5, padx=20)
        
        tk.Label(measurements_frame, text="HEIGHT *", font=('Arial', 11), 
                bg=self.batstateu_colors['bg']).pack(side='left', padx=5)
        height_entry = tk.Entry(measurements_frame, font=('Arial', 11), width=15)
        height_entry.pack(side='left', padx=5)
        tk.Label(measurements_frame, text="(cm)", font=('Arial', 9), 
                bg=self.batstateu_colors['bg']).pack(side='left')
        
        tk.Label(measurements_frame, text="WEIGHT *", font=('Arial', 11), 
                bg=self.batstateu_colors['bg']).pack(side='left', padx=(20,5))
        weight_entry = tk.Entry(measurements_frame, font=('Arial', 11), width=15)
        weight_entry.pack(side='left', padx=5)
        tk.Label(measurements_frame, text="(kg)", font=('Arial', 9), 
                bg=self.batstateu_colors['bg']).pack(side='left')
        
        entries['height_entry'] = height_entry
        entries['weight_entry'] = weight_entry
        
        # PURPOSE OF MEDICAL EXAMINATION
        purpose_frame = tk.LabelFrame(scrollable_frame, text="PURPOSE OF MEDICAL EXAMINATION", 
                                       font=('Arial', 12, 'bold'), bg=self.batstateu_colors['bg'])
        purpose_frame.pack(fill=tk.X, padx=20, pady=10)
        
        tk.Label(purpose_frame, text="Please select the purpose of your medical examination.", 
                font=('Arial', 10), bg=self.batstateu_colors['bg'], fg='gray').pack(anchor='w', padx=20, pady=5)
        
        purpose_options = [
            "OJT Medical", "Pre-employment", "Annual Physical Examination (APE)",
            "Local-off Campus Activity", "International Travel / Exchange Student Program",
            "Scholarship Application", "Return to Work", "Sports Participation",
            "ROTC", "UCCL", "BUSCAA Season 26"
        ]
        
        purpose_var = tk.StringVar()
        purpose_grid = tk.Frame(purpose_frame, bg=self.batstateu_colors['bg'])
        purpose_grid.pack(padx=20, pady=10)
        
        for i, option in enumerate(purpose_options):
            row = i // 2
            col = i % 2
            tk.Radiobutton(purpose_grid, text=option, variable=purpose_var, value=option,
                          bg=self.batstateu_colors['bg'], font=('Arial', 10), anchor='w',
                          width=35).grid(row=row, column=col, sticky='w', padx=10, pady=3)
        
        entries['purpose_var'] = purpose_var
        
        # MEDICAL INFORMATION SECTION
        medical_frame = tk.LabelFrame(scrollable_frame, text="MEDICAL INFORMATION", 
                                      font=('Arial', 12, 'bold'), bg=self.batstateu_colors['bg'])
        medical_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # Symptoms
        tk.Label(medical_frame, text="Select Symptoms:", font=('Arial', 11, 'bold'), 
                bg=self.batstateu_colors['bg']).pack(anchor='w', padx=20, pady=5)
        
        symptoms = ["Fever", "Cough", "Headache", "Nausea", "Fatigue", 
                   "Sore throat", "Difficulty breathing", "Body pain", "Cold", "Diarrhea"]
        
        symptoms_vars = {}
        symptoms_frame = tk.Frame(medical_frame, bg=self.batstateu_colors['bg'])
        symptoms_frame.pack(padx=20, pady=5)
        
        for i, symptom in enumerate(symptoms):
            var = tk.BooleanVar()
            tk.Checkbutton(symptoms_frame, text=symptom, variable=var, 
                          bg=self.batstateu_colors['bg'], font=('Arial', 10)).grid(row=i//3, column=i%3, sticky='w', padx=15, pady=3)
            symptoms_vars[symptom] = var
        
        # Other Symptoms
        tk.Label(medical_frame, text="Other Symptoms:", font=('Arial', 11, 'bold'), 
                bg=self.batstateu_colors['bg']).pack(anchor='w', padx=20, pady=(10,5))
        other_symptoms = tk.Text(medical_frame, height=3, width=50, font=('Arial', 10))
        other_symptoms.pack(padx=20, pady=5)
        
        # Vital Signs
        vital_frame = tk.Frame(medical_frame, bg=self.batstateu_colors['bg'])
        vital_frame.pack(fill=tk.X, padx=20, pady=10)
        
        tk.Label(vital_frame, text="Temperature (°C):", font=('Arial', 11), 
                bg=self.batstateu_colors['bg']).pack(side='left')
        temp_entry = tk.Entry(vital_frame, font=('Arial', 11), width=10)
        temp_entry.pack(side='left', padx=10)
        
        tk.Label(vital_frame, text="Blood Pressure:", font=('Arial', 11), 
                bg=self.batstateu_colors['bg']).pack(side='left', padx=(20,5))
        bp_entry = tk.Entry(vital_frame, font=('Arial', 11), width=15)
        bp_entry.pack(side='left', padx=10)
        
        # Allergies
        allergies_frame = tk.Frame(medical_frame, bg=self.batstateu_colors['bg'])
        allergies_frame.pack(fill=tk.X, padx=20, pady=5)
        tk.Label(allergies_frame, text="Allergies (if any):", font=('Arial', 11), 
                bg=self.batstateu_colors['bg']).pack(side='left')
        allergies_entry = tk.Entry(allergies_frame, font=('Arial', 11), width=30)
        allergies_entry.pack(side='left', padx=10)
        
        # Medical History
        tk.Label(medical_frame, text="Medical History / Existing Conditions:", font=('Arial', 11, 'bold'), 
                bg=self.batstateu_colors['bg']).pack(anchor='w', padx=20, pady=(10,5))
        medical_history = tk.Text(medical_frame, height=3, width=50, font=('Arial', 10))
        medical_history.pack(padx=20, pady=5)
        
        # Disclaimer
        disclaimer_frame = tk.Frame(scrollable_frame, bg=self.batstateu_colors['bg'])
        disclaimer_frame.pack(fill=tk.X, padx=20, pady=10)
        
        tk.Label(disclaimer_frame, text="⚠️ IMPORTANT NOTE:", 
                font=('Arial', 9, 'bold'), bg=self.batstateu_colors['bg'], fg='red').pack(anchor='w')
        tk.Label(disclaimer_frame, text="Huwag isumite kailanman ang mga password sa pamamagitan ng Google Forms.", 
                font=('Arial', 8), bg=self.batstateu_colors['bg'], fg='gray').pack(anchor='w')
        tk.Label(disclaimer_frame, text="Hindi itinaguyod o inindorso ng Google ang nilalamang ito.", 
                font=('Arial', 8), bg=self.batstateu_colors['bg'], fg='gray').pack(anchor='w')
        
        def submit_medical_form():
            # Get all form data
            last_name = entries['last_name_entry'].get().strip()
            first_name = entries['first_name_entry'].get().strip()
            middle_name = entries['middle_name_entry'].get().strip()
            
            if not last_name or not first_name:
                messagebox.showerror("Error", "Last Name and First Name are required!")
                return
            
            full_name = f"{first_name} {last_name}"
            if middle_name:
                full_name = f"{first_name} {middle_name} {last_name}"
            
            selected_symptoms = [s for s, var in symptoms_vars.items() if var.get()]
            
            medical_record = {
                'control_number': patient_data['control_number'],
                'patient_name': full_name,
                'sr_code': patient_data['sr_code'],
                'year': patient_data['year'],
                'program': patient_data['program'],
                'last_name': last_name,
                'first_name': first_name,
                'middle_name': middle_name,
                'age': age_entry.get(),
                'sex': sex_var.get(),
                'civil_status': civil_var.get(),
                'address': address_entry.get(),
                'height': height_entry.get(),
                'weight': weight_entry.get(),
                'purpose': purpose_var.get(),
                'symptoms': selected_symptoms,
                'other_symptoms': other_symptoms.get("1.0", tk.END).strip(),
                'temperature': temp_entry.get(),
                'blood_pressure': bp_entry.get(),
                'allergies': allergies_entry.get(),
                'medical_history': medical_history.get("1.0", tk.END).strip(),
                'submission_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'status': 'Pending'
            }
            self.medical_records.append(medical_record)
            
            # Update patient info
            for patient in self.patients:
                if patient['control_number'] == patient_data['control_number']:
                    patient['name'] = full_name
                    patient['status'] = 'Medical Form Submitted'
                    break
            
            messagebox.showinfo("Success", "Medical form submitted successfully!\nA nurse will attend to you shortly.")
            self.show_role_selection()
        
        def clear_form():
            """Clear all medical form fields"""
            entries['last_name_entry'].delete(0, tk.END)
            entries['first_name_entry'].delete(0, tk.END)
            entries['middle_name_entry'].delete(0, tk.END)
            entries['age_entry'].delete(0, tk.END)
            entries['address_entry'].delete(0, tk.END)
            entries['height_entry'].delete(0, tk.END)
            entries['weight_entry'].delete(0, tk.END)
            entries['sex_var'].set("Male")
            entries['civil_var'].set("Single")
            entries['purpose_var'].set("")
            for var in symptoms_vars.values():
                var.set(False)
            other_symptoms.delete("1.0", tk.END)
            medical_history.delete("1.0", tk.END)
            temp_entry.delete(0, tk.END)
            bp_entry.delete(0, tk.END)
            allergies_entry.delete(0, tk.END)
            messagebox.showinfo("Success", "Form has been cleared!")
        
        button_frame = tk.Frame(scrollable_frame, bg=self.batstateu_colors['bg'])
        button_frame.pack(pady=20)
        
        submit_btn = tk.Button(button_frame, text="SUBMIT MEDICAL FORM", 
                              command=submit_medical_form, bg=self.batstateu_colors['success'], 
                              fg='white', font=('Arial', 14, 'bold'), padx=30, pady=10,
                              cursor='hand2')
        submit_btn.pack(side='left', padx=10)
        
        clear_btn = tk.Button(button_frame, text="CLEAR FORM", 
                             command=clear_form,
                             bg=self.batstateu_colors['danger'], fg='white',
                             font=('Arial', 12, 'bold'), padx=20, pady=10,
                             cursor='hand2')
        clear_btn.pack(side='left', padx=10)
        
        back_btn = tk.Button(button_frame, text="BACK", 
                            command=self.show_role_selection,
                            bg=self.batstateu_colors['info'], fg='white',
                            font=('Arial', 12, 'bold'), padx=20, pady=10,
                            cursor='hand2')
        back_btn.pack(side='left', padx=10)
        
        footer_frame = tk.Frame(self.root, bg=self.batstateu_colors['dark'], height=50)
        footer_frame.pack(side=tk.BOTTOM, fill=tk.X)
        footer_frame.pack_propagate(False)
        
        tk.Label(footer_frame, text="Please fill out all required information accurately", 
                bg=self.batstateu_colors['dark'], fg='white').pack(pady=15)
    
    # ==================== NURSE SECTION ====================
    
    def is_account_locked(self, username):
        """Check if account is locked"""
        if username in self.login_attempts:
            lockout_until = self.login_attempts[username].get('lockout_until', 0)
            if lockout_until > time.time():
                remaining = int(lockout_until - time.time())
                return True, remaining
        return False, 0
    
    def record_failed_attempt(self, username):
        """Record a failed login attempt"""
        if username not in self.login_attempts:
            self.login_attempts[username] = {'count': 0, 'lockout_until': 0}
        
        self.login_attempts[username]['count'] += 1
        
        if self.login_attempts[username]['count'] >= 3:
            self.login_attempts[username]['lockout_until'] = time.time() + 600
            self.login_attempts[username]['count'] = 0
            return True
        return False
    
    def reset_failed_attempts(self, username):
        """Reset failed attempts on successful login"""
        if username in self.login_attempts:
            self.login_attempts[username] = {'count': 0, 'lockout_until': 0}
    
    def show_nurse_login(self):
        """Display nurse login screen with lockout functionality"""
        self.clear_window()
        
        header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=80)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="NURSE LOGIN", 
                font=('Arial', 18, 'bold'), bg=self.batstateu_colors['primary'], 
                fg='white').pack(side='left', padx=20, pady=20)
        
        back_btn = tk.Button(header_frame, text="← Back to Role Selection", 
                           bg='white', fg=self.batstateu_colors['primary'],
                           font=('Arial', 10), cursor='hand2', command=self.show_role_selection)
        back_btn.pack(side='right', padx=20, pady=20)
        
        main_frame = tk.Frame(self.root, bg=self.batstateu_colors['bg'])
        main_frame.pack(expand=True, fill='both')
        
        login_frame = tk.Frame(main_frame, bg='white', relief='solid', borderwidth=1)
        login_frame.pack(pady=100, ipadx=50, ipady=30)
        
        tk.Label(login_frame, text="Nurse Authentication", 
                font=('Arial', 20, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        fields_frame = tk.Frame(login_frame, bg='white')
        fields_frame.pack(pady=20)
        
        tk.Label(fields_frame, text="Username:", font=('Arial', 12), bg='white').grid(row=0, column=0, sticky='w', pady=10)
        username_entry = tk.Entry(fields_frame, font=('Arial', 12), width=25, relief='solid', borderwidth=1)
        username_entry.grid(row=0, column=1, pady=10, padx=10)
        
        tk.Label(fields_frame, text="Password:", font=('Arial', 12), bg='white').grid(row=1, column=0, sticky='w', pady=10)
        password_entry = tk.Entry(fields_frame, font=('Arial', 12), width=25, relief='solid', borderwidth=1, show='•')
        password_entry.grid(row=1, column=1, pady=10, padx=10)
        
        status_label = tk.Label(login_frame, text="", font=('Arial', 10), bg='white', fg='red')
        status_label.pack()
        
        def login():
            username = username_entry.get()
            password = password_entry.get()
            
            if not username or not password:
                messagebox.showerror("Error", "Please enter username and password")
                return
            
            is_locked, remaining = self.is_account_locked(username)
            if is_locked:
                minutes = remaining // 60
                seconds = remaining % 60
                status_label.config(text=f"Account locked! Try again in {minutes}m {seconds}s")
                messagebox.showerror("Account Locked", f"Too many failed attempts.\nPlease try again in {minutes} minutes and {seconds} seconds.")
                return
            
            nurse_found = None
            for nurse in self.nurses:
                if nurse['username'] == username and nurse['password'] == password:
                    nurse_found = nurse
                    break
            
            if nurse_found:
                self.reset_failed_attempts(username)
                self.current_user = nurse_found['name']
                self.current_user_role = 'nurse'
                status_label.config(text="")
                self.show_nurse_dashboard()
            else:
                locked = self.record_failed_attempt(username)
                attempts_left = 3 - self.login_attempts.get(username, {}).get('count', 0)
                
                if locked:
                    status_label.config(text="Account locked for 10 minutes due to 3 failed attempts!")
                    messagebox.showerror("Account Locked", "Too many failed attempts.\nYour account has been locked for 10 minutes.")
                else:
                    status_label.config(text=f"Invalid credentials! {attempts_left} attempts remaining.")
                    messagebox.showerror("Error", f"Invalid username or password.\n{attempts_left} attempts remaining before lockout.")
        
        button_frame = tk.Frame(login_frame, bg='white')
        button_frame.pack(pady=20)
        
        tk.Button(button_frame, text="LOGIN", 
                 bg=self.batstateu_colors['primary'], fg='white',
                 font=('Arial', 12, 'bold'), width=12,
                 cursor='hand2', command=login).pack(side='left', padx=5)
        
        tk.Button(button_frame, text="SIGN UP", 
                 bg=self.batstateu_colors['secondary'], fg=self.batstateu_colors['primary'],
                 font=('Arial', 12, 'bold'), width=12,
                 cursor='hand2', command=self.show_email_verification).pack(side='left', padx=5)
    
    def show_email_verification(self):
        """Step 1: Email verification before showing registration form"""
        verify_window = self.show_centered_popup(self.root, "Email Verification", 450, 350)
        
        tk.Label(verify_window, text="Email Verification", 
                font=('Arial', 18, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        tk.Label(verify_window, text="Enter your email address to receive\na verification code.", 
                font=('Arial', 11), bg='white', fg='gray').pack()
        
        form_frame = tk.Frame(verify_window, bg='white')
        form_frame.pack(pady=30, padx=30)
        
        tk.Label(form_frame, text="Email Address:", font=('Arial', 11), 
                bg='white').grid(row=0, column=0, sticky='w', pady=10)
        email_entry = tk.Entry(form_frame, width=30, font=('Arial', 11))
        email_entry.grid(row=0, column=1, pady=10, padx=10)
        
        code_label = tk.Label(form_frame, text="Verification Code:", font=('Arial', 11), bg='white')
        code_entry = tk.Entry(form_frame, width=30, font=('Arial', 11))
        
        generated_code = None
        
        def send_code():
            nonlocal generated_code
            email = email_entry.get().strip()
            
            if not email:
                messagebox.showerror("Error", "Please enter your email address")
                return
            
            for nurse in self.nurses:
                if nurse['email'] == email:
                    messagebox.showerror("Error", "This email is already registered")
                    return
            
            generated_code = self.generate_verification_code()
            self.email_verification_codes[email] = {
                'code': generated_code,
                'expires': time.time() + 300
            }
            
            self.send_verification_email(email, generated_code)
            
            code_label.grid(row=1, column=0, sticky='w', pady=10)
            code_entry.grid(row=1, column=1, pady=10, padx=10)
            
            messagebox.showinfo("Code Sent", f"Verification code sent to {email}")
        
        def verify_and_proceed():
            email = email_entry.get().strip()
            entered_code = code_entry.get().strip()
            
            if not email or not entered_code:
                messagebox.showerror("Error", "Please enter both email and verification code")
                return
            
            if email not in self.email_verification_codes:
                messagebox.showerror("Error", "Please request a verification code first")
                return
            
            stored_data = self.email_verification_codes[email]
            
            if stored_data['expires'] < time.time():
                del self.email_verification_codes[email]
                messagebox.showerror("Error", "Verification code has expired. Please request a new one.")
                return
            
            if stored_data['code'] != entered_code:
                messagebox.showerror("Error", "Invalid verification code. Please try again.")
                return
            
            verify_window.destroy()
            self.show_nurse_signup_with_email(email)
        
        button_frame = tk.Frame(verify_window, bg='white')
        button_frame.pack(pady=20)
        
        tk.Button(button_frame, text="Send Code", 
                 bg=self.batstateu_colors['primary'], fg='white',
                 font=('Arial', 11, 'bold'), width=12,
                 command=send_code).pack(side='left', padx=10)
        
        tk.Button(button_frame, text="Verify & Continue", 
                 bg=self.batstateu_colors['success'], fg='white',
                 font=('Arial', 11, 'bold'), width=15,
                 command=verify_and_proceed).pack(side='left', padx=10)
    
    def show_nurse_signup_with_email(self, email):
        """Display nurse signup form with pre-filled email"""
        signup_window = self.show_centered_popup(self.root, "Nurse Registration", 500, 600)
        
        tk.Label(signup_window, text="Complete Your Registration", 
                font=('Arial', 18, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        form_frame = tk.Frame(signup_window, bg='white')
        form_frame.pack(pady=20, padx=50)
        
        fields = [
            ("Full Name:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Employee ID:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Username:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Password:", tk.Entry(form_frame, width=30, font=('Arial', 11), show='•')),
            ("Confirm Password:", tk.Entry(form_frame, width=30, font=('Arial', 11), show='•')),
        ]
        
        for i, (label, widget) in enumerate(fields):
            tk.Label(form_frame, text=label, font=('Arial', 11), 
                    bg='white').grid(row=i, column=0, sticky='w', pady=10)
            widget.grid(row=i, column=1, pady=10, padx=10)
        
        tk.Label(form_frame, text="Email:", font=('Arial', 11), 
                bg='white').grid(row=len(fields), column=0, sticky='w', pady=10)
        email_display = tk.Label(form_frame, text=email, font=('Arial', 11), 
                                 bg='white', fg='gray')
        email_display.grid(row=len(fields), column=1, sticky='w', pady=10, padx=10)
        
        def register_nurse():
            name = fields[0][1].get()
            emp_id = fields[1][1].get()
            username = fields[2][1].get()
            password = fields[3][1].get()
            confirm_password = fields[4][1].get()
            
            if not all([name, emp_id, username, password]):
                messagebox.showerror("Error", "Please fill in all fields")
                return
            
            if password != confirm_password:
                messagebox.showerror("Error", "Passwords do not match")
                return
            
            for nurse in self.nurses:
                if nurse['username'] == username:
                    messagebox.showerror("Error", "Username already exists")
                    return
            
            self.nurses.append({
                'name': name,
                'emp_id': emp_id,
                'email': email,
                'username': username,
                'password': password,
                'created_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
            
            if email in self.email_verification_codes:
                del self.email_verification_codes[email]
            
            messagebox.showinfo("Success", "Registration successful! Please login.")
            signup_window.destroy()
        
        tk.Button(signup_window, text="Register", 
                 bg=self.batstateu_colors['primary'], fg='white',
                 font=('Arial', 12, 'bold'), width=15,
                 command=register_nurse).pack(pady=20)
    
    def show_nurse_dashboard(self):
        """Display nurse main dashboard"""
        self.clear_window()
        
        header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=80)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="NURSE DASHBOARD", 
                font=('Arial', 18, 'bold'), bg=self.batstateu_colors['primary'], 
                fg='white').pack(side='left', padx=20, pady=20)
        
        tk.Label(header_frame, text=f"Welcome, {self.current_user or 'Nurse'}", 
                font=('Arial', 12), bg=self.batstateu_colors['primary'], 
                fg=self.batstateu_colors['secondary']).pack(side='left', padx=50, pady=20)
        
        logout_btn = tk.Button(header_frame, text="Logout", 
                             bg='white', fg=self.batstateu_colors['primary'],
                             font=('Arial', 10), cursor='hand2', command=self.show_role_selection)
        logout_btn.pack(side='right', padx=20, pady=20)
        
        main_container = tk.Frame(self.root, bg=self.batstateu_colors['bg'])
        main_container.pack(expand=True, fill='both')
        
        sidebar = tk.Frame(main_container, bg=self.batstateu_colors['primary'], width=220)
        sidebar.pack(side='left', fill='y')
        sidebar.pack_propagate(False)
        
        menu_items = [
            ("🏠 DASHBOARD", self.show_nurse_dashboard_content),
            ("📋 MEDICAL RECORDS", self.show_combined_medical_records),
            ("📦 INVENTORY", self.show_inventory_home),
            ("🛒 CART HISTORY", self.show_cart_history),
            ("📊 REPORTS", self.show_reports),
            ("👨‍🎓 STUDENT RECORDS", self.show_student_records),
        ]
        
        for item, command in menu_items:
            btn = tk.Button(sidebar, text=item, bg=self.batstateu_colors['primary'],
                          fg='white', font=('Arial', 11, 'bold' if 'INVENTORY' in item or 'MEDICAL' in item or 'CART' in item or 'STUDENT' in item else 'normal'),
                          bd=0, activebackground=self.batstateu_colors['secondary'],
                          activeforeground=self.batstateu_colors['primary'],
                          cursor='hand2', width=20, anchor='w', padx=15, pady=10,
                          command=command)
            btn.pack(pady=5, padx=5)
        
        self.content_area = tk.Frame(main_container, bg='white')
        self.content_area.pack(side='right', expand=True, fill='both', padx=20, pady=20)
        
        self.show_nurse_dashboard_content()
    
    # ==================== INVENTORY HOME WITH CART ====================
    
    def show_inventory_home(self):
        """Display inventory home page with cart sidebar"""
        self.clear_content_area()
        
        main_container = tk.Frame(self.content_area, bg='white')
        main_container.pack(fill='both', expand=True)
        
        left_frame = tk.Frame(main_container, bg='white')
        left_frame.pack(side='left', fill='both', expand=True, padx=(0, 10))
        
        title_frame = tk.Frame(left_frame, bg='white')
        title_frame.pack(fill='x', pady=10)
        
        tk.Label(title_frame, text="INVENTORY ITEMS", 
                font=('Arial', 18, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(side='left')
        
        filter_frame = tk.Frame(left_frame, bg='#f0f0f0', height=50)
        filter_frame.pack(fill='x', pady=(0, 10))
        filter_frame.pack_propagate(False)
        
        filter_inner = tk.Frame(filter_frame, bg='#f0f0f0')
        filter_inner.pack(expand=True, pady=8)
        
        tk.Label(filter_inner, text="🔍 Search:", font=('Arial', 11), 
                bg='#f0f0f0').pack(side='left', padx=(10, 5))
        search_entry = tk.Entry(filter_inner, font=('Arial', 11), width=25)
        search_entry.pack(side='left', padx=5)
        
        tk.Label(filter_inner, text="Filter:", font=('Arial', 11), 
                bg='#f0f0f0').pack(side='left', padx=(15, 5))
        filter_combo = ttk.Combobox(filter_inner, values=['All', 'In Stock', 'Low Stock ⚠️', 'Out of Stock'], 
                                    width=15, state='readonly')
        filter_combo.set('All')
        filter_combo.pack(side='left', padx=5)
        
        tree_frame = tk.Frame(left_frame, bg='white')
        tree_frame.pack(fill='both', expand=True)
        
        columns = ('ID', 'Item Name', 'Quantity', 'Unit', 'Status', 'Price', 'Expiry Date')
        tree = ttk.Treeview(tree_frame, columns=columns, show='headings', height=12)
        
        col_widths = {
            'ID': 60, 
            'Item Name': 200, 
            'Quantity': 80, 
            'Unit': 80, 
            'Status': 120, 
            'Price': 80, 
            'Expiry Date': 120
        }
        
        for col in columns:
            tree.heading(col, text=col, anchor='w')
            tree.column(col, width=col_widths.get(col, 100), anchor='w')
        
        v_scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        v_scrollbar.pack(side='right', fill='y')
        h_scrollbar = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
        h_scrollbar.pack(side='bottom', fill='x')
        
        tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        tree.pack(side='left', fill='both', expand=True)
        
        right_frame = tk.Frame(main_container, bg=self.batstateu_colors['secondary'], width=380)
        right_frame.pack(side='right', fill='y', padx=(10, 0))
        right_frame.pack_propagate(False)
        
        tk.Label(right_frame, text="🛒 CHECKOUT CART", 
                font=('Arial', 14, 'bold'), bg=self.batstateu_colors['secondary'],
                fg=self.batstateu_colors['primary']).pack(pady=10)
        
        cart_listbox = tk.Listbox(right_frame, font=('Arial', 10), height=10, bg='white')
        cart_listbox.pack(fill='both', expand=True, padx=10, pady=5)
        
        cart_total_label = tk.Label(right_frame, text="Total: ₱0.00", 
                                   font=('Arial', 12, 'bold'), bg=self.batstateu_colors['secondary'],
                                   fg=self.batstateu_colors['primary'])
        cart_total_label.pack(pady=5)
        
        cart_btn_frame = tk.Frame(right_frame, bg=self.batstateu_colors['secondary'])
        cart_btn_frame.pack(pady=5)
        
        tk.Button(cart_btn_frame, text="➕ Add to Cart", 
                 bg=self.batstateu_colors['success'], fg='white',
                 font=('Arial', 10, 'bold'), padx=10, cursor='hand2',
                 command=lambda: self.add_to_cart(tree, cart_listbox, cart_total_label)).pack(side='left', padx=5)
        
        tk.Button(cart_btn_frame, text="❌ Remove", 
                 bg=self.batstateu_colors['danger'], fg='white',
                 font=('Arial', 10, 'bold'), padx=10, cursor='hand2',
                 command=lambda: self.remove_from_cart(cart_listbox, cart_total_label)).pack(side='left', padx=5)
        
        tk.Button(cart_btn_frame, text="🗑 Clear Cart", 
                 bg=self.batstateu_colors['warning'], fg='black',
                 font=('Arial', 10, 'bold'), padx=10, cursor='hand2',
                 command=lambda: self.clear_cart(cart_listbox, cart_total_label)).pack(side='left', padx=5)
        
        patient_frame = tk.LabelFrame(right_frame, text="Patient Information", 
                                      font=('Arial', 11, 'bold'), bg=self.batstateu_colors['secondary'],
                                      fg=self.batstateu_colors['primary'])
        patient_frame.pack(fill='x', padx=10, pady=10)
        
        tk.Label(patient_frame, text="Patient Name:", font=('Arial', 10), 
                bg=self.batstateu_colors['secondary']).pack(anchor='w', padx=10, pady=(10, 0))
        patient_name_entry = tk.Entry(patient_frame, font=('Arial', 10), width=30)
        patient_name_entry.pack(padx=10, pady=3)
        
        tk.Label(patient_frame, text="SR-Code:", font=('Arial', 10), 
                bg=self.batstateu_colors['secondary']).pack(anchor='w', padx=10, pady=(5, 0))
        sr_code_entry = tk.Entry(patient_frame, font=('Arial', 10), width=30)
        sr_code_entry.pack(padx=10, pady=3)
        
        tk.Label(patient_frame, text="Reason:", font=('Arial', 10), 
                bg=self.batstateu_colors['secondary']).pack(anchor='w', padx=10, pady=(5, 0))
        reason_combo = ttk.Combobox(patient_frame, 
                                    values=['Medical Need', 'Clinic Use', 'Emergency', 'Research', 'Prescription'],
                                    width=28, state='readonly')
        reason_combo.set('Medical Need')
        reason_combo.pack(padx=10, pady=3)
        
        tk.Button(right_frame, text="✅ CHECKOUT", 
                 bg=self.batstateu_colors['success'], fg='white',
                 font=('Arial', 12, 'bold'), padx=20, pady=12, cursor='hand2',
                 command=lambda: self.checkout_cart(cart_listbox, cart_total_label, 
                                                     patient_name_entry, sr_code_entry, reason_combo,
                                                     refresh_inventory)).pack(pady=15)
        
        action_frame = tk.Frame(left_frame, bg='white')
        action_frame.pack(fill='x', pady=10)
        
        action_btn_style = {'font': ('Arial', 10, 'bold'), 'padx': 12, 'pady': 6, 'cursor': 'hand2'}
        
        tk.Button(action_frame, text="➕ Add New Item", 
                 bg=self.batstateu_colors['success'], fg='white',
                 **action_btn_style, command=lambda: self.show_add_inventory_item(refresh_inventory)).pack(side='left', padx=3)
        
        tk.Button(action_frame, text="✏️ Edit Item", 
                 bg=self.batstateu_colors['warning'], fg='black',
                 **action_btn_style, command=lambda: self.show_modify_inventory_item(tree, refresh_inventory)).pack(side='left', padx=3)
        
        tk.Button(action_frame, text="🗑 Delete Item", 
                 bg=self.batstateu_colors['danger'], fg='white',
                 **action_btn_style, command=lambda: self.soft_delete_item(tree, refresh_inventory)).pack(side='left', padx=3)
        
        tk.Button(action_frame, text="📜 View History", 
                 bg=self.batstateu_colors['info'], fg='white',
                 **action_btn_style, command=self.show_inventory_history).pack(side='left', padx=3)
        
        tk.Button(action_frame, text="🛒 Cart History", 
                 bg=self.batstateu_colors['dark'], fg='white',
                 **action_btn_style, command=self.show_cart_history).pack(side='left', padx=3)
        
        status_label = tk.Label(left_frame, text="", font=('Arial', 10), 
                                bg='white', fg='gray')
        status_label.pack(fill='x', pady=5)
        
        def refresh_inventory():
            for item in tree.get_children():
                tree.delete(item)
            
            search_term = search_entry.get().lower()
            filter_val = filter_combo.get()
            
            visible_count = 0
            low_stock_count = 0
            
            for item in self.inventory_items:
                if item.get('deleted', False):
                    continue
                
                if search_term and search_term not in item['name'].lower() and search_term not in item['id']:
                    continue
                
                if filter_val == 'In Stock' and item['status'] != 'In Stock':
                    continue
                if filter_val == 'Low Stock ⚠️' and 'Low Stock' not in item['status']:
                    continue
                if filter_val == 'Out of Stock' and item['status'] != 'Out of Stock':
                    continue
                
                visible_count += 1
                if item['quantity'] < 50 and item['quantity'] > 0:
                    low_stock_count += 1
                
                price = item.get('price', 0)
                
                tags = ()
                if item['quantity'] <= 0:
                    tags = ('out_of_stock',)
                elif item['quantity'] < 50:
                    tags = ('low_stock',)
                
                tree.insert('', tk.END, values=(
                    item['id'],
                    item['name'],
                    item['quantity'],
                    item['unit'],
                    item['status'],
                    f"₱{price:.2f}",
                    item['expiry_date']
                ), tags=tags)
            
            tree.tag_configure('low_stock', background='#fff3cd')
            tree.tag_configure('out_of_stock', background='#f8d7da')
            
            total_active = len([i for i in self.inventory_items if not i.get('deleted', False)])
            status_label.config(text=f"Showing {visible_count} of {total_active} items | Low Stock: {low_stock_count}")
        
        search_entry.bind('<KeyRelease>', lambda e: refresh_inventory())
        filter_combo.bind('<<ComboboxSelected>>', lambda e: refresh_inventory())
        
        refresh_inventory()
        self.refresh_cart_display(cart_listbox, cart_total_label)
    
    def add_to_cart(self, tree, cart_listbox, cart_total_label):
        selected = tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select an item to add to cart")
            return
        
        item = tree.item(selected[0])
        item_id = item['values'][0]
        item_name = item['values'][1]
        available_qty = item['values'][2]
        unit = item['values'][3]
        price_str = item['values'][5].replace('₱', '')
        price = float(price_str) if price_str else 0
        
        qty_popup = self.show_centered_popup(self.root, "Enter Quantity", 300, 200)
        tk.Label(qty_popup, text=f"Item: {item_name}", font=('Arial', 12, 'bold'), 
                bg='white').pack(pady=10)
        tk.Label(qty_popup, text=f"Available: {available_qty} {unit}", 
                font=('Arial', 10), bg='white').pack()
        tk.Label(qty_popup, text="Quantity:", font=('Arial', 11), bg='white').pack(pady=10)
        qty_entry = tk.Entry(qty_popup, font=('Arial', 11), width=10)
        qty_entry.pack()
        
        def add_to_cart_confirm():
            try:
                qty = int(qty_entry.get())
                if qty <= 0:
                    messagebox.showerror("Error", "Quantity must be positive")
                    return
                if qty > available_qty:
                    messagebox.showerror("Error", f"Insufficient stock! Only {available_qty} available")
                    return
                
                for cart_item in self.cart_items:
                    if cart_item['item_id'] == item_id:
                        new_qty = cart_item['quantity'] + qty
                        if new_qty > available_qty:
                            messagebox.showerror("Error", f"Cannot add {qty}. Total would exceed available stock")
                            return
                        cart_item['quantity'] = new_qty
                        break
                else:
                    self.cart_items.append({
                        'item_id': item_id,
                        'name': item_name,
                        'quantity': qty,
                        'unit': unit,
                        'price': price
                    })
                
                qty_popup.destroy()
                self.refresh_cart_display(cart_listbox, cart_total_label)
                messagebox.showinfo("Success", f"Added {qty} {unit} of {item_name} to cart")
            except ValueError:
                messagebox.showerror("Error", "Please enter a valid number")
        
        tk.Button(qty_popup, text="Add to Cart", command=add_to_cart_confirm,
                 bg=self.batstateu_colors['success'], fg='white',
                 font=('Arial', 11, 'bold')).pack(pady=15)
    
    def remove_from_cart(self, cart_listbox, cart_total_label):
        selected = cart_listbox.curselection()
        if not selected:
            messagebox.showwarning("Warning", "Please select an item to remove")
            return
        
        index = selected[0]
        if index < len(self.cart_items):
            removed = self.cart_items.pop(index)
            self.refresh_cart_display(cart_listbox, cart_total_label)
            messagebox.showinfo("Removed", f"Removed {removed['name']} from cart")
    
    def clear_cart(self, cart_listbox, cart_total_label):
        if self.cart_items and messagebox.askyesno("Clear Cart", "Are you sure you want to clear the entire cart?"):
            self.cart_items.clear()
            self.refresh_cart_display(cart_listbox, cart_total_label)
            messagebox.showinfo("Cart Cleared", "All items have been removed from cart")
    
    def refresh_cart_display(self, cart_listbox=None, cart_total_label=None):
        if cart_listbox:
            cart_listbox.delete(0, tk.END)
            total = 0
            for item in self.cart_items:
                item_total = item['quantity'] * item['price']
                total += item_total
                cart_listbox.insert(tk.END, f"{item['name']} - {item['quantity']} {item['unit']} - ₱{item_total:.2f}")
            
            if cart_total_label:
                cart_total_label.config(text=f"Total: ₱{total:.2f}")
    
    def checkout_cart(self, cart_listbox, cart_total_label, patient_name_entry, sr_code_entry, reason_combo, refresh_callback):
        if not self.cart_items:
            messagebox.showwarning("Warning", "Cart is empty. Please add items to checkout.")
            return
        
        patient_name = patient_name_entry.get().strip()
        sr_code = sr_code_entry.get().strip()
        reason = reason_combo.get()
        
        if not patient_name or not sr_code:
            messagebox.showerror("Error", "Please enter patient name and SR-Code")
            return
        
        checkout_success = True
        checkout_details = []
        
        for cart_item in self.cart_items:
            inv_item = None
            for item in self.inventory_items:
                if item['id'] == cart_item['item_id'] and not item.get('deleted', False):
                    inv_item = item
                    break
            
            if not inv_item:
                checkout_details.append(f"❌ {cart_item['name']}: Item not found")
                checkout_success = False
                continue
            
            if cart_item['quantity'] > inv_item['quantity']:
                checkout_details.append(f"❌ {cart_item['name']}: Insufficient stock (Requested: {cart_item['quantity']}, Available: {inv_item['quantity']})")
                checkout_success = False
                continue
            
            inv_item['quantity'] -= cart_item['quantity']
            
            if inv_item['quantity'] < 50 and inv_item['quantity'] > 0:
                inv_item['status'] = "Low Stock ⚠️"
            elif inv_item['quantity'] <= 0:
                inv_item['status'] = "Out of Stock"
            else:
                inv_item['status'] = "In Stock"
            
            details = f"Checked out {cart_item['quantity']} {cart_item['unit']} for {patient_name} (SR: {sr_code}) - Reason: {reason}"
            self.add_history_record(inv_item['id'], inv_item['name'], 'CHECKOUT', details, -cart_item['quantity'])
            
            checkout_details.append(f"✅ {cart_item['name']}: {cart_item['quantity']} {cart_item['unit']} - ₱{cart_item['quantity'] * cart_item['price']:.2f}")
        
        if checkout_success:
            total_amount = sum(item['quantity'] * item['price'] for item in self.cart_items)
            
            checkout_record = {
                'id': len(self.cart_history) + 1,
                'patient_name': patient_name,
                'sr_code': sr_code,
                'reason': reason,
                'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'items': [{'name': item['name'], 'quantity': item['quantity'], 
                           'unit': item['unit'], 'price': item['price'], 
                           'total': item['quantity'] * item['price']} for item in self.cart_items],
                'total_amount': total_amount,
                'nurse': self.current_user if self.current_user else 'Nurse'
            }
            self.cart_history.append(checkout_record)
            
            self.cart_items.clear()
            self.refresh_cart_display(cart_listbox, cart_total_label)
            patient_name_entry.delete(0, tk.END)
            sr_code_entry.delete(0, tk.END)
            
            receipt = f"========== CHECKOUT RECEIPT ==========\n"
            receipt += f"Transaction ID: {checkout_record['id']}\n"
            receipt += f"Patient: {patient_name} (SR: {sr_code})\n"
            receipt += f"Date: {checkout_record['date']}\n"
            receipt += f"Reason: {reason}\n\n"
            receipt += "Items:\n"
            for detail in checkout_details:
                receipt += f"  {detail}\n"
            receipt += f"\nTotal Amount: ₱{total_amount:.2f}\n"
            receipt += "====================================="
            
            receipt_popup = self.show_centered_popup(self.root, "Checkout Receipt", 500, 400)
            text_area = ScrolledText(receipt_popup, wrap=tk.WORD, width=60, height=20, font=('Courier', 10))
            text_area.pack(padx=10, pady=10, fill='both', expand=True)
            text_area.insert('1.0', receipt)
            text_area.configure(state='disabled')
            
            tk.Button(receipt_popup, text="Print Receipt", 
                     bg=self.batstateu_colors['primary'], fg='white',
                     font=('Arial', 11, 'bold'), command=receipt_popup.destroy).pack(pady=10)
            
            refresh_callback()
        else:
            error_msg = "\n".join(checkout_details)
            messagebox.showerror("Checkout Failed", f"Some items could not be processed:\n\n{error_msg}")
            refresh_callback()
    
    def show_inventory_history(self):
        history_window = self.show_centered_popup(self.root, "Inventory Transaction History", 800, 500)
        
        tk.Label(history_window, text="📜 INVENTORY TRANSACTION HISTORY", 
                font=('Arial', 16, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=15)
        
        filter_frame = tk.Frame(history_window, bg='white')
        filter_frame.pack(pady=10, fill='x', padx=20)
        
        tk.Label(filter_frame, text="Filter by Action:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
        action_filter = ttk.Combobox(filter_frame, values=['All', 'CREATE', 'EDIT', 'CHECKOUT', 'DELETE'], width=15)
        action_filter.set('All')
        action_filter.pack(side='left', padx=5)
        
        tk.Label(filter_frame, text="Search Item:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
        search_entry = tk.Entry(filter_frame, width=20)
        search_entry.pack(side='left', padx=5)
        
        tree_frame = tk.Frame(history_window, bg='white')
        tree_frame.pack(fill='both', expand=True, padx=20, pady=10)
        
        columns = ('ID', 'Date/Time', 'Item Name', 'Action', 'Quantity Change', 'Details', 'User')
        tree = ttk.Treeview(tree_frame, columns=columns, show='headings', height=15)
        
        col_widths = {'ID': 50, 'Date/Time': 150, 'Item Name': 150, 'Action': 100, 
                      'Quantity Change': 100, 'Details': 200, 'User': 120}
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=col_widths.get(col, 100))
        
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        scrollbar.pack(side='right', fill='y')
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side='left', fill='both', expand=True)
        
        def refresh_history():
            for item in tree.get_children():
                tree.delete(item)
            
            filter_action = action_filter.get()
            search_term = search_entry.get().lower()
            
            for record in reversed(self.inventory_history):
                if filter_action != 'All' and record['action'] != filter_action:
                    continue
                if search_term and search_term not in record['item_name'].lower():
                    continue
                
                qty_change = record['quantity_change']
                qty_display = f"{'+' if qty_change > 0 else ''}{qty_change}" if qty_change != 0 else '-'
                
                tree.insert('', tk.END, values=(
                    record['id'],
                    record['timestamp'],
                    record['item_name'],
                    record['action'],
                    qty_display,
                    record['details'],
                    record['user']
                ))
        
        action_filter.bind('<<ComboboxSelected>>', lambda e: refresh_history())
        search_entry.bind('<KeyRelease>', lambda e: refresh_history())
        
        tk.Button(filter_frame, text="🔍 Search", command=refresh_history,
                 bg=self.batstateu_colors['info'], fg='white',
                 font=('Arial', 10), padx=10, pady=3).pack(side='left', padx=5)
        
        tk.Button(filter_frame, text="🔄 Refresh", command=refresh_history,
                 bg=self.batstateu_colors['primary'], fg='white',
                 font=('Arial', 10), padx=10, pady=3).pack(side='left', padx=5)
        
        summary_label = tk.Label(history_window, text=f"Total Transactions: {len(self.inventory_history)}", 
                                 font=('Arial', 10), bg='white', fg='gray')
        summary_label.pack(pady=5)
        
        refresh_history()
    
    def show_add_inventory_item(self, refresh_callback):
        popup = self.show_centered_popup(self.root, "Add Inventory Item", 450, 600)
        
        tk.Label(popup, text="Add New Inventory Item", 
                font=('Arial', 16, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        form_frame = tk.Frame(popup, bg='white')
        form_frame.pack(pady=20, padx=30)
        
        fields = [
            ("Item Name:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Description:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Quantity:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Unit:", ttk.Combobox(form_frame, values=['tablets', 'bottles', 'boxes', 'pieces', 'packs', 'units'], width=27)),
            ("Price (₱):", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Manufacturing Date (YYYY-MM-DD):", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Expiry Date (YYYY-MM-DD):", tk.Entry(form_frame, width=30, font=('Arial', 11))),
        ]
        
        entries = {}
        
        for i, (label, widget) in enumerate(fields):
            tk.Label(form_frame, text=label, font=('Arial', 11), 
                    bg='white').grid(row=i, column=0, sticky='w', pady=8)
            widget.grid(row=i, column=1, pady=8, padx=10, sticky='ew')
            if isinstance(widget, ttk.Combobox):
                widget.set('pieces')
            entries[label] = widget
        
        def save_item():
            name = entries.get("Item Name:").get()
            description = entries.get("Description:").get()
            quantity = entries.get("Quantity:").get()
            unit = entries.get("Unit:").get()
            price_str = entries.get("Price (₱):").get()
            manufacturing_date = entries.get("Manufacturing Date (YYYY-MM-DD):").get()
            expiry_date = entries.get("Expiry Date (YYYY-MM-DD):").get()
            
            if not name or not quantity:
                messagebox.showerror("Error", "Please fill in required fields")
                return
            
            try:
                qty = int(quantity)
                price = float(price_str) if price_str else 0
            except ValueError:
                messagebox.showerror("Error", "Quantity and Price must be numbers")
                return
            
            new_id = str(len(self.inventory_items) + 1).zfill(3)
            
            status = "In Stock"
            if qty < 50 and qty > 0:
                status = "Low Stock ⚠️"
            elif qty <= 0:
                status = "Out of Stock"
            
            new_item = {
                'id': new_id,
                'name': name,
                'description': description,
                'quantity': qty,
                'unit': unit,
                'status': status,
                'price': price,
                'manufacturing_date': manufacturing_date if manufacturing_date else 'N/A',
                'expiry_date': expiry_date if expiry_date else 'N/A',
                'deleted': False
            }
            self.inventory_items.append(new_item)
            
            self.add_history_record(new_id, name, 'CREATE', 
                                   f"New item added: {qty} {unit} (Price: ₱{price:.2f})", qty)
            
            messagebox.showinfo("Success", "Item added to inventory")
            popup.destroy()
            refresh_callback()
        
        tk.Button(popup, text="Add Item", 
                 bg=self.batstateu_colors['success'], fg='white',
                 font=('Arial', 12, 'bold'), width=15,
                 command=save_item).pack(pady=20)
    
    def show_modify_inventory_item(self, tree, refresh_callback):
        selected = tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select an item to modify")
            return
        
        item = tree.item(selected[0])
        item_id = item['values'][0]
        
        inv_item = None
        for i in self.inventory_items:
            if i['id'] == item_id:
                inv_item = i
                break
        
        if not inv_item:
            messagebox.showerror("Error", "Item not found")
            return
        
        popup = self.show_centered_popup(self.root, f"Modify Item: {inv_item['name']}", 500, 650)
        
        tk.Label(popup, text=f"Edit Inventory Item", 
                font=('Arial', 16, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        form_frame = tk.Frame(popup, bg='white')
        form_frame.pack(pady=20, padx=30)
        
        original_name = inv_item['name']
        original_quantity = inv_item['quantity']
        
        fields = [
            ("Item Name:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Description:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Quantity:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Unit:", ttk.Combobox(form_frame, values=['tablets', 'bottles', 'boxes', 'pieces', 'packs', 'units'], width=27)),
            ("Price (₱):", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Manufacturing Date (YYYY-MM-DD):", tk.Entry(form_frame, width=30, font=('Arial', 11))),
            ("Expiry Date (YYYY-MM-DD):", tk.Entry(form_frame, width=30, font=('Arial', 11))),
        ]
        
        entries = {}
        
        for i, (label, widget) in enumerate(fields):
            tk.Label(form_frame, text=label, font=('Arial', 11), 
                    bg='white').grid(row=i, column=0, sticky='w', pady=8)
            widget.grid(row=i, column=1, pady=8, padx=10, sticky='ew')
            
            if label == "Item Name:":
                widget.insert(0, inv_item['name'])
            elif label == "Description:":
                widget.insert(0, inv_item.get('description', ''))
            elif label == "Quantity:":
                widget.insert(0, str(inv_item['quantity']))
            elif label == "Unit:":
                widget.set(inv_item['unit'])
            elif label == "Price (₱):":
                widget.insert(0, str(inv_item.get('price', 0)))
            elif label == "Manufacturing Date (YYYY-MM-DD):":
                widget.insert(0, inv_item.get('manufacturing_date', 'N/A'))
            elif label == "Expiry Date (YYYY-MM-DD):":
                widget.insert(0, inv_item.get('expiry_date', 'N/A'))
            
            entries[label] = widget
        
        def save_modifications():
            new_name = entries.get("Item Name:").get()
            new_description = entries.get("Description:").get()
            new_quantity_str = entries.get("Quantity:").get()
            new_unit = entries.get("Unit:").get()
            new_price_str = entries.get("Price (₱):").get()
            new_manufacturing_date = entries.get("Manufacturing Date (YYYY-MM-DD):").get()
            new_expiry_date = entries.get("Expiry Date (YYYY-MM-DD):").get()
            
            if not new_name or not new_quantity_str:
                messagebox.showerror("Error", "Please fill in required fields")
                return
            
            try:
                new_quantity = int(new_quantity_str)
                new_price = float(new_price_str) if new_price_str else 0
            except ValueError:
                messagebox.showerror("Error", "Quantity and Price must be numbers")
                return
            
            changes = []
            quantity_change = new_quantity - original_quantity
            
            if new_name != original_name:
                changes.append(f"Name: '{original_name}' → '{new_name}'")
            if quantity_change != 0:
                changes.append(f"Quantity: {original_quantity} → {new_quantity} ({'+' if quantity_change > 0 else ''}{quantity_change})")
            if new_unit != inv_item['unit']:
                changes.append(f"Unit: {inv_item['unit']} → {new_unit}")
            if new_price != inv_item.get('price', 0):
                changes.append(f"Price: ₱{inv_item.get('price', 0):.2f} → ₱{new_price:.2f}")
            if new_description != inv_item.get('description', ''):
                changes.append("Description updated")
            
            inv_item['name'] = new_name
            inv_item['description'] = new_description
            inv_item['quantity'] = new_quantity
            inv_item['unit'] = new_unit
            inv_item['price'] = new_price
            inv_item['manufacturing_date'] = new_manufacturing_date if new_manufacturing_date else 'N/A'
            inv_item['expiry_date'] = new_expiry_date if new_expiry_date else 'N/A'
            
            if new_quantity < 50 and new_quantity > 0:
                inv_item['status'] = "Low Stock ⚠️"
            elif new_quantity <= 0:
                inv_item['status'] = "Out of Stock"
            else:
                inv_item['status'] = "In Stock"
            
            if changes:
                details = "; ".join(changes)
                self.add_history_record(inv_item['id'], inv_item['name'], 'EDIT', details, quantity_change)
            else:
                self.add_history_record(inv_item['id'], inv_item['name'], 'EDIT', "No changes made", 0)
            
            messagebox.showinfo("Success", "Item updated successfully!")
            popup.destroy()
            refresh_callback()
        
        tk.Button(popup, text="Save Changes", 
                 bg=self.batstateu_colors['success'], fg='white',
                 font=('Arial', 12, 'bold'), width=15,
                 command=save_modifications).pack(pady=20)
    
    def soft_delete_item(self, tree, refresh_callback):
        selected = tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select an item to delete")
            return
        
        item = tree.item(selected[0])
        item_id = item['values'][0]
        item_name = item['values'][1]
        
        inv_item = None
        for i in self.inventory_items:
            if i['id'] == item_id:
                inv_item = i
                break
        
        if not inv_item:
            messagebox.showerror("Error", "Item not found")
            return
        
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete item '{item_name}'?\n\nThis will be a soft delete (item will be hidden)."):
            inv_item['deleted'] = True
            self.add_history_record(item_id, item_name, 'DELETE', f"Item '{item_name}' was soft deleted", 0)
            refresh_callback()
            messagebox.showinfo("Success", f"Item '{item_name}' has been soft deleted")
    
    def show_cart_history(self):
        if not self.cart_history:
            messagebox.showinfo("Cart History", "No checkout transactions yet.")
            return
        
        history_window = self.show_centered_popup(self.root, "Cart Checkout History", 900, 600)
        
        tk.Label(history_window, text="🛒 CHECKOUT HISTORY", 
                font=('Arial', 16, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=15)
        
        notebook = ttk.Notebook(history_window)
        notebook.pack(expand=True, fill='both', padx=10, pady=10)
        
        summary_tab = tk.Frame(notebook, bg='white')
        notebook.add(summary_tab, text="Summary View")
        
        columns = ('ID', 'Date', 'Patient Name', 'SR-Code', 'Items Count', 'Total Amount', 'Nurse')
        tree = ttk.Treeview(summary_tab, columns=columns, show='headings', height=15)
        
        col_widths = {'ID': 50, 'Date': 150, 'Patient Name': 150, 'SR-Code': 100, 
                      'Items Count': 80, 'Total Amount': 100, 'Nurse': 120}
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=col_widths.get(col, 100))
        
        scrollbar = ttk.Scrollbar(summary_tab, orient="vertical", command=tree.yview)
        scrollbar.pack(side='right', fill='y')
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side='left', fill='both', expand=True)
        
        for record in reversed(self.cart_history):
            tree.insert('', tk.END, values=(
                record['id'],
                record['date'],
                record['patient_name'],
                record['sr_code'],
                len(record['items']),
                f"₱{record['total_amount']:.2f}",
                record['nurse']
            ))
        
        detail_tab = tk.Frame(notebook, bg='white')
        notebook.add(detail_tab, text="Detailed View")
        
        select_frame = tk.Frame(detail_tab, bg='white')
        select_frame.pack(pady=10, fill='x')
        
        tk.Label(select_frame, text="Select Transaction ID:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
        id_combo = ttk.Combobox(select_frame, values=[str(r['id']) for r in self.cart_history], width=10, state='readonly')
        id_combo.pack(side='left', padx=5)
        
        detail_text = ScrolledText(detail_tab, wrap=tk.WORD, width=90, height=25, font=('Courier', 10))
        detail_text.pack(padx=10, pady=10, fill='both', expand=True)
        
        def show_detail():
            selected_id = id_combo.get()
            if not selected_id:
                messagebox.showwarning("Warning", "Please select a transaction ID")
                return
            
            record = None
            for r in self.cart_history:
                if str(r['id']) == selected_id:
                    record = r
                    break
            
            if record:
                detail_text.delete(1.0, tk.END)
                receipt = f"========== CHECKOUT RECEIPT ==========\n"
                receipt += f"Transaction ID: {record['id']}\n"
                receipt += f"Date: {record['date']}\n"
                receipt += f"Nurse: {record['nurse']}\n"
                receipt += f"Patient: {record['patient_name']} (SR: {record['sr_code']})\n"
                receipt += f"Reason: {record['reason']}\n\n"
                receipt += "Items:\n"
                for item in record['items']:
                    receipt += f"  - {item['name']}: {item['quantity']} {item['unit']} @ ₱{item['price']:.2f} = ₱{item['total']:.2f}\n"
                receipt += f"\nTotal Amount: ₱{record['total_amount']:.2f}\n"
                receipt += "====================================="
                detail_text.delete(1.0, tk.END)
                detail_text.insert(1.0, receipt)
        
        tk.Button(select_frame, text="View Details", command=show_detail,
                 bg=self.batstateu_colors['info'], fg='white',
                 font=('Arial', 10, 'bold')).pack(side='left', padx=10)
        
        def export_history():
            export_text = "ID,DATE,PATIENT,SR-CODE,REASON,TOTAL,NURSE,ITEMS\n"
            for record in self.cart_history:
                items_str = "; ".join([f"{i['name']} x{i['quantity']}" for i in record['items']])
                export_text += f"{record['id']},{record['date']},{record['patient_name']},{record['sr_code']},{record['reason']},{record['total_amount']},{record['nurse']},\"{items_str}\"\n"
            
            filename = f"cart_history_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(export_text)
            messagebox.showinfo("Export", f"Cart history exported to {filename}")
        
        tk.Button(history_window, text="📎 Export to CSV", command=export_history,
                 bg=self.batstateu_colors['success'], fg='white',
                 font=('Arial', 10, 'bold')).pack(pady=10)
    
    # ==================== STUDENT RECORDS SECTION ====================
    
    def show_student_records(self):
        """Display student records with check-in counts"""
        self.clear_content_area()
        
        tk.Label(self.content_area, text="STUDENT RECORDS", 
                font=('Arial', 18, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        # Search and filter frame
        search_frame = tk.Frame(self.content_area, bg='white')
        search_frame.pack(pady=10, fill='x', padx=20)
        
        tk.Label(search_frame, text="Search:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
        search_entry = tk.Entry(search_frame, font=('Arial', 11), width=20)
        search_entry.pack(side='left', padx=5)
        
        tk.Label(search_frame, text="Program:", font=('Arial', 11), bg='white').pack(side='left', padx=15)
        program_filter = ttk.Combobox(search_frame, values=['All', 'BSIT', 'BSCS', 'BSIS', 'BSEMC', 'BSECE', 'BSME', 'BSCE', 'BSEE'], width=10, state='readonly')
        program_filter.set('All')
        program_filter.pack(side='left', padx=5)
        
        tk.Label(search_frame, text="Year:", font=('Arial', 11), bg='white').pack(side='left', padx=15)
        year_filter = ttk.Combobox(search_frame, values=['All', '1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year'], width=10, state='readonly')
        year_filter.set('All')
        year_filter.pack(side='left', padx=5)
        
        # Treeview for student records
        tree_frame = tk.Frame(self.content_area, bg='white')
        tree_frame.pack(fill='both', expand=True, padx=20, pady=10)
        
        columns = ('SR Code', 'Full Name', 'Year', 'Program', 'Check-in Counts')
        tree = ttk.Treeview(tree_frame, columns=columns, show='headings', height=15)
        
        col_widths = {'SR Code': 120, 'Full Name': 200, 'Year': 100, 'Program': 100, 'Check-in Counts': 120}
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=col_widths.get(col, 100))
        
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        scrollbar.pack(side='right', fill='y')
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side='left', fill='both', expand=True)
        
        def refresh_student_records():
            for item in tree.get_children():
                tree.delete(item)
            
            search_term = search_entry.get().lower()
            prog_filter = program_filter.get()
            yr_filter = year_filter.get()
            
            for student in sorted(self.student_records, key=lambda x: x['sr_code']):
                if search_term and search_term not in student['sr_code'].lower() and search_term not in student['full_name'].lower():
                    continue
                if prog_filter != 'All' and student['program'] != prog_filter:
                    continue
                if yr_filter != 'All' and student['year'] != yr_filter:
                    continue
                
                tree.insert('', tk.END, values=(
                    student['sr_code'],
                    student['full_name'],
                    student['year'],
                    student['program'],
                    student['checkin_counts']
                ))
        
        def reset_filters():
            search_entry.delete(0, tk.END)
            program_filter.set('All')
            year_filter.set('All')
            refresh_student_records()
        
        button_frame = tk.Frame(self.content_area, bg='white')
        button_frame.pack(pady=10)
        
        tk.Button(button_frame, text="🔍 Search", command=refresh_student_records,
                 bg=self.batstateu_colors['info'], fg='white',
                 font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)
        
        tk.Button(button_frame, text="🔄 Reset", command=reset_filters,
                 bg=self.batstateu_colors['warning'], fg='black',
                 font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)
        
        # Export to CSV button
        def export_student_records():
            export_text = "SR Code,Full Name,Year,Program,Check-in Counts\n"
            for student in self.student_records:
                export_text += f"{student['sr_code']},{student['full_name']},{student['year']},{student['program']},{student['checkin_counts']}\n"
            
            filename = f"student_records_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(export_text)
            messagebox.showinfo("Export", f"Student records exported to {filename}")
        
        tk.Button(button_frame, text="📎 Export to CSV", command=export_student_records,
                 bg=self.batstateu_colors['success'], fg='white',
                 font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)
        
        # Summary label
        summary_label = tk.Label(self.content_area, text=f"Total Students: {len(self.student_records)}", 
                                 font=('Arial', 11), bg='white', fg='gray')
        summary_label.pack(pady=10)
        
        # Bind events
        search_entry.bind('<KeyRelease>', lambda e: refresh_student_records())
        program_filter.bind('<<ComboboxSelected>>', lambda e: refresh_student_records())
        year_filter.bind('<<ComboboxSelected>>', lambda e: refresh_student_records())
        
        refresh_student_records()
    
    # ==================== MEDICAL RECORDS SECTION ====================
    
    def show_combined_medical_records(self):
        """Combined view for Patient Queue and Medical Records List (removed Create Document tab)"""
        self.clear_content_area()
        
        tk.Label(self.content_area, text="MEDICAL RECORDS", 
                font=('Arial', 18, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        notebook = ttk.Notebook(self.content_area)
        notebook.pack(expand=True, fill='both', padx=20, pady=10)
        
        patient_queue_tab = tk.Frame(notebook, bg='white')
        notebook.add(patient_queue_tab, text="Patient Queue")
        self.create_patient_queue_tab(patient_queue_tab)
        
        medical_records_tab = tk.Frame(notebook, bg='white')
        notebook.add(medical_records_tab, text="Medical Records List")
        self.create_medical_records_tab(medical_records_tab)
        
        # Create Document tab removed as requested
    
    def create_patient_queue_tab(self, parent):
        """Create patient queue tab content"""
        search_frame = tk.Frame(parent, bg='white')
        search_frame.pack(pady=10, fill='x', padx=10)
        
        tk.Label(search_frame, text="Search:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
        search_entry = tk.Entry(search_frame, font=('Arial', 11), width=20)
        search_entry.pack(side='left', padx=5)
        
        columns = ('Control No.', 'SR-Code', 'Name', 'Year', 'Program', 'Status', 'Time')
        tree = ttk.Treeview(parent, columns=columns, show='headings', height=12)
        
        col_widths = {'Control No.': 130, 'SR-Code': 100, 'Name': 150, 'Year': 80, 'Program': 80, 'Status': 100, 'Time': 130}
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=col_widths.get(col, 100))
        
        for patient in self.patients:
            tree.insert('', tk.END, values=(
                patient['control_number'],
                patient['sr_code'],
                patient['name'],
                patient['year'],
                patient['program'],
                patient.get('status', 'Waiting'),
                patient['timestamp']
            ))
        
        tree.pack(pady=10, padx=10, fill='both', expand=True)
        
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        scrollbar.pack(side='right', fill='y')
        tree.configure(yscrollcommand=scrollbar.set)
        
        action_frame = tk.Frame(parent, bg='white')
        action_frame.pack(pady=15)
        
        def search_queue():
            search_term = search_entry.get().lower()
            for item in tree.get_children():
                tree.delete(item)
            
            for patient in self.patients:
                if search_term in patient['control_number'].lower() or search_term in patient['name'].lower() or search_term in patient['sr_code'].lower():
                    tree.insert('', tk.END, values=(
                        patient['control_number'],
                        patient['sr_code'],
                        patient['name'],
                        patient['year'],
                        patient['program'],
                        patient.get('status', 'Waiting'),
                        patient['timestamp']
                    ))
        
        def start_consultation():
            selected = tree.selection()
            if selected:
                item = tree.item(selected[0])
                control_no = item['values'][0]
                
                for patient in self.patients:
                    if patient['control_number'] == control_no:
                        patient['status'] = 'In Consultation'
                        break
                
                tree.item(selected[0], values=(item['values'][0], item['values'][1], item['values'][2],
                                               item['values'][3], item['values'][4], 'In Consultation',
                                               item['values'][6]))
                messagebox.showinfo("Success", "Patient status updated to 'In Consultation'")
            else:
                messagebox.showwarning("Warning", "Please select a patient")
        
        def complete_consultation():
            selected = tree.selection()
            if selected:
                item = tree.item(selected[0])
                control_no = item['values'][0]
                
                for patient in self.patients:
                    if patient['control_number'] == control_no:
                        patient['status'] = 'Completed'
                        break
                
                tree.item(selected[0], values=(item['values'][0], item['values'][1], item['values'][2],
                                               item['values'][3], item['values'][4], 'Completed',
                                               item['values'][6]))
                
                self.show_document_type_selection(control_no)
            else:
                messagebox.showwarning("Warning", "Please select a patient")
        
        tk.Button(action_frame, text="🔍 Search", command=search_queue,
                 bg=self.batstateu_colors['info'], fg='white',
                 font=('Arial', 10), padx=10, pady=5).pack(side='left', padx=5)
        
        tk.Button(action_frame, text="▶ Start Consultation", command=start_consultation,
                 bg=self.batstateu_colors['warning'], fg='black',
                 font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)
        
        tk.Button(action_frame, text="✓ Complete & Create Document", command=complete_consultation,
                 bg=self.batstateu_colors['success'], fg='white',
                 font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)
    
    def create_medical_records_tab(self, parent):
        """Create medical records list tab content"""
        search_frame = tk.Frame(parent, bg='white')
        search_frame.pack(pady=10, fill='x', padx=10)
        
        tk.Label(search_frame, text="Search by Control No. or Name:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
        search_entry = tk.Entry(search_frame, font=('Arial', 11), width=20)
        search_entry.pack(side='left', padx=5)
        
        columns = ('Control No.', 'Patient Name', 'SR-Code', 'Symptoms', 'Temperature', 'Status', 'Date')
        tree = ttk.Treeview(parent, columns=columns, show='headings', height=12)
        
        col_widths = {'Control No.': 120, 'Patient Name': 150, 'SR-Code': 100, 'Symptoms': 120, 'Temperature': 80, 'Status': 100, 'Date': 130}
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=col_widths.get(col, 100))
        
        for record in self.medical_records:
            symptoms_str = ', '.join(record['symptoms'][:2])
            if len(record['symptoms']) > 2:
                symptoms_str += f" +{len(record['symptoms']) - 2}"
            
            tree.insert('', tk.END, values=(
                record['control_number'],
                record['patient_name'],
                record['sr_code'],
                symptoms_str,
                record.get('temperature', 'N/A'),
                record['status'],
                record['submission_date']
            ))
        
        tree.pack(pady=10, padx=10, fill='both', expand=True)
        
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        scrollbar.pack(side='right', fill='y')
        tree.configure(yscrollcommand=scrollbar.set)
        
        def search_records():
            search_term = search_entry.get().lower()
            for item in tree.get_children():
                tree.delete(item)
            
            for record in self.medical_records:
                if search_term in record['control_number'].lower() or search_term in record['patient_name'].lower():
                    symptoms_str = ', '.join(record['symptoms'][:2])
                    if len(record['symptoms']) > 2:
                        symptoms_str += f" +{len(record['symptoms']) - 2}"
                    
                    tree.insert('', tk.END, values=(
                        record['control_number'],
                        record['patient_name'],
                        record['sr_code'],
                        symptoms_str,
                        record.get('temperature', 'N/A'),
                        record['status'],
                        record['submission_date']
                    ))
        
        def view_record_details():
            selected = tree.selection()
            if selected:
                item = tree.item(selected[0])
                control_no = item['values'][0]
                self.view_medical_record_detail(control_no)
            else:
                messagebox.showwarning("Warning", "Please select a record")
        
        tk.Button(search_frame, text="🔍 Search", command=search_records,
                 bg=self.batstateu_colors['info'], fg='white',
                 font=('Arial', 10), padx=10, pady=5).pack(side='left', padx=5)
        
        tk.Button(search_frame, text="📄 View Details", command=view_record_details,
                 bg=self.batstateu_colors['primary'], fg='white',
                 font=('Arial', 10), padx=10, pady=5).pack(side='left', padx=5)
    
    # ==================== DOCUMENT CREATION (UPDATED FORMS) ====================
    
    def show_document_type_selection(self, control_no=None):
        """Popup to select document type"""
        popup = self.show_centered_popup(self.root, "Select Document Type", 400, 250)
        
        tk.Label(popup, text="Choose Document Type", 
                font=('Arial', 16, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        if not control_no:
            tk.Label(popup, text="Control Number:", font=('Arial', 11), bg='white').pack()
            control_entry = tk.Entry(popup, font=('Arial', 11), width=25)
            control_entry.pack(pady=10)
        
        def select_doc_type(doc_type):
            if not control_no:
                control_no_val = control_entry.get()
                if not control_no_val:
                    messagebox.showerror("Error", "Please enter control number")
                    return
            else:
                control_no_val = control_no
            
            popup.destroy()
            self.show_document_creation_form(control_no_val, doc_type)
        
        button_frame = tk.Frame(popup, bg='white')
        button_frame.pack(pady=30)
        
        tk.Button(button_frame, text="📋 Medical Certificate", 
                 command=lambda: select_doc_type("Medical Certificate"),
                 bg=self.batstateu_colors['primary'], fg='white',
                 font=('Arial', 11, 'bold'), padx=20, pady=10,
                 cursor='hand2').pack(side='left', padx=10)
        
        tk.Button(button_frame, text="🔬 Medical Examination Form", 
                 command=lambda: select_doc_type("Medical Examination Form"),
                 bg=self.batstateu_colors['secondary'], fg=self.batstateu_colors['primary'],
                 font=('Arial', 11, 'bold'), padx=20, pady=10,
                 cursor='hand2').pack(side='left', padx=10)
    
    def show_document_creation_form(self, control_no, document_type):
        """Display document creation form with updated fields based on requirements"""
        patient_data = None
        medical_record = None
        
        for patient in self.patients:
            if patient['control_number'] == control_no:
                patient_data = patient
                break
        
        for record in self.medical_records:
            if record['control_number'] == control_no:
                medical_record = record
                break
        
        if not patient_data:
            messagebox.showerror("Error", "Patient not found for this control number")
            return
        
        popup = self.show_centered_popup(self.root, f"Create {document_type}", 800, 750)
        
        main_frame = tk.Frame(popup, bg='white')
        main_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        canvas = tk.Canvas(main_frame, bg='white')
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg='white')
        
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Header
        header_frame = tk.Frame(scrollable_frame, bg='white')
        header_frame.pack(pady=10)
        
        tk.Label(header_frame, text="Republic of the Philippines", 
                font=('Arial', 12), bg='white').pack()
        tk.Label(header_frame, text="BATANGAS STATE UNIVERSITY", 
                font=('Arial', 18, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack()
        tk.Label(header_frame, text="The National Engineering University", 
                font=('Arial', 10, 'italic'), bg='white', fg='gray').pack()
        tk.Label(header_frame, text="ARASOF - Nasugbu Campus", 
                font=('Arial', 11), bg='white').pack()
        
        tk.Label(scrollable_frame, text=document_type.upper(), 
                font=('Arial', 16, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=10)
        
        tk.Label(scrollable_frame, text=f"Control No.: {control_no}", 
                font=('Arial', 11), bg='white', 
                fg=self.batstateu_colors['info']).pack()
        
        current_date = datetime.now().strftime('%B %d, %Y')
        tk.Label(scrollable_frame, text=f"Date: {current_date}", 
                font=('Arial', 11), bg='white').pack()
        
        # Get patient details
        if medical_record:
            full_name = medical_record.get('patient_name', patient_data['name'])
            age = medical_record.get('age', '')
            sex = medical_record.get('sex', '')
            civil_status = medical_record.get('civil_status', '')
            address = medical_record.get('address', '')
            purpose = medical_record.get('purpose', '')
            height = medical_record.get('height', '')
            weight = medical_record.get('weight', '')
            last_name = medical_record.get('last_name', '')
            first_name = medical_record.get('first_name', '')
            middle_name = medical_record.get('middle_name', '')
        else:
            full_name = patient_data['name']
            name_parts = full_name.split()
            last_name = name_parts[-1] if len(name_parts) > 1 else ''
            first_name = name_parts[0] if name_parts else ''
            middle_name = ''
            age = ''
            sex = ''
            civil_status = ''
            address = ''
            purpose = ''
            height = ''
            weight = ''
        
        entries = {}
        
        if document_type == "Medical Certificate":
            # Medical Certificate with auto-filled fields
            cert_frame = tk.LabelFrame(scrollable_frame, text="MEDICAL CERTIFICATE", 
                                       font=('Arial', 12, 'bold'), bg='white')
            cert_frame.pack(fill='x', pady=10, padx=10)
            
            # Auto-filled display
            auto_frame = tk.Frame(cert_frame, bg='white')
            auto_frame.pack(fill='x', padx=10, pady=10)
            
            auto_fields = [
                ("Control No.:", control_no),
                ("Date:", current_date),
                ("Name:", full_name),
                ("Age:", age),
                ("Sex:", sex),
                ("Civil Status:", civil_status),
                ("Address:", address),
                ("Purpose:", purpose if purpose else "N/A"),
            ]
            
            for i, (label, value) in enumerate(auto_fields):
                row = i // 2
                col = i % 2
                tk.Label(auto_frame, text=label, font=('Arial', 10, 'bold'), 
                        bg='white').grid(row=row, column=col*2, sticky='w', padx=5, pady=3)
                tk.Label(auto_frame, text=value, font=('Arial', 10), 
                        bg='white', fg='gray').grid(row=row, column=col*2+1, sticky='w', padx=5, pady=3)
            
            # Dropdown for Diagnosis
            diag_frame = tk.Frame(cert_frame, bg='white')
            diag_frame.pack(fill='x', padx=10, pady=5)
            tk.Label(diag_frame, text="Diagnosis:", font=('Arial', 11, 'bold'), 
                    bg='white').pack(side='left')
            diagnosis_var = tk.StringVar(value="Normal")
            diagnosis_combo = ttk.Combobox(diag_frame, textvariable=diagnosis_var, 
                                           values=['Normal', 'Not Normal'], width=15, state='readonly')
            diagnosis_combo.pack(side='left', padx=10)
            entries['Diagnosis'] = diagnosis_var
            
            # Dropdown for Remarks
            remarks_frame = tk.Frame(cert_frame, bg='white')
            remarks_frame.pack(fill='x', padx=10, pady=5)
            tk.Label(remarks_frame, text="Remarks:", font=('Arial', 11, 'bold'), 
                    bg='white').pack(side='left')
            remarks_var = tk.StringVar(value="Fit to work")
            remarks_combo = ttk.Combobox(remarks_frame, textvariable=remarks_var, 
                                         values=['Fit to work', 'Not fit to work'], width=15, state='readonly')
            remarks_combo.pack(side='left', padx=10)
            entries['Remarks'] = remarks_var
            
            # VARCHAR fields
            varchar_frame = tk.Frame(cert_frame, bg='white')
            varchar_frame.pack(fill='x', padx=10, pady=10)
            
            tk.Label(varchar_frame, text="Attending Physician:", font=('Arial', 11, 'bold'), 
                    bg='white').pack(side='left')
            physician_entry = tk.Entry(varchar_frame, font=('Arial', 11), width=25)
            physician_entry.pack(side='left', padx=10)
            physician_entry.insert(0, "RIAL JUBENA DE LEON, MD")
            entries['Attending Physician'] = physician_entry
            
            tk.Label(varchar_frame, text="License No.:", font=('Arial', 11, 'bold'), 
                    bg='white').pack(side='left', padx=(20,5))
            license_entry = tk.Entry(varchar_frame, font=('Arial', 11), width=15)
            license_entry.pack(side='left')
            license_entry.insert(0, "0138371")
            entries['License No.'] = license_entry
        
        else:  # Medical Examination Form
            exam_frame = tk.LabelFrame(scrollable_frame, text="MEDICAL EXAMINATION FORM", 
                                       font=('Arial', 12, 'bold'), bg='white')
            exam_frame.pack(fill='x', pady=10, padx=10)
            
            # Auto-filled fields
            auto_frame = tk.Frame(exam_frame, bg='white')
            auto_frame.pack(fill='x', padx=10, pady=10)
            
            auto_fields = [
                ("Last Name:", last_name),
                ("First Name:", first_name),
                ("Middle Name:", middle_name),
                ("Sex:", sex),
                ("Address:", address),
                ("Date:", current_date),
                ("Civil Status:", civil_status),
                ("Age:", age),
                ("Height (cm):", height),
                ("Weight (kg):", weight),
            ]
            
            for i, (label, value) in enumerate(auto_fields):
                row = i // 2
                col = i % 2
                tk.Label(auto_frame, text=label, font=('Arial', 10, 'bold'), 
                        bg='white').grid(row=row, column=col*2, sticky='w', padx=5, pady=3)
                tk.Label(auto_frame, text=value if value else "N/A", font=('Arial', 10), 
                        bg='white', fg='gray').grid(row=row, column=col*2+1, sticky='w', padx=5, pady=3)
            
            # Date fields
            date_frame = tk.LabelFrame(exam_frame, text="Dates", font=('Arial', 11, 'bold'), bg='white')
            date_frame.pack(fill='x', padx=10, pady=10)
            
            tk.Label(date_frame, text="Birthday:", font=('Arial', 10), bg='white').grid(row=0, column=0, padx=5, pady=5)
            birthday_entry = tk.Entry(date_frame, font=('Arial', 10), width=15)
            birthday_entry.grid(row=0, column=1, padx=5, pady=5)
            entries['Birthday'] = birthday_entry
            
            tk.Label(date_frame, text="Date of Examination:", font=('Arial', 10), bg='white').grid(row=0, column=2, padx=5, pady=5)
            doe_entry = tk.Entry(date_frame, font=('Arial', 10), width=15)
            doe_entry.insert(0, current_date)
            doe_entry.grid(row=0, column=3, padx=5, pady=5)
            entries['Date of Examination'] = doe_entry
            
            tk.Label(date_frame, text="LMP:", font=('Arial', 10), bg='white').grid(row=0, column=4, padx=5, pady=5)
            lmp_entry = tk.Entry(date_frame, font=('Arial', 10), width=15)
            lmp_entry.grid(row=0, column=5, padx=5, pady=5)
            entries['LMP'] = lmp_entry
            
            # VARCHAR fields
            varchar_frame = tk.LabelFrame(exam_frame, text="Additional Information", font=('Arial', 11, 'bold'), bg='white')
            varchar_frame.pack(fill='x', padx=10, pady=10)
            
            varchar_fields = [
                ("Tel No.:", tk.Entry(varchar_frame, width=20)),
                ("Cellphone No.:", tk.Entry(varchar_frame, width=20)),
                ("Finding:", tk.Entry(varchar_frame, width=30)),
                ("Blood Pressure:", tk.Entry(varchar_frame, width=15)),
                ("Attending Physician:", tk.Entry(varchar_frame, width=30)),
                ("License No.:", tk.Entry(varchar_frame, width=15)),
            ]
            
            for i, (label, widget) in enumerate(varchar_fields):
                row = i // 2
                col = (i % 2) * 2
                tk.Label(varchar_frame, text=label, font=('Arial', 10, 'bold'), 
                        bg='white').grid(row=row, column=col, sticky='w', padx=5, pady=5)
                widget.grid(row=row, column=col+1, padx=5, pady=5, sticky='w')
                entries[label] = widget
            
            # Set default values
            entries["Attending Physician:"].insert(0, "RIAL JUBENA DE LEON, MD")
            entries["License No.:"].insert(0, "0138371")
            
            # Past Medical History (Text)
            pmh_frame = tk.Frame(exam_frame, bg='white')
            pmh_frame.pack(fill='x', padx=10, pady=5)
            tk.Label(pmh_frame, text="Past Medical History:", font=('Arial', 10, 'bold'), 
                    bg='white').pack(anchor='w')
            pmh_text = tk.Text(pmh_frame, height=3, width=60, font=('Arial', 10))
            pmh_text.pack(fill='x', pady=5)
            entries['Past Medical History'] = pmh_text
            
            # Family History with subfields
            fh_frame = tk.Frame(exam_frame, bg='white')
            fh_frame.pack(fill='x', padx=10, pady=5)
            tk.Label(fh_frame, text="Family History:", font=('Arial', 10, 'bold'), 
                    bg='white').pack(anchor='w')
            
            fh_subframe = tk.Frame(fh_frame, bg='white')
            fh_subframe.pack(fill='x', pady=5)
            
            tk.Label(fh_subframe, text="Mother:", font=('Arial', 10), bg='white').grid(row=0, column=0, padx=5, pady=2)
            mother_entry = tk.Entry(fh_subframe, width=20)
            mother_entry.grid(row=0, column=1, padx=5, pady=2)
            
            tk.Label(fh_subframe, text="Father:", font=('Arial', 10), bg='white').grid(row=0, column=2, padx=5, pady=2)
            father_entry = tk.Entry(fh_subframe, width=20)
            father_entry.grid(row=0, column=3, padx=5, pady=2)
            
            tk.Label(fh_subframe, text="Sibling/s:", font=('Arial', 10), bg='white').grid(row=1, column=0, padx=5, pady=2)
            siblings_entry = tk.Entry(fh_subframe, width=20)
            siblings_entry.grid(row=1, column=1, padx=5, pady=2)
            
            entries['Family History - Mother'] = mother_entry
            entries['Family History - Father'] = father_entry
            entries['Family History - Siblings'] = siblings_entry
            
            # Occupational History
            oh_frame = tk.Frame(exam_frame, bg='white')
            oh_frame.pack(fill='x', padx=10, pady=5)
            tk.Label(oh_frame, text="Occupational History:", font=('Arial', 10, 'bold'), 
                    bg='white').pack(anchor='w')
            oh_text = tk.Text(oh_frame, height=2, width=60, font=('Arial', 10))
            oh_text.pack(fill='x', pady=5)
            entries['Occupational History'] = oh_text
            
            # Dropdown boxes (Check/X) for Normal row and diagnostic exam
            normal_frame = tk.LabelFrame(exam_frame, text="Normal Findings (Check ✓ or X)", font=('Arial', 11, 'bold'), bg='white')
            normal_frame.pack(fill='x', padx=10, pady=10)
            
            normal_items = [
                "General Appearance/Body Built (BMI)", "Skin (Tattoo)", "Head and Scalp", "Eyes (External)",
                "Ears (Piercing)", "Nose and Throat", "Mouth", "Neck, Thyroid, LN", "Chest, Breast, Axilla",
                "Heart", "Lungs", "Abdomen", "Anus, Rectum", "Musculo-Skeletal", "Extremities"
            ]
            
            normal_vars = {}
            normal_grid = tk.Frame(normal_frame, bg='white')
            normal_grid.pack(padx=10, pady=10)
            
            for i, item in enumerate(normal_items):
                var = tk.StringVar(value="✓")
                row = i // 3
                col = i % 3
                frame = tk.Frame(normal_grid, bg='white')
                frame.grid(row=row, column=col, sticky='w', padx=10, pady=3)
                tk.Label(frame, text=item, font=('Arial', 9), bg='white').pack(side='left')
                ttk.Combobox(frame, textvariable=var, values=['✓', '✗'], width=3, state='readonly').pack(side='left', padx=5)
                normal_vars[item] = var
            entries['Normal Findings'] = normal_vars
            
            # Diagnostic Exam boxes
            diag_exam_frame = tk.LabelFrame(exam_frame, text="Diagnostic Examination", font=('Arial', 11, 'bold'), bg='white')
            diag_exam_frame.pack(fill='x', padx=10, pady=10)
            
            diag_items = [
                "Hepa B Screening", "Chest X-Ray", "Drug Test (Methamphetamine)", 
                "Drug Test (Tetrahydrocannabinol)", "Complete Blood Count", "Routine Urinalysis"
            ]
            
            diag_vars = {}
            diag_grid = tk.Frame(diag_exam_frame, bg='white')
            diag_grid.pack(padx=10, pady=10)
            
            for i, item in enumerate(diag_items):
                var = tk.StringVar(value="✓")
                row = i // 2
                col = (i % 2) * 2
                frame = tk.Frame(diag_grid, bg='white')
                frame.grid(row=row, column=col, sticky='w', padx=10, pady=3)
                tk.Label(frame, text=item, font=('Arial', 9), bg='white').pack(side='left')
                ttk.Combobox(frame, textvariable=var, values=['✓', '✗'], width=3, state='readonly').pack(side='left', padx=5)
                diag_vars[item] = var
            entries['Diagnostic Exam'] = diag_vars
        
        def save_and_view_document():
            doc_data = {
                'control_number': control_no,
                'document_type': document_type,
                'patient_name': patient_data['name'],
                'sr_code': patient_data['sr_code'],
                'created_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'nurse': self.current_user,
                'status': 'Completed',
                'editable_data': {}
            }
            
            for label, widget in entries.items():
                if isinstance(widget, tk.Text):
                    doc_data['editable_data'][label] = widget.get("1.0", tk.END).strip()
                elif isinstance(widget, tk.StringVar):
                    doc_data['editable_data'][label] = widget.get()
                elif isinstance(widget, dict):
                    # For normal findings and diagnostic exam dicts
                    doc_data['editable_data'][label] = {k: v.get() for k, v in widget.items()}
                else:
                    doc_data['editable_data'][label] = widget.get()
            
            doc_data['patient_info'] = {
                'name': full_name,
                'age': age,
                'sex': sex,
                'civil_status': civil_status,
                'address': address,
                'purpose': purpose,
                'height': height,
                'weight': weight,
                'last_name': last_name,
                'first_name': first_name,
                'middle_name': middle_name
            }
            
            self.medical_documents.append(doc_data)
            
            for patient in self.patients:
                if patient['control_number'] == control_no:
                    patient['status'] = 'Completed'
                    break
            
            popup.destroy()
            self.show_view_document(doc_data)
        
        button_frame = tk.Frame(scrollable_frame, bg='white')
        button_frame.pack(pady=20)
        
        tk.Button(button_frame, text="Save & View Document", 
                 command=save_and_view_document,
                 bg=self.batstateu_colors['success'], fg='white',
                 font=('Arial', 12, 'bold'), padx=20, pady=10,
                 cursor='hand2').pack()
    
    def show_view_document(self, document):
        """Display the completed document with proper formatting"""
        popup = self.show_centered_popup(self.root, "View Document", 800, 700)
        
        main_frame = tk.Frame(popup, bg='white')
        main_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        canvas = tk.Canvas(main_frame, bg='white')
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg='white')
        
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        print_frame = tk.Frame(popup, bg='white')
        print_frame.pack(fill='x', padx=20, pady=(10, 0))
        
        def print_document():
            messagebox.showinfo("Print", "Document sent to printer!")
            document['status'] = 'Printed'
            popup.destroy()
            self.show_combined_medical_records()
        
        tk.Button(print_frame, text="🖨️ Print Document", 
                 command=print_document,
                 bg=self.batstateu_colors['primary'], fg='white',
                 font=('Arial', 11, 'bold'), padx=15, pady=5,
                 cursor='hand2').pack(side='right')
        
        # Header
        header_frame = tk.Frame(scrollable_frame, bg='white')
        header_frame.pack(pady=20)
        
        tk.Label(header_frame, text="Republic of the Philippines", 
                font=('Arial', 11), bg='white').pack()
        tk.Label(header_frame, text="BATANGAS STATE UNIVERSITY", 
                font=('Arial', 18, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack()
        tk.Label(header_frame, text="The National Engineering University", 
                font=('Arial', 10, 'italic'), bg='white', fg='gray').pack()
        tk.Label(header_frame, text="ARASOF - Nasugbu Campus", 
                font=('Arial', 11), bg='white').pack()
        
        tk.Label(header_frame, text=f"\n{document['document_type'].upper()}", 
                font=('Arial', 14, 'bold'), bg='white', 
                fg=self.batstateu_colors['dark']).pack(pady=10)
        
        tk.Label(scrollable_frame, text=f"Control No.: {document['control_number']}", 
                font=('Arial', 10), bg='white', fg='gray').pack()
        tk.Label(scrollable_frame, text=f"Date Issued: {document['created_date']}", 
                font=('Arial', 10), bg='white', fg='gray').pack()
        
        # Patient Info
        info_frame = tk.LabelFrame(scrollable_frame, text="Patient Information", 
                                   font=('Arial', 11, 'bold'), bg='white')
        info_frame.pack(fill='x', pady=10, padx=20)
        
        patient_info = document.get('patient_info', {})
        info_text = f"Name: {patient_info.get('name', document['patient_name'])}\n"
        info_text += f"Age: {patient_info.get('age', 'N/A')} | Sex: {patient_info.get('sex', 'N/A')} | Civil Status: {patient_info.get('civil_status', 'N/A')}\n"
        info_text += f"Address: {patient_info.get('address', 'N/A')}\n"
        info_text += f"Purpose: {patient_info.get('purpose', 'N/A')}"
        
        tk.Label(info_frame, text=info_text, font=('Arial', 10), 
                bg='white', justify='left').pack(anchor='w', padx=10, pady=10)
        
        # Document Content
        content_frame = tk.LabelFrame(scrollable_frame, text="Document Content", 
                                      font=('Arial', 11, 'bold'), bg='white')
        content_frame.pack(fill='x', pady=10, padx=20)
        
        content_text = ""
        for label, value in document['editable_data'].items():
            if value:
                if isinstance(value, dict):
                    content_text += f"\n{label}:\n"
                    for k, v in value.items():
                        content_text += f"  {k}: {v}\n"
                else:
                    content_text += f"\n{label}\n{value}\n{'-'*60}\n"
        
        if content_text:
            tk.Label(content_frame, text=content_text, font=('Arial', 10), 
                    bg='white', justify='left', wraplength=700).pack(anchor='w', padx=10, pady=5)
        
        # Signature
        sig_frame = tk.Frame(scrollable_frame, bg='white')
        sig_frame.pack(fill='x', pady=20, padx=20)
        
        tk.Label(sig_frame, text="_________________________", font=('Arial', 10), 
                bg='white').pack()
        physician = document.get('editable_data', {}).get('Attending Physician', 
                   document.get('editable_data', {}).get('Examining Physician', 'Attending Physician'))
        tk.Label(sig_frame, text=physician, font=('Arial', 9, 'bold'), bg='white').pack()
        tk.Label(sig_frame, text="Attending Physician", font=('Arial', 9), bg='white').pack()
        
        license_no = document.get('editable_data', {}).get('License No.', '0138371')
        tk.Label(sig_frame, text=f"License No.: {license_no}", font=('Arial', 9), bg='white').pack()
        
        if document['document_type'] == "Medical Certificate":
            tk.Label(scrollable_frame, text="Note: This medical certificate is issued upon request of the patient and for the stated purpose only, and not for medico-legal purposes.", 
                    font=('Arial', 8, 'italic'), bg='white', fg='red', wraplength=700).pack(pady=10, padx=20)
        
        footer_frame = tk.Frame(scrollable_frame, bg='white')
        footer_frame.pack(fill='x', pady=20)
        
        tk.Label(footer_frame, text="This is a computer-generated document. No signature is required.", 
                font=('Arial', 8), bg='white', fg='gray').pack()
    
    def view_medical_record_detail(self, control_no):
        """View detailed medical record"""
        record = None
        for r in self.medical_records:
            if r['control_number'] == control_no:
                record = r
                break
        
        if not record:
            messagebox.showerror("Error", "Record not found")
            return
        
        detail_window = self.show_centered_popup(self.root, f"Medical Record - {control_no}", 600, 700)
        
        tk.Label(detail_window, text="Medical Record Details", 
                font=('Arial', 16, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        info_frame = tk.Frame(detail_window, bg='white')
        info_frame.pack(pady=20, padx=30, fill='both', expand=True)
        
        details = [
            ("Control Number:", record['control_number']),
            ("Patient Name:", record['patient_name']),
            ("SR-Code:", record['sr_code']),
            ("Year:", record.get('year', 'N/A')),
            ("Program:", record.get('program', 'N/A')),
            ("Submission Date:", record['submission_date']),
            ("Status:", record['status']),
            ("Temperature:", record.get('temperature', 'N/A')),
            ("Blood Pressure:", record.get('blood_pressure', 'N/A')),
            ("Allergies:", record.get('allergies', 'None')),
            ("Symptoms:", ', '.join(record['symptoms']) if record['symptoms'] else 'None'),
            ("Other Symptoms:", record.get('other_symptoms', 'None')),
            ("Medical History:", record.get('medical_history', 'None')),
        ]
        
        for i, (label, value) in enumerate(details):
            tk.Label(info_frame, text=label, font=('Arial', 11, 'bold'), 
                    bg='white').grid(row=i, column=0, sticky='w', pady=5, padx=10)
            tk.Label(info_frame, text=str(value), font=('Arial', 11), 
                    bg='white', wraplength=350, justify='left').grid(row=i, column=1, sticky='w', pady=5, padx=10)
        
        def update_status(new_status):
            record['status'] = new_status
            messagebox.showinfo("Success", f"Status updated to {new_status}")
            detail_window.destroy()
            self.show_combined_medical_records()
        
        status_frame = tk.Frame(detail_window, bg='white')
        status_frame.pack(pady=20)
        
        tk.Button(status_frame, text="Mark as In Progress", 
                 command=lambda: update_status("In Progress"),
                 bg=self.batstateu_colors['warning'], fg='black',
                 font=('Arial', 11)).pack(side='left', padx=5)
        
        tk.Button(status_frame, text="Mark as Completed", 
                 command=lambda: update_status("Completed"),
                 bg=self.batstateu_colors['success'], fg='white',
                 font=('Arial', 11)).pack(side='left', padx=5)
    
    # ==================== REPORTS SECTION ====================
    
    def show_reports(self):
        """Display reports"""
        self.clear_content_area()
        
        tk.Label(self.content_area, text="Reports & Analytics", 
                font=('Arial', 18, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        notebook = ttk.Notebook(self.content_area)
        notebook.pack(expand=True, fill='both', padx=20, pady=10)
        
        patient_report_tab = tk.Frame(notebook, bg='white')
        notebook.add(patient_report_tab, text="Patient Reports")
        self.create_patient_reports_tab(patient_report_tab)
        
        inventory_report_tab = tk.Frame(notebook, bg='white')
        notebook.add(inventory_report_tab, text="Inventory Reports")
        self.create_inventory_reports_tab(inventory_report_tab)
        
        medical_report_tab = tk.Frame(notebook, bg='white')
        notebook.add(medical_report_tab, text="Medical Records Report")
        self.create_medical_reports_tab(medical_report_tab)
    
    def create_patient_reports_tab(self, parent):
        """Create patient reports tab"""
        report_frame = tk.Frame(parent, bg='white')
        report_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        stats_frame = tk.Frame(report_frame, bg='white')
        stats_frame.pack(fill='x', pady=10)
        
        today_visits = len([s for s in self.patients if s['timestamp'].startswith(datetime.now().strftime('%Y-%m-%d'))])
        pending = len([r for r in self.medical_records if r['status'] == 'Pending'])
        completed = len([r for r in self.medical_records if r['status'] == 'Completed'])
        
        stats = [
            ("Today's Visits", today_visits, self.batstateu_colors['info']),
            ("Pending Cases", pending, self.batstateu_colors['warning']),
            ("Completed Cases", completed, self.batstateu_colors['success']),
        ]
        
        for i, (label, value, color) in enumerate(stats):
            card = tk.Frame(stats_frame, bg=color, width=180, height=100, relief='raised', borderwidth=1)
            card.grid(row=0, column=i, padx=10, pady=10)
            card.pack_propagate(False)
            
            tk.Label(card, text=label, font=('Arial', 11), bg=color, fg='white').pack(pady=10)
            tk.Label(card, text=str(value), font=('Arial', 24, 'bold'), bg=color, fg='white').pack()
        
        def generate_daily_report():
            report_text = f"""
            ========== DAILY PATIENT REPORT ==========
            Date: {datetime.now().strftime('%Y-%m-%d')}
            
            Total Check-ins Today: {today_visits}
            Pending Medical Forms: {pending}
            Completed Consultations: {completed}
            
            Patient List:
            """
            for patient in self.patients:
                if patient['timestamp'].startswith(datetime.now().strftime('%Y-%m-%d')):
                    report_text += f"\n  - {patient['name']} ({patient['sr_code']}) - {patient['status']}"
            
            report_window = self.show_centered_popup(parent, "Daily Report", 500, 400)
            text_area = ScrolledText(report_window, wrap=tk.WORD, width=60, height=20)
            text_area.pack(padx=10, pady=10, fill='both', expand=True)
            text_area.insert('1.0', report_text)
            text_area.configure(state='disabled')
        
        tk.Button(report_frame, text="📊 Generate Daily Report", 
                 command=generate_daily_report,
                 bg=self.batstateu_colors['primary'], fg='white',
                 font=('Arial', 12, 'bold'), padx=20, pady=10).pack(pady=20)
    
    def create_inventory_reports_tab(self, parent):
        """Create inventory reports tab"""
        report_frame = tk.Frame(parent, bg='white')
        report_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        low_stock_frame = tk.LabelFrame(report_frame, text="LOW STOCK ITEMS (Below 50 units)", 
                                        font=('Arial', 12, 'bold'), bg='white', fg='red')
        low_stock_frame.pack(fill='x', pady=10)
        
        low_stock_items = [item for item in self.inventory_items if not item.get('deleted', False) and item['quantity'] < 50]
        
        if low_stock_items:
            for item in low_stock_items:
                item_frame = tk.Frame(low_stock_frame, bg='#ffeeee')
                item_frame.pack(fill='x', padx=10, pady=5)
                
                tk.Label(item_frame, text=f"⚠️ {item['name']}", font=('Arial', 10, 'bold'), 
                        bg='#ffeeee', fg='red').pack(side='left', padx=10)
                tk.Label(item_frame, text=f"Quantity: {item['quantity']} {item['unit']}", 
                        font=('Arial', 10), bg='#ffeeee').pack(side='left', padx=20)
                tk.Label(item_frame, text=f"Expiry: {item['expiry_date']}", 
                        font=('Arial', 10), bg='#ffeeee').pack(side='left', padx=20)
        else:
            tk.Label(low_stock_frame, text="No low stock items", 
                    font=('Arial', 11), bg='white', fg='green').pack(pady=20)
        
        inventory_summary_frame = tk.LabelFrame(report_frame, text="Inventory Summary", 
                                                font=('Arial', 12, 'bold'), bg='white')
        inventory_summary_frame.pack(fill='x', pady=10)
        
        total_items = len([i for i in self.inventory_items if not i.get('deleted', False)])
        total_quantity = sum(i['quantity'] for i in self.inventory_items if not i.get('deleted', False))
        total_value = sum(i['quantity'] * i.get('price', 0) for i in self.inventory_items if not i.get('deleted', False))
        
        summary_text = f"""
        Total Items in Inventory: {total_items}
        Total Units in Stock: {total_quantity}
        Total Inventory Value: ₱{total_value:.2f}
        Items Expiring Within 6 Months: {len([i for i in self.inventory_items if i['expiry_date'] != 'N/A' and not i.get('deleted', False)])}
        """
        
        tk.Label(inventory_summary_frame, text=summary_text, font=('Arial', 11), 
                bg='white', justify='left').pack(anchor='w', padx=10, pady=10)
        
        def generate_inventory_report():
            report_text = f"""
            ========== INVENTORY REPORT ==========
            Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            Generated by: {self.current_user}
            
            --- LOW STOCK ITEMS ---
            """
            for item in low_stock_items:
                report_text += f"\n  - {item['name']}: {item['quantity']} {item['unit']} (Expires: {item['expiry_date']})"
            
            report_text += "\n\n--- ALL ITEMS ---"
            for item in self.inventory_items:
                if not item.get('deleted', False):
                    price = item.get('price', 0)
                    report_text += f"\n  - {item['name']}: {item['quantity']} {item['unit']} | Price: ₱{price:.2f} | Status: {item['status']}"
            
            report_text += "\n\n--- TRANSACTION HISTORY SUMMARY ---"
            report_text += f"\nTotal Transactions: {len(self.inventory_history)}"
            
            action_counts = defaultdict(int)
            for record in self.inventory_history:
                action_counts[record['action']] += 1
            
            for action, count in action_counts.items():
                report_text += f"\n  - {action}: {count}"
            
            report_window = self.show_centered_popup(parent, "Inventory Report", 600, 500)
            text_area = ScrolledText(report_window, wrap=tk.WORD, width=70, height=25)
            text_area.pack(padx=10, pady=10, fill='both', expand=True)
            text_area.insert('1.0', report_text)
            text_area.configure(state='disabled')
        
        tk.Button(report_frame, text="📊 Generate Full Inventory Report", 
                 command=generate_inventory_report,
                 bg=self.batstateu_colors['info'], fg='white',
                 font=('Arial', 11, 'bold'), padx=15, pady=8).pack(pady=10)
    
    def create_medical_reports_tab(self, parent):
        """Create medical records report tab"""
        report_frame = tk.Frame(parent, bg='white')
        report_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        range_frame = tk.Frame(report_frame, bg='white')
        range_frame.pack(fill='x', pady=10)
        
        tk.Label(range_frame, text="Date Range (YYYY-MM-DD):", font=('Arial', 11), bg='white').pack(side='left', padx=5)
        
        from_entry = tk.Entry(range_frame, width=12, font=('Arial', 11))
        from_entry.pack(side='left', padx=5)
        from_entry.insert(0, datetime.now().strftime('%Y-%m-01'))
        
        tk.Label(range_frame, text="to", font=('Arial', 11), bg='white').pack(side='left', padx=5)
        
        to_entry = tk.Entry(range_frame, width=12, font=('Arial', 11))
        to_entry.pack(side='left', padx=5)
        to_entry.insert(0, datetime.now().strftime('%Y-%m-%d'))
        
        stats_frame = tk.Frame(report_frame, bg='white')
        stats_frame.pack(fill='x', pady=20)
        
        total_records = len(self.medical_records)
        pending = len([r for r in self.medical_records if r['status'] == 'Pending'])
        in_progress = len([r for r in self.medical_records if r['status'] == 'In Progress'])
        completed = len([r for r in self.medical_records if r['status'] == 'Completed'])
        
        stats = [
            ("Total Records", total_records, self.batstateu_colors['primary']),
            ("Pending", pending, self.batstateu_colors['warning']),
            ("In Progress", in_progress, self.batstateu_colors['info']),
            ("Completed", completed, self.batstateu_colors['success']),
        ]
        
        stats_inner = tk.Frame(stats_frame, bg='white')
        stats_inner.pack()
        
        for i, (label, value, color) in enumerate(stats):
            card = tk.Frame(stats_inner, bg=color, width=130, height=80, relief='raised', borderwidth=1)
            card.grid(row=0, column=i, padx=5, pady=5)
            card.pack_propagate(False)
            
            tk.Label(card, text=label, font=('Arial', 10), bg=color, fg='white').pack(pady=5)
            tk.Label(card, text=str(value), font=('Arial', 18, 'bold'), bg=color, fg='white').pack()
        
        def generate_medical_report():
            from_dt = from_entry.get()
            to_dt = to_entry.get()
            
            filtered_records = [r for r in self.medical_records 
                               if from_dt <= r['submission_date'][:10] <= to_dt]
            
            report_text = f"""
            ========== MEDICAL RECORDS REPORT ==========
            Date Range: {from_dt} to {to_dt}
            Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            
            --- SUMMARY ---
            Total Medical Records: {len(filtered_records)}
            Pending: {len([r for r in filtered_records if r['status'] == 'Pending'])}
            In Progress: {len([r for r in filtered_records if r['status'] == 'In Progress'])}
            Completed: {len([r for r in filtered_records if r['status'] == 'Completed'])}
            
            --- COMMON SYMPTOMS ---
            """
            
            symptom_count = {}
            for record in filtered_records:
                for symptom in record['symptoms']:
                    symptom_count[symptom] = symptom_count.get(symptom, 0) + 1
            
            for symptom, count in sorted(symptom_count.items(), key=lambda x: x[1], reverse=True)[:5]:
                report_text += f"\n  - {symptom}: {count} cases"
            
            report_text += "\n\n--- RECORDS LIST ---"
            for record in filtered_records:
                report_text += f"\n  - {record['submission_date'][:10]} | {record['patient_name']} | {record['status']}"
            
            report_window = self.show_centered_popup(parent, "Medical Records Report", 600, 500)
            text_area = ScrolledText(report_window, wrap=tk.WORD, width=70, height=25)
            text_area.pack(padx=10, pady=10, fill='both', expand=True)
            text_area.insert('1.0', report_text)
            text_area.configure(state='disabled')
        
        tk.Button(report_frame, text="📊 Generate Medical Records Report", 
                 command=generate_medical_report,
                 bg=self.batstateu_colors['success'], fg='white',
                 font=('Arial', 12, 'bold'), padx=20, pady=10).pack(pady=20)
    
    def show_nurse_dashboard_content(self):
        """Display dashboard content"""
        self.clear_content_area()
        
        tk.Label(self.content_area, text="Welcome to the Clinic Management System", 
                font=('Arial', 20, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        stats_frame = tk.Frame(self.content_area, bg='white')
        stats_frame.pack(pady=30)
        
        pending_count = len([r for r in self.medical_records if r['status'] == 'Pending'])
        waiting_count = len([s for s in self.patients if s.get('status') == 'Waiting'])
        today_visits = len([s for s in self.patients if s['timestamp'].startswith(datetime.now().strftime('%Y-%m-%d'))])
        completed = len([s for s in self.patients if s.get('status') == 'Completed'])
        
        stats = [
            ("Today's Visits", today_visits, self.batstateu_colors['info']),
            ("Waiting Patients", waiting_count, self.batstateu_colors['warning']),
            ("Pending Forms", pending_count, self.batstateu_colors['danger']),
            ("Completed", completed, self.batstateu_colors['success']),
        ]
        
        for i, (label, value, color) in enumerate(stats):
            card = tk.Frame(stats_frame, bg=color, width=200, height=120, relief='raised', borderwidth=1)
            card.grid(row=0, column=i, padx=10, pady=10)
            card.pack_propagate(False)
            
            tk.Label(card, text=label, font=('Arial', 12), bg=color, 
                    fg='white').pack(pady=10)
            tk.Label(card, text=str(value), font=('Arial', 28, 'bold'), bg=color, 
                    fg='white').pack()
        
        tk.Label(self.content_area, text="Quick Actions", 
                font=('Arial', 16, 'bold'), bg='white', 
                fg=self.batstateu_colors['primary']).pack(pady=20)
        
        quick_actions_frame = tk.Frame(self.content_area, bg='white')
        quick_actions_frame.pack()
        
        actions = [
            ("📋 Medical Records", self.show_combined_medical_records),
            ("📄 Create Document", lambda: self.show_document_type_selection()),
            ("📦 Inventory", self.show_inventory_home),
            ("🛒 Cart History", self.show_cart_history),
            ("👨‍🎓 Student Records", self.show_student_records),
            ("📊 Reports", self.show_reports),
        ]
        
        for i, (action, command) in enumerate(actions):
            btn = tk.Button(quick_actions_frame, text=action, 
                          bg=self.batstateu_colors['secondary'],
                          fg=self.batstateu_colors['primary'],
                          font=('Arial', 11, 'bold'), width=25, height=2,
                          cursor='hand2', command=command)
            btn.grid(row=i//2, column=i%2, padx=10, pady=10)
    
    def clear_content_area(self):
        """Clear the nurse content area"""
        if hasattr(self, 'content_area'):
            for widget in self.content_area.winfo_children():
                widget.destroy()

# Main execution
if __name__ == "__main__":
    root = tk.Tk()
    app = ClinicManagementSystem(root)
    root.mainloop()