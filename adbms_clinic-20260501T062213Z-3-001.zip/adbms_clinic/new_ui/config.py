# config.py
# Color scheme and application constants

BATSTATEU_COLORS = {
    'primary': '#800000',      # Maroon
    'secondary': '#FFD1DC',    # Light pink
    'bg': '#f5f5f5',
    'white': '#ffffff',
    'text': '#333333',
    'success': '#28a745',
    'danger': '#dc3545',
    'warning': '#ffc107',
    'info': '#17a2b8',
    'dark': '#2c3e50'
}

YEAR_LEVELS = [
    '1st Year',
    '2nd Year',
    '3rd Year',
    '4th Year',
    '5th Year',
]

PROGRAMS = [
    'BSIT',
    'BSCS',
    'BSIS',
    'BSEMC',
    'BSECE',
    'BSME',
    'BSCE',
    'BSEE',
]

SYMPTOMS = [
    'Fever',
    'Cough',
    'Headache',
    'Nausea',
    'Fatigue',
    'Sore throat',
    'Difficulty breathing',
    'Body pain',
    'Cold',
    'Diarrhea',
]
