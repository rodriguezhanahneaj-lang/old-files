# data_manager.py
from datetime import datetime

def add_history_record(self, item_id, item_name, action, details, quantity_change=0):
    """Add a record to inventory transaction history"""
    history_record = {
        'id': len(self.inventory_history) + 1,
        'item_id': item_id,
        'item_name': item_name,
        'action': action,
        'details': details,
        'quantity_change': quantity_change,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'user': self.current_user if self.current_user else 'System'
    }
    self.inventory_history.append(history_record)

def load_sample_inventory(self):
    """Load sample inventory items with history records"""
    self.inventory_items = [
        {'id': '001', 'name': 'Paracetamol', 'quantity': 500, 'unit': 'tablets', 
         'status': 'In Stock', 'expiry_date': '2025-12-31', 'manufacturing_date': '2023-01-15', 
         'deleted': False, 'description': 'Pain reliever and fever reducer', 'price': 5.00},
        {'id': '002', 'name': 'Bandages', 'quantity': 50, 'unit': 'boxes', 
         'status': 'Low Stock ⚠️', 'expiry_date': '2026-06-30', 'manufacturing_date': '2024-01-10',
         'deleted': False, 'description': 'Sterile gauze bandages', 'price': 25.00},
        {'id': '003', 'name': 'Ethyl Alcohol', 'quantity': 120, 'unit': 'bottles', 
         'status': 'In Stock', 'expiry_date': '2025-10-15', 'manufacturing_date': '2024-02-20',
         'deleted': False, 'description': '70% Isopropyl Alcohol', 'price': 45.00},
        {'id': '004', 'name': 'Gauze Pads', 'quantity': 30, 'unit': 'packs', 
         'status': 'Low Stock ⚠️', 'expiry_date': '2026-03-20', 'manufacturing_date': '2024-01-05',
         'deleted': False, 'description': 'Sterile gauze pads 4x4', 'price': 15.00},
        {'id': '005', 'name': 'Digital Thermometer', 'quantity': 15, 'unit': 'pieces', 
         'status': 'In Stock', 'expiry_date': 'N/A', 'manufacturing_date': '2023-06-10',
         'deleted': False, 'description': 'Digital oral thermometer', 'price': 120.00},
        {'id': '006', 'name': 'Face Mask', 'quantity': 200, 'unit': 'pieces', 
         'status': 'In Stock', 'expiry_date': '2025-12-31', 'manufacturing_date': '2024-03-01',
         'deleted': False, 'description': 'Surgical face mask', 'price': 3.00},
        {'id': '007', 'name': 'Vitamin C', 'quantity': 80, 'unit': 'tablets', 
         'status': 'In Stock', 'expiry_date': '2025-08-15', 'manufacturing_date': '2024-01-20',
         'deleted': False, 'description': 'Immune booster', 'price': 8.00},
    ]
    # Add initial history records
    for item in self.inventory_items:
        self.add_history_record(
            item['id'], 
            item['name'],
            'CREATE', 
            f"Initial stock added: {item['quantity']} {item['unit']}",
            item['quantity']
        )

def load_sample_nurse(self):
    """Load a sample nurse account for testing"""
    self.nurses.append({
        'name': 'Sample Nurse',
        'emp_id': 'NURSE001',
        'email': 'nurse@batstateu.edu.ph',
        'username': 'nurse',
        'password': 'nurse123',
        'created_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })

def load_sample_student_records(self):
    """Load sample student records for testing"""
    self.student_records = [
        {'sr_code': '20-01234', 'full_name': 'Juan Dela Cruz', 'year': '3rd Year', 'program': 'BSIT', 'checkin_counts': 5},
        {'sr_code': '20-05678', 'full_name': 'Maria Santos', 'year': '2nd Year', 'program': 'BSCS', 'checkin_counts': 3},
        {'sr_code': '21-09012', 'full_name': 'Jose Rizal', 'year': '1st Year', 'program': 'BSIS', 'checkin_counts': 1},
    ]