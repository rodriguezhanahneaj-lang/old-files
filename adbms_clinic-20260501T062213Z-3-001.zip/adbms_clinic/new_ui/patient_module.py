"""Patient check-in and medical form handlers."""

import tkinter as tk
from datetime import datetime
from tkinter import messagebox, ttk

from config import BATSTATEU_COLORS, PROGRAMS, SYMPTOMS, YEAR_LEVELS
from backend.patient_checkin import patient_checkin
from utils import clear_window, show_centered_popup


def show_patient_checkin(self):
    """Display the patient check-in screen."""
    clear_window(self.root)

    header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=80)
    header_frame.pack(fill='x')
    header_frame.pack_propagate(False)

    tk.Label(
        header_frame,
        text="PATIENT CHECK-IN",
        font=('Arial', 18, 'bold'),
        bg=self.batstateu_colors['primary'],
        fg='white',
    ).pack(side='left', padx=20, pady=20)

    tk.Button(
        header_frame,
        text="Back to Role Selection",
        bg='white',
        fg=self.batstateu_colors['primary'],
        font=('Arial', 10),
        cursor='hand2',
        command=self.show_role_selection,
    ).pack(side='right', padx=20, pady=20)

    main_frame = tk.Frame(self.root, bg=self.batstateu_colors['bg'])
    main_frame.pack(expand=True, fill='both', padx=50, pady=30)

    form_frame = tk.Frame(main_frame, bg='white', relief='solid', borderwidth=1)
    form_frame.pack(pady=30, ipadx=50, ipady=30)

    tk.Label(
        form_frame,
        text="Patient Check-in Form",
        font=('Arial', 20, 'bold'),
        bg='white',
        fg=self.batstateu_colors['primary'],
    ).pack(pady=20)

    fields_frame = tk.Frame(form_frame, bg='white')
    fields_frame.pack(pady=20)

    tk.Label(fields_frame, text="SR-Code:", font=('Arial', 12), bg='white').grid(
        row=0, column=0, sticky='w', pady=10, padx=10
    )
    sr_code_entry = tk.Entry(fields_frame, font=('Arial', 12), width=30, relief='solid', borderwidth=1)
    sr_code_entry.grid(row=0, column=1, pady=10, padx=10)

    tk.Label(fields_frame, text="Full Name:", font=('Arial', 12), bg='white').grid(
        row=1, column=0, sticky='w', pady=10, padx=10
    )
    name_entry = tk.Entry(fields_frame, font=('Arial', 12), width=30, relief='solid', borderwidth=1)
    name_entry.grid(row=1, column=1, pady=10, padx=10)

    tk.Label(fields_frame, text="Year Level:", font=('Arial', 12), bg='white').grid(
        row=3, column=0, sticky='w', pady=10, padx=10
    )
    year_combo = ttk.Combobox(fields_frame, font=('Arial', 12), width=28, values=YEAR_LEVELS, state='readonly')
    year_combo.grid(row=3, column=1, pady=10, padx=10)
    year_combo.set(YEAR_LEVELS[0])

    tk.Label(fields_frame, text="Program:", font=('Arial', 12), bg='white').grid(
        row=4, column=0, sticky='w', pady=10, padx=10
    )
    program_combo = ttk.Combobox(fields_frame, font=('Arial', 12), width=28, values=PROGRAMS, state='readonly')
    program_combo.grid(row=4, column=1, pady=10, padx=10)
    program_combo.set(PROGRAMS[0])

    def generate_control_number():
        sr_code = sr_code_entry.get().strip()
        full_name = name_entry.get().strip()
        year = year_combo.get()
        program = program_combo.get()

        if not sr_code or not full_name:
            messagebox.showerror("Error", "Please fill in SR-Code and Name fields")
            return

        success, result = patient_checkin(sr_code, full_name.upper(), year, program)
        if not success:
            messagebox.showerror("Error", result)
            return

        control_num = result
        qr_data = f"BATSTATEU-CLINIC|{control_num}|{sr_code}|{full_name}"
        self.qr_codes[control_num] = qr_data

        student_found = False
        for student in self.student_records:
            if student['sr_code'] == sr_code:
                student['checkin_counts'] += 1
                student_found = True
                break

        if not student_found:
            self.student_records.append(
                {
                    'sr_code': sr_code,
                    'full_name': full_name,
                    'year': year,
                    'program': program,
                    'checkin_counts': 1,
                }
            )

        patient_data = {
            'sr_code': sr_code,
            'name': full_name,
            'year': year,
            'program': program,
            'control_number': control_num,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'Waiting',
        }
        self.patients.append(patient_data)

        popup = show_centered_popup(self.root, "Check-in Successful", 500, 450)

        success_frame = tk.Frame(popup, bg='white')
        success_frame.pack(expand=True, fill='both', pady=30)

        tk.Label(
            success_frame,
            text="Check-in Successful",
            font=('Arial', 20, 'bold'),
            bg='white',
            fg=self.batstateu_colors['success'],
        ).pack(pady=(0, 10))

        tk.Label(success_frame, text="Your Control Number is:", font=('Arial', 12), bg='white').pack()
        tk.Label(
            success_frame,
            text=control_num,
            font=('Arial', 24, 'bold'),
            bg='white',
            fg=self.batstateu_colors['primary'],
        ).pack(pady=10)

        qr_frame = tk.Frame(success_frame, bg='#f0f0f0', width=100, height=100, relief='solid', borderwidth=1)
        qr_frame.pack(pady=10)
        qr_frame.pack_propagate(False)
        tk.Label(
            qr_frame,
            text="[QR CODE]\nScan to access\nmedical form",
            font=('Arial', 8),
            bg='#f0f0f0',
        ).pack(expand=True)

        button_frame_popup = tk.Frame(popup, bg='white')
        button_frame_popup.pack(pady=20)

        tk.Button(
            button_frame_popup,
            text="Fill Medical Form",
            bg=self.batstateu_colors['secondary'],
            fg=self.batstateu_colors['primary'],
            font=('Arial', 11, 'bold'),
            width=18,
            cursor='hand2',
            command=lambda: [popup.destroy(), self.show_medical_form(patient_data)],
        ).pack(side='left', padx=5)

        tk.Button(
            popup,
            text="Close",
            bg=self.batstateu_colors['primary'],
            fg='white',
            font=('Arial', 12, 'bold'),
            width=15,
            command=popup.destroy,
        ).pack(pady=15)

        sr_code_entry.delete(0, tk.END)
        name_entry.delete(0, tk.END)
        year_combo.set(YEAR_LEVELS[0])
        program_combo.set(PROGRAMS[0])

    tk.Button(
        form_frame,
        text="CHECK-IN",
        bg=self.batstateu_colors['primary'],
        fg='white',
        font=('Arial', 14, 'bold'),
        width=20,
        height=2,
        cursor='hand2',
        command=generate_control_number,
    ).pack(pady=20)


def show_medical_form(self, patient_data):
    """Display the medical form for a checked-in patient."""
    self.clear_window()

    header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=80)
    header_frame.pack(fill='x')
    header_frame.pack_propagate(False)

    tk.Label(
        header_frame,
        text="MEDICAL FORM",
        font=('Arial', 18, 'bold'),
        bg=self.batstateu_colors['primary'],
        fg='white',
    ).pack(side='left', padx=20, pady=20)

    tk.Label(
        header_frame,
        text=f"Control No: {patient_data['control_number']}",
        font=('Arial', 12),
        bg=self.batstateu_colors['primary'],
        fg=self.batstateu_colors['secondary'],
    ).pack(side='right', padx=20, pady=20)

    canvas = tk.Canvas(self.root, bg=self.batstateu_colors['bg'])
    scrollbar = ttk.Scrollbar(self.root, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas, bg=self.batstateu_colors['bg'])

    scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    control_frame = tk.LabelFrame(
        scrollable_frame,
        text="CONTROL NUMBER",
        font=('Arial', 12, 'bold'),
        bg=self.batstateu_colors['bg'],
        fg='red',
    )
    control_frame.pack(fill=tk.X, padx=20, pady=10)

    control_info_frame = tk.Frame(control_frame, bg=self.batstateu_colors['bg'])
    control_info_frame.pack(pady=10, padx=20)

    tk.Label(
        control_info_frame,
        text=f"Control Number: {patient_data['control_number']}",
        font=('Arial', 12, 'bold'),
        bg=self.batstateu_colors['bg'],
        fg=self.batstateu_colors['primary'],
    ).pack(anchor='w')
    tk.Label(
        control_info_frame,
        text="Format: ALxx-xxxx or ALxx-xxx (e.g AL26-1234)",
        font=('Arial', 9),
        bg=self.batstateu_colors['bg'],
        fg='gray',
    ).pack(anchor='w')
    tk.Label(
        control_info_frame,
        text="Please take note of your own control number. Thank you.",
        font=('Arial', 9, 'italic'),
        bg=self.batstateu_colors['bg'],
        fg='red',
    ).pack(anchor='w')

    basic_frame = tk.LabelFrame(
        scrollable_frame,
        text="BASIC INFORMATION",
        font=('Arial', 12, 'bold'),
        bg=self.batstateu_colors['bg'],
    )
    basic_frame.pack(fill=tk.X, padx=20, pady=10)

    entries = {}
    name_parts = patient_data['name'].split()
    name_fields = [
        ("LAST NAME *", "last_name_entry"),
        ("FIRST NAME *", "first_name_entry"),
        ("MIDDLE NAME", "middle_name_entry"),
    ]

    for label, key in name_fields:
        row_frame = tk.Frame(basic_frame, bg=self.batstateu_colors['bg'])
        row_frame.pack(fill=tk.X, pady=5, padx=20)

        tk.Label(
            row_frame,
            text=label,
            font=('Arial', 11),
            bg=self.batstateu_colors['bg'],
            width=15,
            anchor='w',
        ).pack(side='left')

        entry = tk.Entry(row_frame, font=('Arial', 11), width=40)
        entry.pack(side='left', padx=10)
        entries[key] = entry

        if key == "last_name_entry" and name_parts:
            entry.insert(0, name_parts[-1] if len(name_parts) > 1 else name_parts[0])
        elif key == "first_name_entry" and name_parts:
            entry.insert(0, name_parts[0])
        elif key == "middle_name_entry":
            tk.Label(
                row_frame,
                text="Leave it blank if does not apply",
                font=('Arial', 8),
                bg=self.batstateu_colors['bg'],
                fg='gray',
            ).pack(side='left', padx=10)

    demographics_frame = tk.Frame(basic_frame, bg=self.batstateu_colors['bg'])
    demographics_frame.pack(fill=tk.X, pady=10, padx=20)

    tk.Label(demographics_frame, text="AGE *", font=('Arial', 11), bg=self.batstateu_colors['bg']).grid(
        row=0, column=0, sticky='w', padx=5, pady=5
    )
    age_entry = tk.Entry(demographics_frame, font=('Arial', 11), width=15)
    age_entry.grid(row=0, column=1, padx=5, pady=5)
    entries['age_entry'] = age_entry

    tk.Label(demographics_frame, text="SEX *", font=('Arial', 11), bg=self.batstateu_colors['bg']).grid(
        row=0, column=2, sticky='w', padx=(20, 5), pady=5
    )
    sex_var = tk.StringVar(value="Male")
    sex_frame = tk.Frame(demographics_frame, bg=self.batstateu_colors['bg'])
    sex_frame.grid(row=0, column=3, padx=5, pady=5)
    tk.Radiobutton(sex_frame, text="Male", variable=sex_var, value="Male", bg=self.batstateu_colors['bg']).pack(side='left')
    tk.Radiobutton(sex_frame, text="Female", variable=sex_var, value="Female", bg=self.batstateu_colors['bg']).pack(side='left')
    entries['sex_var'] = sex_var

    tk.Label(demographics_frame, text="CIVIL STATUS *", font=('Arial', 11), bg=self.batstateu_colors['bg']).grid(
        row=0, column=4, sticky='w', padx=(20, 5), pady=5
    )
    civil_var = tk.StringVar(value="Single")
    civil_frame = tk.Frame(demographics_frame, bg=self.batstateu_colors['bg'])
    civil_frame.grid(row=0, column=5, padx=5, pady=5)
    tk.Radiobutton(civil_frame, text="Single", variable=civil_var, value="Single", bg=self.batstateu_colors['bg']).pack(side='left')
    tk.Radiobutton(civil_frame, text="Married", variable=civil_var, value="Married", bg=self.batstateu_colors['bg']).pack(side='left')
    entries['civil_var'] = civil_var

    address_frame = tk.Frame(basic_frame, bg=self.batstateu_colors['bg'])
    address_frame.pack(fill=tk.X, pady=5, padx=20)
    tk.Label(
        address_frame,
        text="ADDRESS *",
        font=('Arial', 11),
        bg=self.batstateu_colors['bg'],
        width=15,
        anchor='w',
    ).pack(side='left')
    address_entry = tk.Entry(address_frame, font=('Arial', 11), width=60)
    address_entry.pack(side='left', padx=10)
    entries['address_entry'] = address_entry

    measurements_frame = tk.Frame(basic_frame, bg=self.batstateu_colors['bg'])
    measurements_frame.pack(fill=tk.X, pady=5, padx=20)
    tk.Label(measurements_frame, text="HEIGHT *", font=('Arial', 11), bg=self.batstateu_colors['bg']).pack(side='left', padx=5)
    height_entry = tk.Entry(measurements_frame, font=('Arial', 11), width=15)
    height_entry.pack(side='left', padx=5)
    tk.Label(measurements_frame, text="(cm)", font=('Arial', 9), bg=self.batstateu_colors['bg']).pack(side='left')
    tk.Label(measurements_frame, text="WEIGHT *", font=('Arial', 11), bg=self.batstateu_colors['bg']).pack(side='left', padx=(20, 5))
    weight_entry = tk.Entry(measurements_frame, font=('Arial', 11), width=15)
    weight_entry.pack(side='left', padx=5)
    tk.Label(measurements_frame, text="(kg)", font=('Arial', 9), bg=self.batstateu_colors['bg']).pack(side='left')
    entries['height_entry'] = height_entry
    entries['weight_entry'] = weight_entry

    purpose_frame = tk.LabelFrame(
        scrollable_frame,
        text="PURPOSE OF MEDICAL EXAMINATION",
        font=('Arial', 12, 'bold'),
        bg=self.batstateu_colors['bg'],
    )
    purpose_frame.pack(fill=tk.X, padx=20, pady=10)
    tk.Label(
        purpose_frame,
        text="Please select the purpose of your medical examination.",
        font=('Arial', 10),
        bg=self.batstateu_colors['bg'],
        fg='gray',
    ).pack(anchor='w', padx=20, pady=5)

    purpose_options = [
        "OJT Medical",
        "Pre-employment",
        "Annual Physical Examination (APE)",
        "Local-off Campus Activity",
        "International Travel / Exchange Student Program",
        "Scholarship Application",
        "Return to Work",
        "Sports Participation",
        "ROTC",
        "UCCL",
        "BUSCAA Season 26",
    ]
    purpose_var = tk.StringVar()
    purpose_grid = tk.Frame(purpose_frame, bg=self.batstateu_colors['bg'])
    purpose_grid.pack(padx=20, pady=10)

    for index, option in enumerate(purpose_options):
        row = index // 2
        col = index % 2
        tk.Radiobutton(
            purpose_grid,
            text=option,
            variable=purpose_var,
            value=option,
            bg=self.batstateu_colors['bg'],
            font=('Arial', 10),
            anchor='w',
            width=35,
        ).grid(row=row, column=col, sticky='w', padx=10, pady=3)
    entries['purpose_var'] = purpose_var

    medical_frame = tk.LabelFrame(
        scrollable_frame,
        text="MEDICAL INFORMATION",
        font=('Arial', 12, 'bold'),
        bg=self.batstateu_colors['bg'],
    )
    medical_frame.pack(fill=tk.X, padx=20, pady=10)

    tk.Label(
        medical_frame,
        text="Select Symptoms:",
        font=('Arial', 11, 'bold'),
        bg=self.batstateu_colors['bg'],
    ).pack(anchor='w', padx=20, pady=5)

    symptoms_vars = {}
    symptoms_frame = tk.Frame(medical_frame, bg=self.batstateu_colors['bg'])
    symptoms_frame.pack(padx=20, pady=5)
    for index, symptom in enumerate(SYMPTOMS):
        var = tk.BooleanVar()
        tk.Checkbutton(
            symptoms_frame,
            text=symptom,
            variable=var,
            bg=self.batstateu_colors['bg'],
            font=('Arial', 10),
        ).grid(row=index // 3, column=index % 3, sticky='w', padx=15, pady=3)
        symptoms_vars[symptom] = var

    tk.Label(
        medical_frame,
        text="Other Symptoms:",
        font=('Arial', 11, 'bold'),
        bg=self.batstateu_colors['bg'],
    ).pack(anchor='w', padx=20, pady=(10, 5))
    other_symptoms = tk.Text(medical_frame, height=3, width=50, font=('Arial', 10))
    other_symptoms.pack(padx=20, pady=5)

    vital_frame = tk.Frame(medical_frame, bg=self.batstateu_colors['bg'])
    vital_frame.pack(fill=tk.X, padx=20, pady=10)
    tk.Label(vital_frame, text="Temperature (C):", font=('Arial', 11), bg=self.batstateu_colors['bg']).pack(side='left')
    temp_entry = tk.Entry(vital_frame, font=('Arial', 11), width=10)
    temp_entry.pack(side='left', padx=10)
    tk.Label(vital_frame, text="Blood Pressure:", font=('Arial', 11), bg=self.batstateu_colors['bg']).pack(side='left', padx=(20, 5))
    bp_entry = tk.Entry(vital_frame, font=('Arial', 11), width=15)
    bp_entry.pack(side='left', padx=10)

    allergies_frame = tk.Frame(medical_frame, bg=self.batstateu_colors['bg'])
    allergies_frame.pack(fill=tk.X, padx=20, pady=5)
    tk.Label(allergies_frame, text="Allergies (if any):", font=('Arial', 11), bg=self.batstateu_colors['bg']).pack(side='left')
    allergies_entry = tk.Entry(allergies_frame, font=('Arial', 11), width=30)
    allergies_entry.pack(side='left', padx=10)

    tk.Label(
        medical_frame,
        text="Medical History / Existing Conditions:",
        font=('Arial', 11, 'bold'),
        bg=self.batstateu_colors['bg'],
    ).pack(anchor='w', padx=20, pady=(10, 5))
    medical_history = tk.Text(medical_frame, height=3, width=50, font=('Arial', 10))
    medical_history.pack(padx=20, pady=5)

    disclaimer_frame = tk.Frame(scrollable_frame, bg=self.batstateu_colors['bg'])
    disclaimer_frame.pack(fill=tk.X, padx=20, pady=10)
    tk.Label(
        disclaimer_frame,
        text="IMPORTANT NOTE:",
        font=('Arial', 9, 'bold'),
        bg=self.batstateu_colors['bg'],
        fg='red',
    ).pack(anchor='w')
    tk.Label(
        disclaimer_frame,
        text="Huwag isumite kailanman ang mga password sa pamamagitan ng Google Forms.",
        font=('Arial', 8),
        bg=self.batstateu_colors['bg'],
        fg='gray',
    ).pack(anchor='w')
    tk.Label(
        disclaimer_frame,
        text="Hindi itinaguyod o inindorso ng Google ang nilalamang ito.",
        font=('Arial', 8),
        bg=self.batstateu_colors['bg'],
        fg='gray',
    ).pack(anchor='w')

    def submit_medical_form():
        last_name = entries['last_name_entry'].get().strip()
        first_name = entries['first_name_entry'].get().strip()
        middle_name = entries['middle_name_entry'].get().strip()

        if not last_name or not first_name:
            messagebox.showerror("Error", "Last Name and First Name are required!")
            return

        full_name = f"{first_name} {last_name}"
        if middle_name:
            full_name = f"{first_name} {middle_name} {last_name}"

        selected_symptoms = [symptom for symptom, var in symptoms_vars.items() if var.get()]
        medical_record = {
            'control_number': patient_data['control_number'],
            'patient_name': full_name,
            'sr_code': patient_data['sr_code'],
            'year': patient_data['year'],
            'program': patient_data['program'],
            'last_name': last_name,
            'first_name': first_name,
            'middle_name': middle_name,
            'age': age_entry.get(),
            'sex': sex_var.get(),
            'civil_status': civil_var.get(),
            'address': address_entry.get(),
            'height': height_entry.get(),
            'weight': weight_entry.get(),
            'purpose': purpose_var.get(),
            'symptoms': selected_symptoms,
            'other_symptoms': other_symptoms.get("1.0", tk.END).strip(),
            'temperature': temp_entry.get(),
            'blood_pressure': bp_entry.get(),
            'allergies': allergies_entry.get(),
            'medical_history': medical_history.get("1.0", tk.END).strip(),
            'submission_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'Pending',
        }
        self.medical_records.append(medical_record)

        for patient in self.patients:
            if patient['control_number'] == patient_data['control_number']:
                patient['name'] = full_name
                patient['status'] = 'Medical Form Submitted'
                break

        messagebox.showinfo("Success", "Medical form submitted successfully!\nA nurse will attend to you shortly.")
        self.show_role_selection()

    def clear_form():
        entries['last_name_entry'].delete(0, tk.END)
        entries['first_name_entry'].delete(0, tk.END)
        entries['middle_name_entry'].delete(0, tk.END)
        entries['age_entry'].delete(0, tk.END)
        entries['address_entry'].delete(0, tk.END)
        entries['height_entry'].delete(0, tk.END)
        entries['weight_entry'].delete(0, tk.END)
        entries['sex_var'].set("Male")
        entries['civil_var'].set("Single")
        entries['purpose_var'].set("")
        for var in symptoms_vars.values():
            var.set(False)
        other_symptoms.delete("1.0", tk.END)
        medical_history.delete("1.0", tk.END)
        temp_entry.delete(0, tk.END)
        bp_entry.delete(0, tk.END)
        allergies_entry.delete(0, tk.END)
        messagebox.showinfo("Success", "Form has been cleared!")

    button_frame = tk.Frame(scrollable_frame, bg=self.batstateu_colors['bg'])
    button_frame.pack(pady=20)
    tk.Button(
        button_frame,
        text="SUBMIT MEDICAL FORM",
        command=submit_medical_form,
        bg=self.batstateu_colors['success'],
        fg='white',
        font=('Arial', 14, 'bold'),
        padx=30,
        pady=10,
        cursor='hand2',
    ).pack(side='left', padx=10)
    tk.Button(
        button_frame,
        text="CLEAR FORM",
        command=clear_form,
        bg=self.batstateu_colors['danger'],
        fg='white',
        font=('Arial', 12, 'bold'),
        padx=20,
        pady=10,
        cursor='hand2',
    ).pack(side='left', padx=10)
    tk.Button(
        button_frame,
        text="BACK",
        command=self.show_role_selection,
        bg=self.batstateu_colors['info'],
        fg='white',
        font=('Arial', 12, 'bold'),
        padx=20,
        pady=10,
        cursor='hand2',
    ).pack(side='left', padx=10)

    footer_frame = tk.Frame(self.root, bg=self.batstateu_colors['dark'], height=50)
    footer_frame.pack(side=tk.BOTTOM, fill=tk.X)
    footer_frame.pack_propagate(False)
    tk.Label(
        footer_frame,
        text="Please fill out all required information accurately",
        bg=self.batstateu_colors['dark'],
        fg='white',
    ).pack(pady=15)
