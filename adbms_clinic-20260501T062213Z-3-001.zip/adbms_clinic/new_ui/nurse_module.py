"""Function-based nurse authentication handlers."""

import random
import re
import time
import tkinter as tk
from datetime import datetime, timedelta
from tkinter import messagebox

from backend.email_sender import send_verification_email
from backend.nurse import nurse_login, nurse_signup, unlock_nurse
from backend.reset_email_password import change_password, confirm_otp, request_password_reset
from utils import show_centered_popup


def is_account_locked(self, username):
    """Check whether a username is still inside the local lockout window."""
    if username in self.login_attempts:
        lockout_until = self.login_attempts[username].get('lockout_until', 0)
        if lockout_until > time.time():
            remaining = int(lockout_until - time.time())
            return True, remaining
    return False, 0


def record_failed_attempt(self, username):
    """Track a failed login and return True when the account becomes locked."""
    if username not in self.login_attempts:
        self.login_attempts[username] = {'count': 0, 'lockout_until': 0}

    self.login_attempts[username]['count'] += 1
    if self.login_attempts[username]['count'] >= 3:
        self.login_attempts[username]['lockout_until'] = time.time() + 180
        self.login_attempts[username]['count'] = 0
        return True
    return False


def reset_failed_attempts(self, username):
    """Clear the local lockout state for a username."""
    if username in self.login_attempts:
        self.login_attempts[username] = {'count': 0, 'lockout_until': 0}


def _create_password_field(parent, row, label_text):
    tk.Label(parent, text=label_text, font=('Arial', 12), bg='white').grid(
        row=row, column=0, sticky='w', pady=10
    )

    container = tk.Frame(parent, bg='black', bd=1)
    container.grid(row=row, column=1, pady=10, padx=10, sticky='w')

    inner = tk.Frame(container, bg='white')
    inner.pack(fill='both', expand=True)

    entry = tk.Entry(inner, font=('Arial', 12), width=23, relief='flat', bg='white', show='*')
    entry.pack(side='left', padx=(5, 0), pady=5)

    visible = {'state': False}

    def toggle_password():
        visible['state'] = not visible['state']
        entry.config(show='' if visible['state'] else '*')
        toggle_btn.config(text='Hide' if visible['state'] else 'Show')

    toggle_btn = tk.Button(
        inner,
        text='Show',
        command=toggle_password,
        bg='white',
        relief='flat',
        bd=0,
        cursor='hand2',
    )
    toggle_btn.pack(side='right', padx=5)

    return entry


def show_nurse_login(self):
    """Display the nurse login screen."""
    self.clear_window()

    header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=80)
    header_frame.pack(fill='x')
    header_frame.pack_propagate(False)

    tk.Label(
        header_frame,
        text="NURSE LOGIN",
        font=('Arial', 18, 'bold'),
        bg=self.batstateu_colors['primary'],
        fg='white',
    ).pack(side='left', padx=20, pady=20)

    tk.Button(
        header_frame,
        text="Back to Role Selection",
        bg='white',
        fg=self.batstateu_colors['primary'],
        font=('Arial', 10),
        cursor='hand2',
        command=self.show_role_selection,
    ).pack(side='right', padx=20, pady=20)

    main_frame = tk.Frame(self.root, bg=self.batstateu_colors['bg'])
    main_frame.pack(expand=True, fill='both')

    login_frame = tk.Frame(main_frame, bg='white', relief='solid', borderwidth=1)
    login_frame.pack(pady=100, ipadx=50, ipady=30)

    tk.Label(
        login_frame,
        text="Nurse Authentication",
        font=('Arial', 20, 'bold'),
        bg='white',
        fg=self.batstateu_colors['primary'],
    ).pack(pady=20)

    fields_frame = tk.Frame(login_frame, bg='white')
    fields_frame.pack(pady=20)

    tk.Label(fields_frame, text="Username:", font=('Arial', 12), bg='white').grid(
        row=0, column=0, sticky='w', pady=10
    )
    username_entry = tk.Entry(fields_frame, font=('Arial', 12), width=25, relief='solid', borderwidth=1)
    username_entry.grid(row=0, column=1, pady=10, padx=10)

    password_entry = _create_password_field(fields_frame, 1, "Password:")

    status_label = tk.Label(login_frame, text="", font=('Arial', 10), bg='white', fg='red')
    status_label.pack()

    def login():
        username = username_entry.get().strip()
        password = password_entry.get().strip()

        if not username or not password:
            status_label.config(text="Please enter username and password.", fg='red')
            return

        locked, remaining = self.is_account_locked(username)
        if locked:
            minutes = remaining // 60
            seconds = remaining % 60
            status_label.config(text=f"Account locked. Try again in {minutes}:{seconds:02d}", fg='red')
            return

        success, msg = nurse_login(username, password)
        if success:
            self.reset_failed_attempts(username)
            self.current_user = username
            self.current_user_role = 'nurse'
            self.show_nurse_dashboard()
            return

        if msg == 'Account locked':
            self.login_attempts[username] = {'count': 0, 'lockout_until': time.time() + 180}
            status_label.config(text="Account locked. Please try again in 3 minutes.", fg='red')
            return

        if msg == 'Invalid credentials':
            locked_now = self.record_failed_attempt(username)
            if locked_now:
                unlock_nurse(username)
                status_label.config(text="Too many failed attempts. Locked for 3 minutes.", fg='red')
            else:
                attempts_left = 3 - self.login_attempts.get(username, {}).get('count', 0)
                status_label.config(text=f"Invalid credentials. {attempts_left} attempt(s) remaining.", fg='red')
            return

        status_label.config(text=msg, fg='red')

    button_frame = tk.Frame(login_frame, bg='white')
    button_frame.pack(pady=10)

    tk.Button(
        button_frame,
        text="LOGIN",
        bg=self.batstateu_colors['primary'],
        fg='white',
        font=('Arial', 12, 'bold'),
        width=12,
        cursor='hand2',
        command=login,
    ).pack(side='left', padx=5)

    tk.Button(
        button_frame,
        text="SIGN UP",
        bg=self.batstateu_colors['secondary'],
        fg=self.batstateu_colors['primary'],
        font=('Arial', 12, 'bold'),
        width=12,
        cursor='hand2',
        command=self.show_email_verification,
    ).pack(side='left', padx=5)

    forgot_label = tk.Label(
        login_frame,
        text="Forgot Password?",
        font=('Arial', 10, 'underline'),
        bg='white',
        fg=self.batstateu_colors['primary'],
        cursor='hand2',
    )
    forgot_label.pack(pady=(5, 10))
    forgot_label.bind("<Button-1>", lambda _event: self.show_forgot_password())


def show_email_verification(self):
    """Verify email before showing the registration form."""
    verify_window = show_centered_popup(self.root, "Email Verification", 450, 350)

    tk.Label(
        verify_window,
        text="Email Verification",
        font=('Arial', 18, 'bold'),
        bg='white',
        fg=self.batstateu_colors['primary'],
    ).pack(pady=20)

    tk.Label(
        verify_window,
        text="Enter your email address to receive\na verification code.",
        font=('Arial', 11),
        bg='white',
        fg='gray',
    ).pack()

    form_frame = tk.Frame(verify_window, bg='white')
    form_frame.pack(pady=30, padx=30)

    tk.Label(form_frame, text="Email Address:", font=('Arial', 11), bg='white').grid(
        row=0, column=0, sticky='w', pady=10
    )
    email_entry = tk.Entry(form_frame, width=30, font=('Arial', 11))
    email_entry.grid(row=0, column=1, pady=10, padx=10)

    code_label = tk.Label(form_frame, text="Verification Code:", font=('Arial', 11), bg='white')
    code_entry = tk.Entry(form_frame, width=30, font=('Arial', 11))

    def send_code():
        email = email_entry.get().strip()
        if not email:
            messagebox.showerror("Error", "Please enter your email address")
            return

        generated_code = str(random.randint(100000, 999999))
        self.email_verification_codes[email] = {
            'code': generated_code,
            'expires': time.time() + 120,
        }

        if not send_verification_email(email, generated_code):
            messagebox.showerror("Error", "Failed to send verification email")
            return

        code_label.grid(row=1, column=0, sticky='w', pady=10)
        code_entry.grid(row=1, column=1, pady=10, padx=10)
        messagebox.showinfo("Code Sent", f"Verification code sent to {email}")

    def verify_and_proceed():
        email = email_entry.get().strip()
        entered_code = code_entry.get().strip()
        stored_data = self.email_verification_codes.get(email)

        if not email or not entered_code:
            messagebox.showerror("Error", "Please enter both email and verification code")
            return
        if not stored_data:
            messagebox.showerror("Error", "Please request a verification code first")
            return
        if stored_data['expires'] < time.time():
            del self.email_verification_codes[email]
            messagebox.showerror("Error", "Verification code has expired. Please request a new one.")
            return
        if stored_data['code'] != entered_code:
            messagebox.showerror("Error", "Invalid verification code. Please try again.")
            return

        verify_window.destroy()
        self.show_nurse_signup_with_email(email)

    button_frame = tk.Frame(verify_window, bg='white')
    button_frame.pack(pady=20)

    tk.Button(
        button_frame,
        text="Send Code",
        bg=self.batstateu_colors['primary'],
        fg='white',
        font=('Arial', 11, 'bold'),
        width=12,
        command=send_code,
    ).pack(side='left', padx=10)

    tk.Button(
        button_frame,
        text="Verify & Continue",
        bg=self.batstateu_colors['success'],
        fg='white',
        font=('Arial', 11, 'bold'),
        width=15,
        command=verify_and_proceed,
    ).pack(side='left', padx=10)


def show_nurse_signup_with_email(self, email):
    """Display the backend-backed registration form after email verification."""
    signup_window = show_centered_popup(self.root, "Nurse Registration", 520, 620)

    tk.Label(
        signup_window,
        text="Complete Your Registration",
        font=('Arial', 18, 'bold'),
        bg='white',
        fg=self.batstateu_colors['primary'],
    ).pack(pady=20)

    form_frame = tk.Frame(signup_window, bg='white')
    form_frame.pack(pady=20, padx=50)

    first_name_entry = tk.Entry(form_frame, width=30, font=('Arial', 11))
    last_name_entry = tk.Entry(form_frame, width=30, font=('Arial', 11))
    emp_id_entry = tk.Entry(form_frame, width=30, font=('Arial', 11))
    username_entry = tk.Entry(form_frame, width=30, font=('Arial', 11))

    fields = [
        ("First Name:", first_name_entry),
        ("Last Name:", last_name_entry),
        ("Employee ID:", emp_id_entry),
        ("Username:", username_entry),
    ]

    for index, (label, widget) in enumerate(fields):
        tk.Label(form_frame, text=label, font=('Arial', 11), bg='white').grid(
            row=index, column=0, sticky='w', pady=10
        )
        widget.grid(row=index, column=1, pady=10, padx=10)

    password_entry = _create_password_field(form_frame, 4, "Password:")
    confirm_entry = _create_password_field(form_frame, 5, "Confirm Password:")

    tk.Label(form_frame, text="Email:", font=('Arial', 11), bg='white').grid(
        row=6, column=0, sticky='w', pady=10
    )
    tk.Label(form_frame, text=email, font=('Arial', 11), bg='white', fg='gray').grid(
        row=6, column=1, sticky='w', pady=10, padx=10
    )

    def register_nurse():
        first_name = first_name_entry.get().strip().upper()
        last_name = last_name_entry.get().strip().upper()
        emp_id = emp_id_entry.get().strip()
        username = username_entry.get().strip()
        password = password_entry.get().strip()
        confirm_password = confirm_entry.get().strip()

        if not all([first_name, last_name, emp_id, username, password, confirm_password]):
            messagebox.showerror("Error", "Please fill in all fields")
            return
        if password != confirm_password:
            messagebox.showerror("Error", "Passwords do not match")
            return

        errors = []
        if len(password) < 8 or len(password) > 16:
            errors.append("8 to 16 characters")
        if not any(char.isupper() for char in password):
            errors.append("At least 1 uppercase letter")
        if not any(char.isdigit() for char in password):
            errors.append("At least 1 number")
        if not re.search(r'[!@#$%^&*(),.?\":{}|<>]', password):
            errors.append("At least 1 special character")

        if errors:
            messagebox.showerror("Password Requirements Not Met", "Password must contain:\n" + "\n".join(errors))
            return

        success, msg = nurse_signup(email, username, password, first_name, last_name, emp_id)
        if not success:
            messagebox.showerror("Error", msg)
            return

        self.email_verification_codes.pop(email, None)
        messagebox.showinfo("Success", "Registration successful! Please log in.")
        signup_window.destroy()

    tk.Button(
        signup_window,
        text="Register",
        bg=self.batstateu_colors['primary'],
        fg='white',
        font=('Arial', 12, 'bold'),
        width=15,
        command=register_nurse,
    ).pack(pady=20)


def show_forgot_password(self):
    """Display the email entry screen for password reset."""
    self.clear_window()

    header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=80)
    header_frame.pack(fill='x')
    header_frame.pack_propagate(False)

    tk.Label(
        header_frame,
        text="FORGOT PASSWORD",
        font=('Arial', 18, 'bold'),
        bg=self.batstateu_colors['primary'],
        fg='white',
    ).pack(side='left', padx=20, pady=20)

    tk.Button(
        header_frame,
        text="Back to Login",
        bg='white',
        fg=self.batstateu_colors['primary'],
        font=('Arial', 10),
        cursor='hand2',
        command=self.show_nurse_login,
    ).pack(side='right', padx=20, pady=20)

    main_frame = tk.Frame(self.root, bg=self.batstateu_colors['bg'])
    main_frame.pack(expand=True, fill='both')

    card = tk.Frame(main_frame, bg='white', relief='solid', borderwidth=1)
    card.pack(pady=100, ipadx=50, ipady=30)

    tk.Label(
        card,
        text="Reset Your Password",
        font=('Arial', 18, 'bold'),
        bg='white',
        fg=self.batstateu_colors['primary'],
    ).pack(pady=20)
    tk.Label(
        card,
        text="Enter your registered email address.\nWe will send you a 6-digit OTP.",
        font=('Arial', 11),
        bg='white',
        fg='gray',
        justify='center',
    ).pack()

    fields = tk.Frame(card, bg='white')
    fields.pack(pady=20)
    tk.Label(fields, text="Email:", font=('Arial', 12), bg='white').grid(row=0, column=0, sticky='w', pady=10)
    email_entry = tk.Entry(fields, font=('Arial', 12), width=28, relief='solid', borderwidth=1)
    email_entry.grid(row=0, column=1, pady=10, padx=10)

    status_label = tk.Label(card, text="", font=('Arial', 10), bg='white', fg='red')
    status_label.pack()

    def request_otp():
        email = email_entry.get().strip()
        if not email:
            status_label.config(text="Please enter your email.", fg='red')
            return

        success, msg = request_password_reset(email)
        if success:
            self.show_verify_otp(email)
        else:
            status_label.config(text=msg, fg='red')

    tk.Button(
        card,
        text="SEND OTP",
        bg=self.batstateu_colors['primary'],
        fg='white',
        font=('Arial', 12, 'bold'),
        width=15,
        cursor='hand2',
        command=request_otp,
    ).pack(pady=10)


def show_verify_otp(self, email):
    """Display the OTP verification screen for password reset."""
    self.clear_window()

    header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=80)
    header_frame.pack(fill='x')
    header_frame.pack_propagate(False)

    tk.Label(
        header_frame,
        text="VERIFY OTP",
        font=('Arial', 18, 'bold'),
        bg=self.batstateu_colors['primary'],
        fg='white',
    ).pack(side='left', padx=20, pady=20)

    tk.Button(
        header_frame,
        text="Back",
        bg='white',
        fg=self.batstateu_colors['primary'],
        font=('Arial', 10),
        cursor='hand2',
        command=self.show_forgot_password,
    ).pack(side='right', padx=20, pady=20)

    main_frame = tk.Frame(self.root, bg=self.batstateu_colors['bg'])
    main_frame.pack(expand=True, fill='both')

    card = tk.Frame(main_frame, bg='white', relief='solid', borderwidth=1)
    card.pack(pady=100, ipadx=50, ipady=30)

    tk.Label(
        card,
        text="Enter OTP",
        font=('Arial', 18, 'bold'),
        bg='white',
        fg=self.batstateu_colors['primary'],
    ).pack(pady=20)
    tk.Label(
        card,
        text=f"A 6-digit code was sent to:\n{email}",
        font=('Arial', 11),
        bg='white',
        fg='gray',
        justify='center',
    ).pack()

    fields = tk.Frame(card, bg='white')
    fields.pack(pady=20)
    tk.Label(fields, text="OTP Code:", font=('Arial', 12), bg='white').grid(row=0, column=0, sticky='w', pady=10)
    otp_entry = tk.Entry(fields, font=('Arial', 14), width=12, relief='solid', borderwidth=1, justify='center')
    otp_entry.grid(row=0, column=1, pady=10, padx=10)

    status_label = tk.Label(card, text="", font=('Arial', 10), bg='white', fg='red')
    status_label.pack()

    def verify():
        success, msg = confirm_otp(email, otp_entry.get().strip())
        if success:
            self.show_reset_password(email)
        else:
            status_label.config(text=msg, fg='red')

    tk.Button(
        card,
        text="VERIFY OTP",
        bg=self.batstateu_colors['primary'],
        fg='white',
        font=('Arial', 12, 'bold'),
        width=15,
        cursor='hand2',
        command=verify,
    ).pack(pady=10)


def show_reset_password(self, email):
    """Display the new-password form after OTP verification."""
    self.clear_window()

    header_frame = tk.Frame(self.root, bg=self.batstateu_colors['primary'], height=80)
    header_frame.pack(fill='x')
    header_frame.pack_propagate(False)

    tk.Label(
        header_frame,
        text="RESET PASSWORD",
        font=('Arial', 18, 'bold'),
        bg=self.batstateu_colors['primary'],
        fg='white',
    ).pack(side='left', padx=20, pady=20)

    tk.Button(
        header_frame,
        text="Back",
        bg='white',
        fg=self.batstateu_colors['primary'],
        font=('Arial', 10),
        cursor='hand2',
        command=lambda: self.show_verify_otp(email),
    ).pack(side='right', padx=20, pady=20)

    main_frame = tk.Frame(self.root, bg=self.batstateu_colors['bg'])
    main_frame.pack(expand=True, fill='both')

    card = tk.Frame(main_frame, bg='white', relief='solid', borderwidth=1)
    card.pack(pady=80, ipadx=50, ipady=30)

    tk.Label(
        card,
        text="Set New Password",
        font=('Arial', 18, 'bold'),
        bg='white',
        fg=self.batstateu_colors['primary'],
    ).pack(pady=20)

    fields = tk.Frame(card, bg='white')
    fields.pack(pady=20)

    new_pass = _create_password_field(fields, 0, "New Password:")
    confirm_pass = _create_password_field(fields, 1, "Confirm Password:")

    status_label = tk.Label(card, text="", font=('Arial', 10), bg='white', fg='red')
    status_label.pack()

    def do_reset():
        success, msg = change_password(email, new_pass.get().strip(), confirm_pass.get().strip())
        if success:
            messagebox.showinfo("Success", "Password updated successfully! Please log in.")
            self.show_nurse_login()
        else:
            status_label.config(text=msg, fg='red')

    tk.Button(
        card,
        text="SAVE PASSWORD",
        bg=self.batstateu_colors['primary'],
        fg='white',
        font=('Arial', 12, 'bold'),
        width=15,
        cursor='hand2',
        command=do_reset,
    ).pack(pady=10)
