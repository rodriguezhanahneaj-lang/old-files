import tkinter as tk
from tkinter import ttk, messagebox
from tkinter.scrolledtext import ScrolledText
from datetime import datetime
import os
import sys
from utils import show_centered_popup

# Allow this module to import backend when the app is launched from either
# the project root or the new_ui folder.
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Import from backend - try to load database functions
try:
    from backend.inventory_backend import (
        get_all_inventory,
        get_inventory_transactions,
        add_inventory_item,
        update_inventory_item,
        soft_delete_inventory_item,
        use_inventory_item
    )
    BACKEND_AVAILABLE = True
    print("✓ Inventory backend imported successfully")
except ImportError as e:
    print(f"Warning: Could not import backend - {e}")
    BACKEND_AVAILABLE = False


def get_stock_status(quantity, backend_status=None):
    """Return the UI stock status, preferring a non-empty backend status."""
    if backend_status:
        return str(backend_status)
    if quantity <= 0:
        return "Out of Stock"
    if quantity < 50:
        return "Low Stock âš ï¸"
    return "In Stock"


def safe_float(value, default=0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def safe_item_id(item_id):
    try:
        return int(item_id)
    except (TypeError, ValueError):
        return None


def sync_inventory_from_db(self):
    """Refresh the screen's inventory list from inventory_backend.py."""
    db_items = load_inventory_from_db()
    if db_items is not None:
        self.inventory_items = db_items
        return True
    return False


def db_row_to_ui_item(row):
    """Convert database row to UI item format"""
    qty = int(row.get('StockQuantity', 0))
    
    return {
        'id': str(row.get('ItemID', '')),
        'name': row.get('ItemName', ''),
        'quantity': qty,
        'unit': row.get('Unit') or row.get('UnitName') or row.get('UnitOfMeasure') or 'units',
        'description': row.get('Description', ''),
        'manufacturing_date': str(row.get('ManufacturingDate', 'N/A')) if row.get('ManufacturingDate') else 'N/A',
        'expiry_date': str(row.get('ExpiryDate', 'N/A')) if row.get('ExpiryDate') else 'N/A',
        'status': get_stock_status(qty, row.get('StockStatus')),
        'price': safe_float(row.get('Price') or row.get('UnitPrice') or row.get('SellingPrice')),
        'deleted': False
    }


def load_inventory_from_db():
    """Load inventory from database"""
    if not BACKEND_AVAILABLE:
        return None
    try:
        ok, result = get_all_inventory()
    except Exception as e:
        print(f"Failed to load inventory: {e}")
        return None
    if ok:
        return [db_row_to_ui_item(r) for r in (result or [])]
    return None

def _legacy_show_inventory_home(self):
    """Display inventory home page with cart sidebar"""
    self.clear_content_area()
    if BACKEND_AVAILABLE:
        sync_inventory_from_db(self)
    
    main_container = tk.Frame(self.content_area, bg='white')
    main_container.pack(fill='both', expand=True)
    
    left_frame = tk.Frame(main_container, bg='white')
    left_frame.pack(side='left', fill='both', expand=True, padx=(0, 10))
    
    title_frame = tk.Frame(left_frame, bg='white')
    title_frame.pack(fill='x', pady=10)
    
    tk.Label(title_frame, text="INVENTORY ITEMS", 
            font=('Arial', 18, 'bold'), bg='white', 
            fg=self.batstateu_colors['primary']).pack(side='left')
    
    filter_frame = tk.Frame(left_frame, bg='#f0f0f0', height=50)
    filter_frame.pack(fill='x', pady=(0, 10))
    filter_frame.pack_propagate(False)
    
    filter_inner = tk.Frame(filter_frame, bg='#f0f0f0')
    filter_inner.pack(expand=True, pady=8)
    
    tk.Label(filter_inner, text="🔍 Search:", font=('Arial', 11), 
            bg='#f0f0f0').pack(side='left', padx=(10, 5))
    search_entry = tk.Entry(filter_inner, font=('Arial', 11), width=25)
    search_entry.pack(side='left', padx=5)
    
    tk.Label(filter_inner, text="Filter:", font=('Arial', 11), 
            bg='#f0f0f0').pack(side='left', padx=(15, 5))
    filter_combo = ttk.Combobox(filter_inner, values=['All', 'In Stock', 'Low Stock ⚠️', 'Out of Stock'], 
                                width=15, state='readonly')
    filter_combo.set('All')
    filter_combo.pack(side='left', padx=5)
    
    tree_frame = tk.Frame(left_frame, bg='white')
    tree_frame.pack(fill='both', expand=True)
    
    columns = ('ID', 'Item Name', 'Quantity', 'Unit', 'Status', 'Price', 'Expiry Date')
    tree = ttk.Treeview(tree_frame, columns=columns, show='headings', height=12)
    
    col_widths = {
        'ID': 60, 
        'Item Name': 200, 
        'Quantity': 80, 
        'Unit': 80, 
        'Status': 120, 
        'Price': 80, 
        'Expiry Date': 120
    }
    
    for col in columns:
        tree.heading(col, text=col, anchor='w')
        tree.column(col, width=col_widths.get(col, 100), anchor='w')
    
    v_scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
    v_scrollbar.pack(side='right', fill='y')
    h_scrollbar = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
    h_scrollbar.pack(side='bottom', fill='x')
    
    tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
    tree.pack(side='left', fill='both', expand=True)
    
    right_frame = tk.Frame(main_container, bg=self.batstateu_colors['secondary'], width=380)
    right_frame.pack(side='right', fill='y', padx=(10, 0))
    right_frame.pack_propagate(False)
    
    tk.Label(right_frame, text="🛒 CHECKOUT CART", 
            font=('Arial', 14, 'bold'), bg=self.batstateu_colors['secondary'],
            fg=self.batstateu_colors['primary']).pack(pady=10)
    
    cart_listbox = tk.Listbox(right_frame, font=('Arial', 10), height=10, bg='white')
    cart_listbox.pack(fill='both', expand=True, padx=10, pady=5)
    
    cart_total_label = tk.Label(right_frame, text="Total: ₱0.00", 
                               font=('Arial', 12, 'bold'), bg=self.batstateu_colors['secondary'],
                               fg=self.batstateu_colors['primary'])
    cart_total_label.pack(pady=5)
    
    cart_btn_frame = tk.Frame(right_frame, bg=self.batstateu_colors['secondary'])
    cart_btn_frame.pack(pady=5)
    
    tk.Button(cart_btn_frame, text="➕ Add to Cart", 
             bg=self.batstateu_colors['success'], fg='white',
             font=('Arial', 10, 'bold'), padx=10, cursor='hand2',
             command=lambda: self.add_to_cart(tree, cart_listbox, cart_total_label)).pack(side='left', padx=5)
    
    tk.Button(cart_btn_frame, text="❌ Remove", 
             bg=self.batstateu_colors['danger'], fg='white',
             font=('Arial', 10, 'bold'), padx=10, cursor='hand2',
             command=lambda: self.remove_from_cart(cart_listbox, cart_total_label)).pack(side='left', padx=5)
    
    tk.Button(cart_btn_frame, text="🗑 Clear Cart", 
             bg=self.batstateu_colors['warning'], fg='black',
             font=('Arial', 10, 'bold'), padx=10, cursor='hand2',
             command=lambda: self.clear_cart(cart_listbox, cart_total_label)).pack(side='left', padx=5)
    
    patient_frame = tk.LabelFrame(right_frame, text="Patient Information", 
                                  font=('Arial', 11, 'bold'), bg=self.batstateu_colors['secondary'],
                                  fg=self.batstateu_colors['primary'])
    patient_frame.pack(fill='x', padx=10, pady=10)
    
    tk.Label(patient_frame, text="Patient Name:", font=('Arial', 10), 
            bg=self.batstateu_colors['secondary']).pack(anchor='w', padx=10, pady=(10, 0))
    patient_name_entry = tk.Entry(patient_frame, font=('Arial', 10), width=30)
    patient_name_entry.pack(padx=10, pady=3)
    
    tk.Label(patient_frame, text="SR-Code:", font=('Arial', 10), 
            bg=self.batstateu_colors['secondary']).pack(anchor='w', padx=10, pady=(5, 0))
    sr_code_entry = tk.Entry(patient_frame, font=('Arial', 10), width=30)
    sr_code_entry.pack(padx=10, pady=3)
    
    tk.Label(patient_frame, text="Reason:", font=('Arial', 10), 
            bg=self.batstateu_colors['secondary']).pack(anchor='w', padx=10, pady=(5, 0))
    reason_combo = ttk.Combobox(patient_frame, 
                                values=['Medical Need', 'Clinic Use', 'Emergency', 'Research', 'Prescription'],
                                width=28, state='readonly')
    reason_combo.set('Medical Need')
    reason_combo.pack(padx=10, pady=3)
    
    tk.Button(right_frame, text="✅ CHECKOUT", 
             bg=self.batstateu_colors['success'], fg='white',
             font=('Arial', 12, 'bold'), padx=20, pady=12, cursor='hand2',
             command=lambda: self.checkout_cart(cart_listbox, cart_total_label, 
                                                 patient_name_entry, sr_code_entry, reason_combo,
                                                 refresh_inventory)).pack(pady=15)
    
    action_frame = tk.Frame(left_frame, bg='white')
    action_frame.pack(fill='x', pady=10)
    
    action_btn_style = {'font': ('Arial', 10, 'bold'), 'padx': 12, 'pady': 6, 'cursor': 'hand2'}
    
    tk.Button(action_frame, text="➕ Add New Item", 
             bg=self.batstateu_colors['success'], fg='white',
             **action_btn_style, command=lambda: self.show_add_inventory_item(refresh_inventory)).pack(side='left', padx=3)
    
    tk.Button(action_frame, text="✏️ Edit Item", 
             bg=self.batstateu_colors['warning'], fg='black',
             **action_btn_style, command=lambda: self.show_modify_inventory_item(tree, refresh_inventory)).pack(side='left', padx=3)
    
    tk.Button(action_frame, text="🗑 Delete Item", 
             bg=self.batstateu_colors['danger'], fg='white',
             **action_btn_style, command=lambda: self.soft_delete_item(tree, refresh_inventory)).pack(side='left', padx=3)
    
    tk.Button(action_frame, text="📜 View History", 
             bg=self.batstateu_colors['info'], fg='white',
             **action_btn_style, command=self.show_inventory_history).pack(side='left', padx=3)
    
    tk.Button(action_frame, text="🛒 Cart History", 
             bg=self.batstateu_colors['dark'], fg='white',
             **action_btn_style, command=self.show_cart_history).pack(side='left', padx=3)
    
    status_label = tk.Label(left_frame, text="", font=('Arial', 10), 
                            bg='white', fg='gray')
    status_label.pack(fill='x', pady=5)
    
    def refresh_inventory():
        for item in tree.get_children():
            tree.delete(item)
        
        search_term = search_entry.get().lower()
        filter_val = filter_combo.get()
        
        visible_count = 0
        low_stock_count = 0
        
        for item in self.inventory_items:
            if item.get('deleted', False):
                continue
            
            if search_term and search_term not in item['name'].lower() and search_term not in item['id']:
                continue
            
            if filter_val == 'In Stock' and item['status'] != 'In Stock':
                continue
            if filter_val == 'Low Stock ⚠️' and 'Low Stock' not in item['status']:
                continue
            if filter_val == 'Out of Stock' and item['status'] != 'Out of Stock':
                continue
            
            visible_count += 1
            if item['quantity'] < 50 and item['quantity'] > 0:
                low_stock_count += 1
            
            price = item.get('price', 0)
            
            tags = ()
            if item['quantity'] <= 0:
                tags = ('out_of_stock',)
            elif item['quantity'] < 50:
                tags = ('low_stock',)
            
            tree.insert('', tk.END, values=(
                item['id'],
                item['name'],
                item['quantity'],
                item['unit'],
                item['status'],
                f"₱{price:.2f}",
                item['expiry_date']
            ), tags=tags)
        
        tree.tag_configure('low_stock', background='#fff3cd')
        tree.tag_configure('out_of_stock', background='#f8d7da')
        
        total_active = len([i for i in self.inventory_items if not i.get('deleted', False)])
        status_label.config(text=f"Showing {visible_count} of {total_active} items | Low Stock: {low_stock_count}")
    
    search_entry.bind('<KeyRelease>', lambda e: refresh_inventory())
    filter_combo.bind('<<ComboboxSelected>>', lambda e: refresh_inventory())
    
    refresh_inventory()
    self.refresh_cart_display(cart_listbox, cart_total_label)

def _legacy_add_to_cart(self, tree, cart_listbox, cart_total_label):
    selected = tree.selection()
    if not selected:
        messagebox.showwarning("Warning", "Please select an item to add to cart")
        return
    
    item = tree.item(selected[0])
    item_id = item['values'][0]
    item_name = item['values'][1]
    available_qty = item['values'][2]
    unit = item['values'][3]
    price_str = item['values'][5].replace('₱', '')
    price_str = price_str.replace('PHP', '').replace('₱', '').strip()
    price = float(price_str) if price_str else 0
    
    qty_popup = show_centered_popup(self.root, "Enter Quantity", 300, 200)
    tk.Label(qty_popup, text=f"Item: {item_name}", font=('Arial', 12, 'bold'), 
            bg='white').pack(pady=10)
    tk.Label(qty_popup, text=f"Available: {available_qty} {unit}", 
            font=('Arial', 10), bg='white').pack()
    tk.Label(qty_popup, text="Quantity:", font=('Arial', 11), bg='white').pack(pady=10)
    qty_entry = tk.Entry(qty_popup, font=('Arial', 11), width=10)
    qty_entry.pack()
    
    def add_to_cart_confirm():
        try:
            qty = int(qty_entry.get())
            if qty <= 0:
                messagebox.showerror("Error", "Quantity must be positive")
                return
            if qty > available_qty:
                messagebox.showerror("Error", f"Insufficient stock! Only {available_qty} available")
                return
            
            for cart_item in self.cart_items:
                if cart_item['item_id'] == item_id:
                    new_qty = cart_item['quantity'] + qty
                    if new_qty > available_qty:
                        messagebox.showerror("Error", f"Cannot add {qty}. Total would exceed available stock")
                        return
                    cart_item['quantity'] = new_qty
                    break
            else:
                self.cart_items.append({
                    'item_id': item_id,
                    'name': item_name,
                    'quantity': qty,
                    'unit': unit,
                    'price': price
                })
            
            qty_popup.destroy()
            self.refresh_cart_display(cart_listbox, cart_total_label)
            messagebox.showinfo("Success", f"Added {qty} {unit} of {item_name} to cart")
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number")
    
    tk.Button(qty_popup, text="Add to Cart", command=add_to_cart_confirm,
             bg=self.batstateu_colors['success'], fg='white',
             font=('Arial', 11, 'bold')).pack(pady=15)

def remove_from_cart(self, cart_listbox, cart_total_label):
    selected = cart_listbox.curselection()
    if not selected:
        messagebox.showwarning("Warning", "Please select an item to remove")
        return
    
    index = selected[0]
    if index < len(self.cart_items):
        removed = self.cart_items.pop(index)
        self.refresh_cart_display(cart_listbox, cart_total_label)
        messagebox.showinfo("Removed", f"Removed {removed['name']} from cart")

def clear_cart(self, cart_listbox, cart_total_label):
    if self.cart_items and messagebox.askyesno("Clear Cart", "Are you sure you want to clear the entire cart?"):
        self.cart_items.clear()
        self.refresh_cart_display(cart_listbox, cart_total_label)
        messagebox.showinfo("Cart Cleared", "All items have been removed from cart")

def _legacy_refresh_cart_display(self, cart_listbox=None, cart_total_label=None):
    if cart_listbox:
        cart_listbox.delete(0, tk.END)
        total = 0
        for item in self.cart_items:
            item_total = item['quantity'] * item['price']
            total += item_total
            cart_listbox.insert(tk.END, f"{item['name']} - {item['quantity']} {item['unit']} - ₱{item_total:.2f}")
        
        if cart_total_label:
            cart_total_label.config(text=f"Total: ₱{total:.2f}")

def checkout_cart(self, cart_listbox, cart_total_label, patient_name_entry, sr_code_entry, reason_combo, refresh_callback):
    if not self.cart_items:
        messagebox.showwarning("Warning", "Cart is empty. Please add items to checkout.")
        return

    patient_name = patient_name_entry.get().strip()
    sr_code = sr_code_entry.get().strip()
    reason = reason_combo.get()

    if not patient_name or not sr_code:
        messagebox.showerror("Error", "Please enter patient name and SR-Code")
        return

    # ---- Verify stock availability FIRST ----
    checkout_possible = True
    stock_issues = []
    for cart_item in self.cart_items:
        inv_item = None
        for item in self.inventory_items:
            if item['id'] == cart_item['item_id'] and not item.get('deleted', False):
                inv_item = item
                break
        if not inv_item:
            stock_issues.append(f"❌ {cart_item['name']}: Item not found in inventory")
            checkout_possible = False
        elif cart_item['quantity'] > inv_item['quantity']:
            stock_issues.append(f"❌ {cart_item['name']}: Requested {cart_item['quantity']}, only {inv_item['quantity']} available")
            checkout_possible = False

    if not checkout_possible:
        messagebox.showerror("Insufficient Stock", "\n".join(stock_issues))
        return

    if BACKEND_AVAILABLE:
        for cart_item in self.cart_items:
            backend_id = safe_item_id(cart_item['item_id'])
            if backend_id is None:
                messagebox.showerror("Database Error", f"Invalid database item ID: {cart_item['item_id']}")
                return
            try:
                ok, msg = use_inventory_item(backend_id, sr_code, cart_item['quantity'], reason)
            except Exception as e:
                messagebox.showerror("Database Error", str(e))
                sync_inventory_from_db(self)
                refresh_callback()
                return
            if not ok:
                messagebox.showerror("Database Error", msg)
                sync_inventory_from_db(self)
                refresh_callback()
                return

    # ---- Perform checkout (deduct stock) ----
    checkout_details = []
    total_amount = 0
    for cart_item in self.cart_items:
        # find inventory item again (we already verified)
        inv_item = None
        for item in self.inventory_items:
            if item['id'] == cart_item['item_id'] and not item.get('deleted', False):
                inv_item = item
                break
        # Deduct quantity
        inv_item['quantity'] -= cart_item['quantity']
        total_amount += cart_item['quantity'] * cart_item['price']

        # Update status
        if inv_item['quantity'] < 50 and inv_item['quantity'] > 0:
            inv_item['status'] = "Low Stock ⚠️"
        elif inv_item['quantity'] <= 0:
            inv_item['status'] = "Out of Stock"
        else:
            inv_item['status'] = "In Stock"

        # Record history (safe call)
        details = f"Checked out {cart_item['quantity']} {cart_item['unit']} for {patient_name} (SR: {sr_code}) - Reason: {reason}"
        if hasattr(self, 'add_history_record'):
            self.add_history_record(inv_item['id'], inv_item['name'], 'CHECKOUT', details, -cart_item['quantity'])
        else:
            # Fallback: append directly to inventory_history (if it exists)
            if hasattr(self, 'inventory_history'):
                self.inventory_history.append({
                    'id': len(self.inventory_history) + 1,
                    'item_id': inv_item['id'],
                    'item_name': inv_item['name'],
                    'action': 'CHECKOUT',
                    'details': details,
                    'quantity_change': -cart_item['quantity'],
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'user': self.current_user if self.current_user else 'System'
                })

        checkout_details.append(f"✅ {cart_item['name']}: {cart_item['quantity']} {cart_item['unit']} - ₱{cart_item['quantity'] * cart_item['price']:.2f}")

    # ---- Save to cart history ----
    checkout_record = {
        'id': len(self.cart_history) + 1,
        'patient_name': patient_name,
        'sr_code': sr_code,
        'reason': reason,
        'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'items': [{'name': item['name'], 'quantity': item['quantity'], 
                   'unit': item['unit'], 'price': item['price'], 
                   'total': item['quantity'] * item['price']} for item in self.cart_items],
        'total_amount': total_amount,
        'nurse': self.current_user if self.current_user else 'Nurse'
    }
    self.cart_history.append(checkout_record)

    # ---- Clear cart and update UI ----
    self.cart_items.clear()
    self.refresh_cart_display(cart_listbox, cart_total_label)
    patient_name_entry.delete(0, tk.END)
    sr_code_entry.delete(0, tk.END)

    # ---- Show receipt ----
    receipt = f"========== CHECKOUT RECEIPT ==========\n"
    receipt += f"Transaction ID: {checkout_record['id']}\n"
    receipt += f"Patient: {patient_name} (SR: {sr_code})\n"
    receipt += f"Date: {checkout_record['date']}\n"
    receipt += f"Reason: {reason}\n\n"
    receipt += "Items:\n"
    for detail in checkout_details:
        receipt += f"  {detail}\n"
    receipt += f"\nTotal Amount: ₱{total_amount:.2f}\n"
    receipt += "====================================="

    receipt_popup = show_centered_popup(self.root, "Checkout Receipt", 500, 400)
    text_area = ScrolledText(receipt_popup, wrap=tk.WORD, width=60, height=20, font=('Courier', 10))
    text_area.pack(padx=10, pady=10, fill='both', expand=True)
    text_area.insert('1.0', receipt)
    text_area.configure(state='disabled')
    tk.Button(receipt_popup, text="Print Receipt", 
             bg=self.batstateu_colors['primary'], fg='white',
             font=('Arial', 11, 'bold'), command=receipt_popup.destroy).pack(pady=10)

    # ---- Refresh inventory display ----
    refresh_callback()

def show_inventory_history(self):
    history_window = show_centered_popup(self.root, "Inventory Transaction History", 800, 500)
    
    tk.Label(history_window, text="📜 INVENTORY TRANSACTION HISTORY", 
            font=('Arial', 16, 'bold'), bg='white', 
            fg=self.batstateu_colors['primary']).pack(pady=15)
    
    filter_frame = tk.Frame(history_window, bg='white')
    filter_frame.pack(pady=10, fill='x', padx=20)
    
    tk.Label(filter_frame, text="Filter by Action:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
    action_filter = ttk.Combobox(filter_frame, values=['All', 'CREATE', 'EDIT', 'CHECKOUT', 'DELETE'], width=15)
    action_filter.set('All')
    action_filter.pack(side='left', padx=5)
    
    tk.Label(filter_frame, text="Search Item:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
    search_entry = tk.Entry(filter_frame, width=20)
    search_entry.pack(side='left', padx=5)
    
    tree_frame = tk.Frame(history_window, bg='white')
    tree_frame.pack(fill='both', expand=True, padx=20, pady=10)
    
    columns = ('ID', 'Date/Time', 'Item Name', 'Action', 'Quantity Change', 'Details', 'User')
    tree = ttk.Treeview(tree_frame, columns=columns, show='headings', height=15)
    
    col_widths = {'ID': 50, 'Date/Time': 150, 'Item Name': 150, 'Action': 100, 
                  'Quantity Change': 100, 'Details': 200, 'User': 120}
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=col_widths.get(col, 100))
    
    scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
    scrollbar.pack(side='right', fill='y')
    tree.configure(yscrollcommand=scrollbar.set)
    tree.pack(side='left', fill='both', expand=True)
    
    def refresh_history():
        for item in tree.get_children():
            tree.delete(item)
        
        filter_action = action_filter.get()
        search_term = search_entry.get().lower()
        
        # Use database transactions if available
        transactions = []
        db_transactions = []
        if BACKEND_AVAILABLE:
            try:
                ok, result = get_inventory_transactions()
                if ok and result:
                    db_transactions = result
            except Exception as e:
                print(f"Failed to load inventory transactions: {e}")
        if db_transactions:
            for row in db_transactions:
                transactions.append({
                    'id': row.get('TransactionID', ''),
                    'item_name': row.get('ItemName', ''),
                    'action': 'CHECKOUT',  # All db transactions are usage/checkout
                    'quantity_change': -row.get('QuantityUsed', 0),
                    'details': row.get('Reason', ''),
                    'user': row.get('ControlID', '')
                })
        else:
            transactions = self.inventory_history
        
        for record in reversed(transactions):
            if filter_action != 'All' and record['action'] != filter_action:
                continue
            if search_term and search_term not in record['item_name'].lower():
                continue
            
            qty_change = record['quantity_change']
            qty_display = f"{'+' if qty_change > 0 else ''}{qty_change}" if qty_change != 0 else '-'
            
            tree.insert('', tk.END, values=(
                record['id'],
                record.get('timestamp', ''),
                record['item_name'],
                record['action'],
                qty_display,
                record['details'],
                record['user']
            ))
        
        total_count = len(transactions)
        summary_label.config(text=f"Total Transactions: {total_count}")
    
    action_filter.bind('<<ComboboxSelected>>', lambda e: refresh_history())
    search_entry.bind('<KeyRelease>', lambda e: refresh_history())
    
    tk.Button(filter_frame, text="🔍 Search", command=refresh_history,
             bg=self.batstateu_colors['info'], fg='white',
             font=('Arial', 10), padx=10, pady=3).pack(side='left', padx=5)
    
    tk.Button(filter_frame, text="🔄 Refresh", command=refresh_history,
             bg=self.batstateu_colors['primary'], fg='white',
             font=('Arial', 10), padx=10, pady=3).pack(side='left', padx=5)
    
    summary_label = tk.Label(history_window, text="", 
                             font=('Arial', 10), bg='white', fg='gray')
    summary_label.pack(pady=5)
    
    refresh_history()

def show_add_inventory_item(self, refresh_callback):
    popup = show_centered_popup(self.root, "Add Inventory Item", 450, 600)
    
    tk.Label(popup, text="Add New Inventory Item", 
            font=('Arial', 16, 'bold'), bg='white', 
            fg=self.batstateu_colors['primary']).pack(pady=20)
    
    form_frame = tk.Frame(popup, bg='white')
    form_frame.pack(pady=20, padx=30)
    
    fields = [
        ("Item Name:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
        ("Description:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
        ("Quantity:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
        ("Unit:", ttk.Combobox(form_frame, values=['tablets', 'bottles', 'boxes', 'pieces', 'packs', 'units'], width=27)),
        ("Price (₱):", tk.Entry(form_frame, width=30, font=('Arial', 11))),
        ("Manufacturing Date (YYYY-MM-DD):", tk.Entry(form_frame, width=30, font=('Arial', 11))),
        ("Expiry Date (YYYY-MM-DD):", tk.Entry(form_frame, width=30, font=('Arial', 11))),
    ]
    
    entries = {}
    
    for i, (label, widget) in enumerate(fields):
        tk.Label(form_frame, text=label, font=('Arial', 11), 
                bg='white').grid(row=i, column=0, sticky='w', pady=8)
        widget.grid(row=i, column=1, pady=8, padx=10, sticky='ew')
        if isinstance(widget, ttk.Combobox):
            widget.set('pieces')
        entries[label] = widget
    
    def save_item():
        name = entries.get("Item Name:").get()
        description = entries.get("Description:").get()
        quantity = entries.get("Quantity:").get()
        unit = entries.get("Unit:").get()
        price_str = entries.get("Price (₱):").get()
        manufacturing_date = entries.get("Manufacturing Date (YYYY-MM-DD):").get()
        expiry_date = entries.get("Expiry Date (YYYY-MM-DD):").get()
        
        if not name or not quantity:
            messagebox.showerror("Error", "Please fill in required fields")
            return
        
        try:
            qty = int(quantity)
            price = float(price_str) if price_str else 0
        except ValueError:
            messagebox.showerror("Error", "Quantity and Price must be numbers")
            return

        if BACKEND_AVAILABLE:
            try:
                ok, msg = add_inventory_item(name, description, qty)
            except Exception as e:
                messagebox.showerror("Database Error", str(e))
                return
            if not ok:
                messagebox.showerror("Database Error", msg)
                return
        
        new_id = str(len(self.inventory_items) + 1).zfill(3)
        
        status = "In Stock"
        if qty < 50 and qty > 0:
            status = "Low Stock ⚠️"
        elif qty <= 0:
            status = "Out of Stock"
        
        new_item = {
            'id': new_id,
            'name': name,
            'description': description,
            'quantity': qty,
            'unit': unit,
            'status': status,
            'price': price,
            'manufacturing_date': manufacturing_date if manufacturing_date else 'N/A',
            'expiry_date': expiry_date if expiry_date else 'N/A',
            'deleted': False
        }
        if not (BACKEND_AVAILABLE and sync_inventory_from_db(self)):
            self.inventory_items.append(new_item)
        elif BACKEND_AVAILABLE:
            saved_item = next((item for item in self.inventory_items if item['name'] == name and not item.get('deleted', False)), None)
            if saved_item:
                new_id = saved_item['id']
        
        self.add_history_record(new_id, name, 'CREATE', 
                               f"New item added: {qty} {unit} (Price: ₱{price:.2f})", qty)
        
        messagebox.showinfo("Success", "Item added to inventory")
        popup.destroy()
        refresh_callback()
    
    tk.Button(popup, text="Add Item", 
             bg=self.batstateu_colors['success'], fg='white',
             font=('Arial', 12, 'bold'), width=15,
             command=save_item).pack(pady=20)

def show_modify_inventory_item(self, tree, refresh_callback):
    selected = tree.selection()
    if not selected:
        messagebox.showwarning("Warning", "Please select an item to modify")
        return
    
    item = tree.item(selected[0])
    item_id = item['values'][0]
    
    inv_item = None
    for i in self.inventory_items:
        if i['id'] == item_id:
            inv_item = i
            break
    
    if not inv_item:
        messagebox.showerror("Error", "Item not found")
        return
    
    popup = show_centered_popup(self.root, f"Modify Item: {inv_item['name']}", 500, 650)
    
    tk.Label(popup, text=f"Edit Inventory Item", 
            font=('Arial', 16, 'bold'), bg='white', 
            fg=self.batstateu_colors['primary']).pack(pady=20)
    
    form_frame = tk.Frame(popup, bg='white')
    form_frame.pack(pady=20, padx=30)
    
    original_name = inv_item['name']
    original_quantity = inv_item['quantity']
    
    fields = [
        ("Item Name:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
        ("Description:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
        ("Quantity:", tk.Entry(form_frame, width=30, font=('Arial', 11))),
        ("Unit:", ttk.Combobox(form_frame, values=['tablets', 'bottles', 'boxes', 'pieces', 'packs', 'units'], width=27)),
        ("Price (₱):", tk.Entry(form_frame, width=30, font=('Arial', 11))),
        ("Manufacturing Date (YYYY-MM-DD):", tk.Entry(form_frame, width=30, font=('Arial', 11))),
        ("Expiry Date (YYYY-MM-DD):", tk.Entry(form_frame, width=30, font=('Arial', 11))),
    ]
    
    entries = {}
    
    for i, (label, widget) in enumerate(fields):
        tk.Label(form_frame, text=label, font=('Arial', 11), 
                bg='white').grid(row=i, column=0, sticky='w', pady=8)
        widget.grid(row=i, column=1, pady=8, padx=10, sticky='ew')
        
        if label == "Item Name:":
            widget.insert(0, inv_item['name'])
        elif label == "Description:":
            widget.insert(0, inv_item.get('description', ''))
        elif label == "Quantity:":
            widget.insert(0, str(inv_item['quantity']))
        elif label == "Unit:":
            widget.set(inv_item['unit'])
        elif label == "Price (₱):":
            widget.insert(0, str(inv_item.get('price', 0)))
        elif label == "Manufacturing Date (YYYY-MM-DD):":
            widget.insert(0, inv_item.get('manufacturing_date', 'N/A'))
        elif label == "Expiry Date (YYYY-MM-DD):":
            widget.insert(0, inv_item.get('expiry_date', 'N/A'))
        
        entries[label] = widget
    
    def save_modifications():
        new_name = entries.get("Item Name:").get()
        new_description = entries.get("Description:").get()
        new_quantity_str = entries.get("Quantity:").get()
        new_unit = entries.get("Unit:").get()
        new_price_str = entries.get("Price (₱):").get()
        new_manufacturing_date = entries.get("Manufacturing Date (YYYY-MM-DD):").get()
        new_expiry_date = entries.get("Expiry Date (YYYY-MM-DD):").get()
        
        if not new_name or not new_quantity_str:
            messagebox.showerror("Error", "Please fill in required fields")
            return
        
        try:
            new_quantity = int(new_quantity_str)
            new_price = float(new_price_str) if new_price_str else 0
        except ValueError:
            messagebox.showerror("Error", "Quantity and Price must be numbers")
            return
        
        changes = []
        quantity_change = new_quantity - original_quantity
        
        if new_name != original_name:
            changes.append(f"Name: '{original_name}' → '{new_name}'")
        if quantity_change != 0:
            changes.append(f"Quantity: {original_quantity} → {new_quantity} ({'+' if quantity_change > 0 else ''}{quantity_change})")
        if new_unit != inv_item['unit']:
            changes.append(f"Unit: {inv_item['unit']} → {new_unit}")
        if new_price != inv_item.get('price', 0):
            changes.append(f"Price: ₱{inv_item.get('price', 0):.2f} → ₱{new_price:.2f}")
        if new_description != inv_item.get('description', ''):
            changes.append("Description updated")

        if BACKEND_AVAILABLE:
            backend_id = safe_item_id(inv_item['id'])
            if backend_id is None:
                messagebox.showerror("Database Error", f"Invalid database item ID: {inv_item['id']}")
                return
            try:
                ok, msg = update_inventory_item(backend_id, new_name, new_description, new_quantity)
            except Exception as e:
                messagebox.showerror("Database Error", str(e))
                return
            if not ok:
                messagebox.showerror("Database Error", msg)
                return
        
        inv_item['name'] = new_name
        inv_item['description'] = new_description
        inv_item['quantity'] = new_quantity
        inv_item['unit'] = new_unit
        inv_item['price'] = new_price
        inv_item['manufacturing_date'] = new_manufacturing_date if new_manufacturing_date else 'N/A'
        inv_item['expiry_date'] = new_expiry_date if new_expiry_date else 'N/A'
        
        if new_quantity < 50 and new_quantity > 0:
            inv_item['status'] = "Low Stock ⚠️"
        elif new_quantity <= 0:
            inv_item['status'] = "Out of Stock"
        else:
            inv_item['status'] = "In Stock"
        
        if changes:
            details = "; ".join(changes)
            self.add_history_record(inv_item['id'], inv_item['name'], 'EDIT', details, quantity_change)
        else:
            self.add_history_record(inv_item['id'], inv_item['name'], 'EDIT', "No changes made", 0)
        
        messagebox.showinfo("Success", "Item updated successfully!")
        popup.destroy()
        refresh_callback()
    
    tk.Button(popup, text="Save Changes", 
             bg=self.batstateu_colors['success'], fg='white',
             font=('Arial', 12, 'bold'), width=15,
             command=save_modifications).pack(pady=20)

def soft_delete_item(self, tree, refresh_callback):
    selected = tree.selection()
    if not selected:
        messagebox.showwarning("Warning", "Please select an item to delete")
        return
    
    item = tree.item(selected[0])
    item_id = item['values'][0]
    item_name = item['values'][1]
    
    inv_item = None
    for i in self.inventory_items:
        if i['id'] == item_id:
            inv_item = i
            break
    
    if not inv_item:
        messagebox.showerror("Error", "Item not found")
        return
    
    if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete item '{item_name}'?\n\nThis will be a soft delete (item will be hidden)."):
# Try to use backend if available
        if BACKEND_AVAILABLE:
            try:
                backend_id = safe_item_id(item_id)
                if backend_id is None:
                    messagebox.showerror("Database Error", f"Invalid database item ID: {item_id}")
                    return
                ok, msg = soft_delete_inventory_item(backend_id)
                if ok:
                    # Mark as deleted in local list too
                    inv_item['deleted'] = True
                    self.add_history_record(item_id, item_name, 'DELETE', f"Item '{item_name}' was soft deleted", 0)
                    refresh_callback()
                    messagebox.showinfo("Success", f"Item '{item_name}' has been soft deleted")
                else:
                    messagebox.showerror("Database Error", msg)
                return
            except Exception as e:
                messagebox.showerror("Error", str(e))
        
        # Fallback to in-memory only
        inv_item['deleted'] = True
        self.add_history_record(item_id, item_name, 'DELETE', f"Item '{item_name}' was soft deleted", 0)
        refresh_callback()
        messagebox.showinfo("Success", f"Item '{item_name}' has been soft deleted")

def show_cart_history(self):
    if not self.cart_history:
        messagebox.showinfo("Cart History", "No checkout transactions yet.")
        return
    
    history_window = show_centered_popup(self.root, "Cart Checkout History", 900, 600)
    
    tk.Label(history_window, text="🛒 CHECKOUT HISTORY", 
            font=('Arial', 16, 'bold'), bg='white', 
            fg=self.batstateu_colors['primary']).pack(pady=15)
    
    notebook = ttk.Notebook(history_window)
    notebook.pack(expand=True, fill='both', padx=10, pady=10)
    
    summary_tab = tk.Frame(notebook, bg='white')
    notebook.add(summary_tab, text="Summary View")
    
    columns = ('ID', 'Date', 'Patient Name', 'SR-Code', 'Items Count', 'Total Amount', 'Nurse')
    tree = ttk.Treeview(summary_tab, columns=columns, show='headings', height=15)
    
    col_widths = {'ID': 50, 'Date': 150, 'Patient Name': 150, 'SR-Code': 100, 
                  'Items Count': 80, 'Total Amount': 100, 'Nurse': 120}
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=col_widths.get(col, 100))
    
    scrollbar = ttk.Scrollbar(summary_tab, orient="vertical", command=tree.yview)
    scrollbar.pack(side='right', fill='y')
    tree.configure(yscrollcommand=scrollbar.set)
    tree.pack(side='left', fill='both', expand=True)
    
    for record in reversed(self.cart_history):
        tree.insert('', tk.END, values=(
            record['id'],
            record['date'],
            record['patient_name'],
            record['sr_code'],
            len(record['items']),
            f"₱{record['total_amount']:.2f}",
            record['nurse']
        ))
    
    detail_tab = tk.Frame(notebook, bg='white')
    notebook.add(detail_tab, text="Detailed View")
    
    select_frame = tk.Frame(detail_tab, bg='white')
    select_frame.pack(pady=10, fill='x')
    
    tk.Label(select_frame, text="Select Transaction ID:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
    id_combo = ttk.Combobox(select_frame, values=[str(r['id']) for r in self.cart_history], width=10, state='readonly')
    id_combo.pack(side='left', padx=5)
    
    detail_text = ScrolledText(detail_tab, wrap=tk.WORD, width=90, height=25, font=('Courier', 10))
    detail_text.pack(padx=10, pady=10, fill='both', expand=True)
    
    def show_detail():
        selected_id = id_combo.get()
        if not selected_id:
            messagebox.showwarning("Warning", "Please select a transaction ID")
            return
        
        record = None
        for r in self.cart_history:
            if str(r['id']) == selected_id:
                record = r
                break
        
        if record:
            detail_text.delete(1.0, tk.END)
            receipt = f"========== CHECKOUT RECEIPT ==========\n"
            receipt += f"Transaction ID: {record['id']}\n"
            receipt += f"Date: {record['date']}\n"
            receipt += f"Nurse: {record['nurse']}\n"
            receipt += f"Patient: {record['patient_name']} (SR: {record['sr_code']})\n"
            receipt += f"Reason: {record['reason']}\n\n"
            receipt += "Items:\n"
            for item in record['items']:
                receipt += f"  - {item['name']}: {item['quantity']} {item['unit']} @ ₱{item['price']:.2f} = ₱{item['total']:.2f}\n"
            receipt += f"\nTotal Amount: ₱{record['total_amount']:.2f}\n"
            receipt += "====================================="
            detail_text.delete(1.0, tk.END)
            detail_text.insert(1.0, receipt)
    
    tk.Button(select_frame, text="View Details", command=show_detail,
             bg=self.batstateu_colors['info'], fg='white',
             font=('Arial', 10, 'bold')).pack(side='left', padx=10)
    
    def export_history():
        export_text = "ID,DATE,PATIENT,SR-CODE,REASON,TOTAL,NURSE,ITEMS\n"
        for record in self.cart_history:
            items_str = "; ".join([f"{i['name']} x{i['quantity']}" for i in record['items']])
            export_text += f"{record['id']},{record['date']},{record['patient_name']},{record['sr_code']},{record['reason']},{record['total_amount']},{record['nurse']},\"{items_str}\"\n"
        
        filename = f"cart_history_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(export_text)
        messagebox.showinfo("Export", f"Cart history exported to {filename}")
    
    tk.Button(history_window, text="📎 Export to CSV", command=export_history,
             bg=self.batstateu_colors['success'], fg='white',
             font=('Arial', 10, 'bold')).pack(pady=10)


# --------------------------------------------------------------
# UPDATED CART POPUP UI
# Latest inventory UI from inventory_handlers(2).py, adapted to keep
# inventory_backend.py connections used by checkout_cart/add/edit/delete.
# --------------------------------------------------------------
def _popup_show_inventory_home(self):
    """Display inventory home page with Add to Cart and View Cart popup buttons."""
    self.clear_content_area()
    if BACKEND_AVAILABLE:
        sync_inventory_from_db(self)

    self.cart_popup = getattr(self, 'cart_popup', None)
    self.cart_popup_listbox = getattr(self, 'cart_popup_listbox', None)
    self.cart_popup_total_label = getattr(self, 'cart_popup_total_label', None)

    main_container = tk.Frame(self.content_area, bg='white')
    main_container.pack(fill='both', expand=True)

    left_frame = tk.Frame(main_container, bg='white')
    left_frame.pack(side='left', fill='both', expand=True, padx=(0, 10))

    title_frame = tk.Frame(left_frame, bg='white')
    title_frame.pack(fill='x', pady=10)
    tk.Label(title_frame, text="INVENTORY ITEMS", font=('Arial', 18, 'bold'),
             bg='white', fg=self.batstateu_colors['primary']).pack(side='left')

    filter_frame = tk.Frame(left_frame, bg='#f0f0f0', height=50)
    filter_frame.pack(fill='x', pady=(0, 10))
    filter_frame.pack_propagate(False)
    filter_inner = tk.Frame(filter_frame, bg='#f0f0f0')
    filter_inner.pack(expand=True, pady=8)

    tk.Label(filter_inner, text="Search:", font=('Arial', 11),
             bg='#f0f0f0').pack(side='left', padx=(10, 5))
    search_entry = tk.Entry(filter_inner, font=('Arial', 11), width=25)
    search_entry.pack(side='left', padx=5)

    tk.Label(filter_inner, text="Filter:", font=('Arial', 11),
             bg='#f0f0f0').pack(side='left', padx=(15, 5))
    filter_combo = ttk.Combobox(filter_inner,
                                values=['All', 'In Stock', 'Low Stock', 'Out of Stock'],
                                width=15, state='readonly')
    filter_combo.set('All')
    filter_combo.pack(side='left', padx=5)

    tree_frame = tk.Frame(left_frame, bg='white')
    tree_frame.pack(fill='both', expand=True)
    columns = ('ID', 'Item Name', 'Quantity', 'Unit', 'Status', 'Price', 'Expiry Date')
    tree = ttk.Treeview(tree_frame, columns=columns, show='headings', height=12)
    col_widths = {'ID': 60, 'Item Name': 200, 'Quantity': 80, 'Unit': 80,
                  'Status': 120, 'Price': 80, 'Expiry Date': 120}
    for col in columns:
        tree.heading(col, text=col, anchor='w')
        tree.column(col, width=col_widths.get(col, 100), anchor='w')

    v_scroll = ttk.Scrollbar(tree_frame, orient='vertical', command=tree.yview)
    v_scroll.pack(side='right', fill='y')
    h_scroll = ttk.Scrollbar(tree_frame, orient='horizontal', command=tree.xview)
    h_scroll.pack(side='bottom', fill='x')
    tree.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)
    tree.pack(side='left', fill='both', expand=True)

    status_label = tk.Label(left_frame, text="", font=('Arial', 10), bg='white', fg='gray')
    status_label.pack(fill='x', pady=5)

    def refresh_inventory():
        for row in tree.get_children():
            tree.delete(row)

        search = search_entry.get().lower()
        filt = filter_combo.get()
        visible = 0
        low = 0

        for item in self.inventory_items:
            if item.get('deleted', False):
                continue
            item_id = str(item.get('id', ''))
            item_name = item.get('name', '')
            status = item.get('status', get_stock_status(item.get('quantity', 0)))

            if search and search not in item_name.lower() and search not in item_id:
                continue
            if filt == 'In Stock' and status != 'In Stock':
                continue
            if filt == 'Low Stock' and 'Low Stock' not in status:
                continue
            if filt == 'Out of Stock' and status != 'Out of Stock':
                continue

            visible += 1
            if 0 < item.get('quantity', 0) < 50:
                low += 1

            tags = ()
            if item.get('quantity', 0) <= 0:
                tags = ('out_of_stock',)
            elif item.get('quantity', 0) < 50:
                tags = ('low_stock',)

            tree.insert('', tk.END, values=(
                item_id,
                item_name,
                item.get('quantity', 0),
                item.get('unit', 'units'),
                status,
f"₱{item.get('price', 0):.2f}",
                item.get('expiry_date', 'N/A')
            ), tags=tags)

        tree.tag_configure('low_stock', background='#fff3cd')
        tree.tag_configure('out_of_stock', background='#f8d7da')
        total_active = len([item for item in self.inventory_items if not item.get('deleted', False)])
        status_label.config(text=f"Showing {visible} of {total_active} items | Low Stock: {low}")

    action_frame = tk.Frame(left_frame, bg='white')
    action_frame.pack(fill='x', pady=10)
    btn_style = {'font': ('Arial', 10, 'bold'), 'padx': 12, 'pady': 6, 'cursor': 'hand2'}

    tk.Button(action_frame, text="Add to Cart", bg=self.batstateu_colors['success'], fg='white',
              **btn_style, command=lambda: self.add_to_cart(tree)).pack(side='left', padx=3)
    tk.Button(action_frame, text="Add New Item", bg=self.batstateu_colors['primary'], fg='white',
              **btn_style, command=lambda: self.show_add_inventory_item(refresh_inventory)).pack(side='left', padx=3)
    tk.Button(action_frame, text="Edit Item", bg=self.batstateu_colors['warning'], fg='black',
              **btn_style, command=lambda: self.show_modify_inventory_item(tree, refresh_inventory)).pack(side='left', padx=3)
    tk.Button(action_frame, text="Delete Item", bg=self.batstateu_colors['danger'], fg='white',
              **btn_style, command=lambda: self.soft_delete_item(tree, refresh_inventory)).pack(side='left', padx=3)
    tk.Button(action_frame, text="View History", bg=self.batstateu_colors['info'], fg='white',
              **btn_style, command=self.show_inventory_history).pack(side='left', padx=3)
    tk.Button(action_frame, text="Cart History", bg=self.batstateu_colors['dark'], fg='white',
              **btn_style, command=self.show_cart_history).pack(side='left', padx=3)

    self.cart_btn = tk.Button(action_frame, text="View Cart (0 items, 0.00)",
                              bg=self.batstateu_colors['secondary'], fg='white',
                              **btn_style, command=self.show_cart_popup)
    self.cart_btn.pack(side='left', padx=3)

    search_entry.bind('<KeyRelease>', lambda e: refresh_inventory())
    filter_combo.bind('<<ComboboxSelected>>', lambda e: refresh_inventory())

    refresh_inventory()
    self.refresh_inventory_tree = refresh_inventory
    self.refresh_cart_display()


def show_cart_popup(self):
    if hasattr(self, 'cart_popup') and self.cart_popup and self.cart_popup.winfo_exists():
        self.cart_popup.lift()
        return

    self.cart_popup = show_centered_popup(self.root, "Shopping Cart", 550, 600)
    self.cart_popup.protocol("WM_DELETE_WINDOW", self.on_cart_popup_close)

    tk.Label(self.cart_popup, text="YOUR CART", font=('Arial', 16, 'bold'),
             bg='white', fg=self.batstateu_colors['primary']).pack(pady=15)

    cart_listbox = tk.Listbox(self.cart_popup, font=('Arial', 10), height=12, bg='white')
    cart_listbox.pack(fill='both', expand=True, padx=10, pady=5)

    cart_total_label = tk.Label(self.cart_popup, text="Total: 0.00",
                                font=('Arial', 12, 'bold'), bg='white',
                                fg=self.batstateu_colors['primary'])
    cart_total_label.pack(pady=5)

    btn_frame = tk.Frame(self.cart_popup, bg='white')
    btn_frame.pack(pady=5)
    tk.Button(btn_frame, text="Remove Selected", bg=self.batstateu_colors['danger'], fg='white',
              font=('Arial', 10, 'bold'), padx=10,
              command=lambda: self.remove_from_cart_popup(cart_listbox)).pack(side='left', padx=5)
    tk.Button(btn_frame, text="Clear All", bg=self.batstateu_colors['warning'], fg='black',
              font=('Arial', 10, 'bold'), padx=10,
              command=lambda: self.clear_cart_popup(cart_listbox, cart_total_label)).pack(side='left', padx=5)

    patient_frame = tk.LabelFrame(self.cart_popup, text="Patient Information",
                                  font=('Arial', 11, 'bold'), bg='white',
                                  fg=self.batstateu_colors['primary'])
    patient_frame.pack(fill='x', padx=10, pady=10)
    tk.Label(patient_frame, text="Patient Name:", font=('Arial', 10), bg='white').pack(anchor='w', padx=10, pady=(10, 0))
    patient_name_entry = tk.Entry(patient_frame, font=('Arial', 10), width=35)
    patient_name_entry.pack(padx=10, pady=3)
    tk.Label(patient_frame, text="SR-Code:", font=('Arial', 10), bg='white').pack(anchor='w', padx=10, pady=(5, 0))
    sr_code_entry = tk.Entry(patient_frame, font=('Arial', 10), width=35)
    sr_code_entry.pack(padx=10, pady=3)
    tk.Label(patient_frame, text="Reason:", font=('Arial', 10), bg='white').pack(anchor='w', padx=10, pady=(5, 0))
    reason_combo = ttk.Combobox(patient_frame,
                                values=['Medical Need', 'Clinic Use', 'Emergency', 'Research', 'Prescription'],
                                width=32, state='readonly')
    reason_combo.set('Medical Need')
    reason_combo.pack(padx=10, pady=3)

    tk.Button(self.cart_popup, text="CHECKOUT", bg=self.batstateu_colors['success'], fg='white',
              font=('Arial', 12, 'bold'), padx=20, pady=10,
              command=lambda: self.checkout_from_popup(cart_listbox, patient_name_entry, sr_code_entry, reason_combo)).pack(pady=15)

    self.cart_popup_listbox = cart_listbox
    self.cart_popup_total_label = cart_total_label
    self.refresh_cart_display()


def on_cart_popup_close(self):
    if hasattr(self, 'cart_popup') and self.cart_popup:
        self.cart_popup.destroy()
    self.cart_popup = None
    self.cart_popup_listbox = None
    self.cart_popup_total_label = None


def refresh_cart_display(self, cart_listbox=None, cart_total_label=None):
    total = sum(item['quantity'] * item['price'] for item in self.cart_items)
    qty = sum(item['quantity'] for item in self.cart_items)

    if hasattr(self, 'cart_btn') and self.cart_btn:
        self.cart_btn.config(text=f"View Cart ({qty} items, ₱{total:.2f})")

    target_listbox = cart_listbox
    target_total = cart_total_label
    if target_listbox is None and hasattr(self, 'cart_popup_listbox'):
        target_listbox = self.cart_popup_listbox
    if target_total is None and hasattr(self, 'cart_popup_total_label'):
        target_total = self.cart_popup_total_label

    try:
        listbox_exists = target_listbox is not None and target_listbox.winfo_exists()
    except (tk.TclError, AttributeError):
        listbox_exists = False

    if listbox_exists:
        target_listbox.delete(0, tk.END)
        for item in self.cart_items:
            item_total = item['quantity'] * item['price']
            target_listbox.insert(tk.END, f"{item['name']} - {item['quantity']} {item['unit']} - ₱{item_total:.2f}")

    try:
        total_exists = target_total is not None and target_total.winfo_exists()
    except (tk.TclError, AttributeError):
        total_exists = False

    if total_exists:
        target_total.config(text=f"Total: ₱{total:.2f}")


def add_to_cart(self, tree, cart_listbox=None, cart_total_label=None):
    selected = tree.selection()
    if not selected:
        messagebox.showwarning("Warning", "Please select an item to add to cart")
        return

    item = tree.item(selected[0])
    item_id = item['values'][0]
    item_name = item['values'][1]
    available_qty = item['values'][2]
    unit = item['values'][3]
    price_str = str(item['values'][5]).replace('₱', '')
    price_str = price_str.replace('PHP', '').replace('₱', '').strip()
    price = float(price_str) if price_str else 0

    popup = show_centered_popup(self.root, "Enter Quantity", 300, 200)
    tk.Label(popup, text=f"Item: {item_name}", font=('Arial', 12, 'bold'), bg='white').pack(pady=10)
    tk.Label(popup, text=f"Available: {available_qty} {unit}", font=('Arial', 10), bg='white').pack()
    tk.Label(popup, text="Quantity:", font=('Arial', 11), bg='white').pack(pady=10)
    qty_entry = tk.Entry(popup, font=('Arial', 11), width=10)
    qty_entry.pack()

    def confirm():
        try:
            qty = int(qty_entry.get())
            if qty <= 0:
                messagebox.showerror("Error", "Quantity must be positive")
                return
            if qty > available_qty:
                messagebox.showerror("Error", f"Insufficient stock! Only {available_qty} available")
                return

            for cart_item in self.cart_items:
                if cart_item['item_id'] == item_id:
                    if cart_item['quantity'] + qty > available_qty:
                        messagebox.showerror("Error", "Exceeds available stock")
                        return
                    cart_item['quantity'] += qty
                    break
            else:
                self.cart_items.append({
                    'item_id': item_id,
                    'name': item_name,
                    'quantity': qty,
                    'unit': unit,
                    'price': price
                })

            popup.destroy()
            self.refresh_cart_display(cart_listbox, cart_total_label)
            messagebox.showinfo("Success", f"Added {qty} {unit} of {item_name} to cart")
        except ValueError:
            messagebox.showerror("Error", "Enter a valid number")

    tk.Button(popup, text="Add to Cart", command=confirm,
              bg=self.batstateu_colors['success'], fg='white').pack(pady=15)


def remove_from_cart_popup(self, cart_listbox):
    selected = cart_listbox.curselection()
    if not selected:
        messagebox.showwarning("Warning", "Select an item to remove")
        return
    index = selected[0]
    if index < len(self.cart_items):
        removed = self.cart_items.pop(index)
        self.refresh_cart_display()
        messagebox.showinfo("Removed", f"Removed {removed['name']}")


def clear_cart_popup(self, cart_listbox=None, cart_total_label=None):
    if self.cart_items and messagebox.askyesno("Clear Cart", "Clear entire cart?"):
        self.cart_items.clear()
        self.refresh_cart_display(cart_listbox, cart_total_label)
        messagebox.showinfo("Cart Cleared", "All items removed")


def checkout_from_popup(self, cart_listbox, patient_name_entry, sr_code_entry, reason_combo):
    refresh_callback = getattr(self, 'refresh_inventory_tree', lambda: None)
    had_items = bool(self.cart_items)
    self.checkout_cart(cart_listbox, self.cart_popup_total_label, patient_name_entry, sr_code_entry, reason_combo, refresh_callback)

    if hasattr(self, 'refresh_cart_history_tab'):
        self.refresh_cart_history_tab()
    if hasattr(self, 'refresh_inventory_history_tab'):
        self.refresh_inventory_history_tab()

    if had_items and not self.cart_items and hasattr(self, 'cart_popup') and self.cart_popup:
        self.cart_popup.destroy()
        self.cart_popup = None
        self.cart_popup_listbox = None
        self.cart_popup_total_label = None


# --------------------------------------------------------------
# INVENTORY TABBED UI
# Active inventory page: Main, Cart History, View History.
# --------------------------------------------------------------
def show_inventory_home(self):
    self.clear_content_area()
    if BACKEND_AVAILABLE:
        sync_inventory_from_db(self)

    notebook = ttk.Notebook(self.content_area)
    notebook.pack(fill='both', expand=True)

    main_tab = tk.Frame(notebook, bg='white')
    cart_history_tab = tk.Frame(notebook, bg='white')
    view_history_tab = tk.Frame(notebook, bg='white')

    notebook.add(main_tab, text="Main")
    notebook.add(cart_history_tab, text="Cart History")
    notebook.add(view_history_tab, text="View History")

    create_inventory_main_tab(self, main_tab)
    create_cart_history_tab(self, cart_history_tab)
    create_inventory_history_tab(self, view_history_tab)

    def refresh_selected_tab(_event=None):
        selected = notebook.select()
        if selected == str(cart_history_tab) and hasattr(self, 'refresh_cart_history_tab'):
            self.refresh_cart_history_tab()
        elif selected == str(view_history_tab) and hasattr(self, 'refresh_inventory_history_tab'):
            self.refresh_inventory_history_tab()

    notebook.bind('<<NotebookTabChanged>>', refresh_selected_tab)


def create_inventory_main_tab(self, parent):
    self.cart_popup = getattr(self, 'cart_popup', None)
    self.cart_popup_listbox = getattr(self, 'cart_popup_listbox', None)
    self.cart_popup_total_label = getattr(self, 'cart_popup_total_label', None)

    title_frame = tk.Frame(parent, bg='white')
    title_frame.pack(fill='x', pady=10)
    tk.Label(title_frame, text="INVENTORY ITEMS", font=('Arial', 18, 'bold'),
             bg='white', fg=self.batstateu_colors['primary']).pack(side='left')

    filter_frame = tk.Frame(parent, bg='#f0f0f0', height=50)
    filter_frame.pack(fill='x', pady=(0, 10))
    filter_frame.pack_propagate(False)
    filter_inner = tk.Frame(filter_frame, bg='#f0f0f0')
    filter_inner.pack(expand=True, pady=8)

    tk.Label(filter_inner, text="Search:", font=('Arial', 11), bg='#f0f0f0').pack(side='left', padx=(10, 5))
    search_entry = tk.Entry(filter_inner, font=('Arial', 11), width=25)
    search_entry.pack(side='left', padx=5)

    tk.Label(filter_inner, text="Filter:", font=('Arial', 11), bg='#f0f0f0').pack(side='left', padx=(15, 5))
    filter_combo = ttk.Combobox(filter_inner,
                                values=['All', 'In Stock', 'Low Stock', 'Out of Stock'],
                                width=15, state='readonly')
    filter_combo.set('All')
    filter_combo.pack(side='left', padx=5)

    tree_frame = tk.Frame(parent, bg='white')
    tree_frame.pack(fill='both', expand=True)
    columns = ('ID', 'Item Name', 'Quantity', 'Unit', 'Status', 'Price', 'Expiry Date')
    tree = ttk.Treeview(tree_frame, columns=columns, show='headings', height=12)
    widths = {'ID': 60, 'Item Name': 200, 'Quantity': 80, 'Unit': 80,
              'Status': 120, 'Price': 80, 'Expiry Date': 120}
    for col in columns:
        tree.heading(col, text=col, anchor='w')
        tree.column(col, width=widths.get(col, 100), anchor='w')

    v_scroll = ttk.Scrollbar(tree_frame, orient='vertical', command=tree.yview)
    v_scroll.pack(side='right', fill='y')
    h_scroll = ttk.Scrollbar(tree_frame, orient='horizontal', command=tree.xview)
    h_scroll.pack(side='bottom', fill='x')
    tree.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)
    tree.pack(side='left', fill='both', expand=True)

    status_label = tk.Label(parent, text="", font=('Arial', 10), bg='white', fg='gray')
    status_label.pack(fill='x', pady=5)

    def refresh_inventory():
        if BACKEND_AVAILABLE:
            sync_inventory_from_db(self)

        for row in tree.get_children():
            tree.delete(row)

        search = search_entry.get().lower()
        filter_value = filter_combo.get()
        visible = 0
        low = 0

        for item in self.inventory_items:
            if item.get('deleted', False):
                continue

            item_id = str(item.get('id', ''))
            item_name = item.get('name', '')
            quantity = item.get('quantity', 0)
            status = item.get('status', get_stock_status(quantity))

            if search and search not in item_name.lower() and search not in item_id:
                continue
            if filter_value == 'In Stock' and status != 'In Stock':
                continue
            if filter_value == 'Low Stock' and 'Low Stock' not in status:
                continue
            if filter_value == 'Out of Stock' and status != 'Out of Stock':
                continue

            visible += 1
            if 0 < quantity < 50:
                low += 1

            tags = ()
            if quantity <= 0:
                tags = ('out_of_stock',)
            elif quantity < 50:
                tags = ('low_stock',)

            tree.insert('', tk.END, values=(
                item_id,
                item_name,
                quantity,
                item.get('unit', 'units'),
                status,
                f"PHP {item.get('price', 0):.2f}",
                item.get('expiry_date', 'N/A')
            ), tags=tags)

        tree.tag_configure('low_stock', background='#fff3cd')
        tree.tag_configure('out_of_stock', background='#f8d7da')
        total_active = len([item for item in self.inventory_items if not item.get('deleted', False)])
        status_label.config(text=f"Showing {visible} of {total_active} items | Low Stock: {low}")

    action_frame = tk.Frame(parent, bg='white')
    action_frame.pack(fill='x', pady=10)
    btn_style = {'font': ('Arial', 10, 'bold'), 'padx': 12, 'pady': 6, 'cursor': 'hand2'}

    tk.Button(action_frame, text="Add to Cart", bg=self.batstateu_colors['success'], fg='white',
              **btn_style, command=lambda: self.add_to_cart(tree)).pack(side='left', padx=3)
    tk.Button(action_frame, text="Add New Item", bg=self.batstateu_colors['primary'], fg='white',
              **btn_style, command=lambda: self.show_add_inventory_item(refresh_inventory)).pack(side='left', padx=3)
    tk.Button(action_frame, text="Edit Item", bg=self.batstateu_colors['warning'], fg='black',
              **btn_style, command=lambda: self.show_modify_inventory_item(tree, refresh_inventory)).pack(side='left', padx=3)
    tk.Button(action_frame, text="Delete Item", bg=self.batstateu_colors['danger'], fg='white',
              **btn_style, command=lambda: self.soft_delete_item(tree, refresh_inventory)).pack(side='left', padx=3)

    self.cart_btn = tk.Button(action_frame, text="View Cart (0 items, PHP 0.00)",
                              bg=self.batstateu_colors['secondary'], fg='white',
                              **btn_style, command=self.show_cart_popup)
    self.cart_btn.pack(side='left', padx=3)

    search_entry.bind('<KeyRelease>', lambda e: refresh_inventory())
    filter_combo.bind('<<ComboboxSelected>>', lambda e: refresh_inventory())

    self.refresh_inventory_tree = refresh_inventory
    refresh_inventory()
    self.refresh_cart_display()


def create_inventory_history_tab(self, parent):
    tk.Label(parent, text="INVENTORY TRANSACTION HISTORY",
             font=('Arial', 16, 'bold'), bg='white',
             fg=self.batstateu_colors['primary']).pack(pady=15)

    filter_frame = tk.Frame(parent, bg='white')
    filter_frame.pack(pady=10, fill='x', padx=20)

    tk.Label(filter_frame, text="Filter by Action:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
    action_filter = ttk.Combobox(filter_frame, values=['All', 'CREATE', 'EDIT', 'CHECKOUT', 'DELETE'], width=15, state='readonly')
    action_filter.set('All')
    action_filter.pack(side='left', padx=5)

    tk.Label(filter_frame, text="Search Item:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
    search_entry = tk.Entry(filter_frame, width=20)
    search_entry.pack(side='left', padx=5)

    tree_frame = tk.Frame(parent, bg='white')
    tree_frame.pack(fill='both', expand=True, padx=20, pady=10)

    columns = ('ID', 'Date/Time', 'Item Name', 'Action', 'Quantity Change', 'Details', 'User')
    tree = ttk.Treeview(tree_frame, columns=columns, show='headings', height=15)
    widths = {'ID': 50, 'Date/Time': 150, 'Item Name': 150, 'Action': 100,
              'Quantity Change': 120, 'Details': 250, 'User': 120}
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=widths.get(col, 100))

    scrollbar = ttk.Scrollbar(tree_frame, orient='vertical', command=tree.yview)
    scrollbar.pack(side='right', fill='y')
    tree.configure(yscrollcommand=scrollbar.set)
    tree.pack(side='left', fill='both', expand=True)

    summary_label = tk.Label(parent, text="", font=('Arial', 10), bg='white', fg='gray')
    summary_label.pack(pady=5)

    def refresh_history():
        for row_id in tree.get_children():
            tree.delete(row_id)

        filter_action = action_filter.get()
        search_term = search_entry.get().lower()
        transactions = []
        db_transactions = []

        if BACKEND_AVAILABLE:
            try:
                ok, result = get_inventory_transactions()
                if ok and result:
                    db_transactions = result
            except Exception as e:
                print(f"Failed to load inventory transactions: {e}")

        if db_transactions:
            for row in db_transactions:
                transactions.append({
                    'id': row.get('TransactionID', ''),
                    'timestamp': '',
                    'item_name': row.get('ItemName', ''),
                    'action': 'CHECKOUT',
                    'quantity_change': -row.get('QuantityUsed', 0),
                    'details': row.get('Reason', ''),
                    'user': row.get('ControlID', '')
                })
        else:
            transactions = self.inventory_history

        for record in reversed(transactions):
            if filter_action != 'All' and record['action'] != filter_action:
                continue
            if search_term and search_term not in record['item_name'].lower():
                continue

            qty_change = record['quantity_change']
            qty_display = f"{'+' if qty_change > 0 else ''}{qty_change}" if qty_change != 0 else '-'
            tree.insert('', tk.END, values=(
                record['id'],
                record.get('timestamp', ''),
                record['item_name'],
                record['action'],
                qty_display,
                record['details'],
                record['user']
            ))

        summary_label.config(text=f"Total Transactions: {len(transactions)}")

    action_filter.bind('<<ComboboxSelected>>', lambda e: refresh_history())
    search_entry.bind('<KeyRelease>', lambda e: refresh_history())
    tk.Button(filter_frame, text="Search", command=refresh_history,
              bg=self.batstateu_colors['info'], fg='white',
              font=('Arial', 10), padx=10, pady=3).pack(side='left', padx=5)
    tk.Button(filter_frame, text="Refresh", command=refresh_history,
              bg=self.batstateu_colors['primary'], fg='white',
              font=('Arial', 10), padx=10, pady=3).pack(side='left', padx=5)

    self.refresh_inventory_history_tab = refresh_history
    refresh_history()


def create_cart_history_tab(self, parent):
    tk.Label(parent, text="CHECKOUT HISTORY",
             font=('Arial', 16, 'bold'), bg='white',
             fg=self.batstateu_colors['primary']).pack(pady=15)

    notebook = ttk.Notebook(parent)
    notebook.pack(expand=True, fill='both', padx=10, pady=10)

    summary_tab = tk.Frame(notebook, bg='white')
    detail_tab = tk.Frame(notebook, bg='white')
    notebook.add(summary_tab, text="Summary View")
    notebook.add(detail_tab, text="Detailed View")

    columns = ('ID', 'Date', 'Patient Name', 'SR-Code', 'Items Count', 'Total Amount', 'Nurse')
    tree = ttk.Treeview(summary_tab, columns=columns, show='headings', height=15)
    widths = {'ID': 50, 'Date': 150, 'Patient Name': 150, 'SR-Code': 100,
              'Items Count': 90, 'Total Amount': 110, 'Nurse': 120}
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=widths.get(col, 100))

    scrollbar = ttk.Scrollbar(summary_tab, orient='vertical', command=tree.yview)
    scrollbar.pack(side='right', fill='y')
    tree.configure(yscrollcommand=scrollbar.set)
    tree.pack(side='left', fill='both', expand=True)

    select_frame = tk.Frame(detail_tab, bg='white')
    select_frame.pack(pady=10, fill='x')
    tk.Label(select_frame, text="Select Transaction ID:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
    id_combo = ttk.Combobox(select_frame, values=[], width=10, state='readonly')
    id_combo.pack(side='left', padx=5)

    detail_text = ScrolledText(detail_tab, wrap=tk.WORD, width=90, height=25, font=('Courier', 10))
    detail_text.pack(padx=10, pady=10, fill='both', expand=True)

    empty_label = tk.Label(parent, text="", font=('Arial', 10), bg='white', fg='gray')
    empty_label.pack(pady=5)

    def show_detail():
        selected_id = id_combo.get()
        if not selected_id:
            messagebox.showwarning("Warning", "Please select a transaction ID")
            return

        record = next((row for row in self.cart_history if str(row['id']) == selected_id), None)
        if not record:
            return

        receipt = "========== CHECKOUT RECEIPT ==========\n"
        receipt += f"Transaction ID: {record['id']}\n"
        receipt += f"Date: {record['date']}\n"
        receipt += f"Nurse: {record['nurse']}\n"
        receipt += f"Patient: {record['patient_name']} (SR: {record['sr_code']})\n"
        receipt += f"Reason: {record['reason']}\n\n"
        receipt += "Items:\n"
        for item in record['items']:
            receipt += f"  - {item['name']}: {item['quantity']} {item['unit']} @ PHP {item['price']:.2f} = PHP {item['total']:.2f}\n"
        receipt += f"\nTotal Amount: PHP {record['total_amount']:.2f}\n"
        receipt += "====================================="

        detail_text.configure(state='normal')
        detail_text.delete(1.0, tk.END)
        detail_text.insert(1.0, receipt)
        detail_text.configure(state='disabled')

    tk.Button(select_frame, text="View Details", command=show_detail,
              bg=self.batstateu_colors['info'], fg='white',
              font=('Arial', 10, 'bold')).pack(side='left', padx=10)

    def export_history():
        export_text = "ID,DATE,PATIENT,SR-CODE,REASON,TOTAL,NURSE,ITEMS\n"
        for record in self.cart_history:
            items_str = "; ".join([f"{item['name']} x{item['quantity']}" for item in record['items']])
            export_text += f"{record['id']},{record['date']},{record['patient_name']},{record['sr_code']},{record['reason']},{record['total_amount']},{record['nurse']},\"{items_str}\"\n"

        filename = f"cart_history_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        with open(filename, 'w', encoding='utf-8') as file:
            file.write(export_text)
        messagebox.showinfo("Export", f"Cart history exported to {filename}")

    tk.Button(parent, text="Export to CSV", command=export_history,
              bg=self.batstateu_colors['success'], fg='white',
              font=('Arial', 10, 'bold')).pack(pady=10)

    def refresh_cart_history():
        for row_id in tree.get_children():
            tree.delete(row_id)

        for record in reversed(self.cart_history):
            tree.insert('', tk.END, values=(
                record['id'],
                record['date'],
                record['patient_name'],
                record['sr_code'],
                len(record['items']),
                f"PHP {record['total_amount']:.2f}",
                record['nurse']
            ))

        id_combo.configure(values=[str(record['id']) for record in self.cart_history])
        if not self.cart_history:
            detail_text.configure(state='normal')
            detail_text.delete(1.0, tk.END)
            detail_text.configure(state='disabled')
            empty_label.config(text="No checkout transactions yet.")
        else:
            empty_label.config(text=f"Total Checkout Transactions: {len(self.cart_history)}")

    self.refresh_cart_history_tab = refresh_cart_history
    refresh_cart_history()
