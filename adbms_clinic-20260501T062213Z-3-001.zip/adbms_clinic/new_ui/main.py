import sys
import tkinter as tk
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app import ClinicManagementSystem

if __name__ == "__main__":
    root = tk.Tk()
    app = ClinicManagementSystem(root)
    root.mainloop()
