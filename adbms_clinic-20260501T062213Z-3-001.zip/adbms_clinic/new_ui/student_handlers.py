# student_handlers.py
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

def show_student_records(self):
    """Display student records with check-in counts"""
    self.clear_content_area()
    
    tk.Label(self.content_area, text="STUDENT RECORDS", 
            font=('Arial', 18, 'bold'), bg='white', 
            fg=self.batstateu_colors['primary']).pack(pady=20)
    
    # Search and filter frame
    search_frame = tk.Frame(self.content_area, bg='white')
    search_frame.pack(pady=10, fill='x', padx=20)
    
    tk.Label(search_frame, text="Search:", font=('Arial', 11), bg='white').pack(side='left', padx=5)
    search_entry = tk.Entry(search_frame, font=('Arial', 11), width=20)
    search_entry.pack(side='left', padx=5)
    
    tk.Label(search_frame, text="Program:", font=('Arial', 11), bg='white').pack(side='left', padx=15)
    program_filter = ttk.Combobox(search_frame, values=['All', 'BSIT', 'BSCS', 'BSIS', 'BSEMC', 'BSECE', 'BSME', 'BSCE', 'BSEE'], width=10, state='readonly')
    program_filter.set('All')
    program_filter.pack(side='left', padx=5)
    
    tk.Label(search_frame, text="Year:", font=('Arial', 11), bg='white').pack(side='left', padx=15)
    year_filter = ttk.Combobox(search_frame, values=['All', '1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year'], width=10, state='readonly')
    year_filter.set('All')
    year_filter.pack(side='left', padx=5)
    
    # Treeview for student records
    tree_frame = tk.Frame(self.content_area, bg='white')
    tree_frame.pack(fill='both', expand=True, padx=20, pady=10)
    
    columns = ('SR Code', 'Full Name', 'Year', 'Program', 'Check-in Counts')
    tree = ttk.Treeview(tree_frame, columns=columns, show='headings', height=15)
    
    col_widths = {'SR Code': 120, 'Full Name': 200, 'Year': 100, 'Program': 100, 'Check-in Counts': 120}
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=col_widths.get(col, 100))
    
    scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
    scrollbar.pack(side='right', fill='y')
    tree.configure(yscrollcommand=scrollbar.set)
    tree.pack(side='left', fill='both', expand=True)
    
    def refresh_student_records():
        for item in tree.get_children():
            tree.delete(item)
        
        search_term = search_entry.get().lower()
        prog_filter = program_filter.get()
        yr_filter = year_filter.get()
        
        for student in sorted(self.student_records, key=lambda x: x['sr_code']):
            if search_term and search_term not in student['sr_code'].lower() and search_term not in student['full_name'].lower():
                continue
            if prog_filter != 'All' and student['program'] != prog_filter:
                continue
            if yr_filter != 'All' and student['year'] != yr_filter:
                continue
            
            tree.insert('', tk.END, values=(
                student['sr_code'],
                student['full_name'],
                student['year'],
                student['program'],
                student['checkin_counts']
            ))
    
    def reset_filters():
        search_entry.delete(0, tk.END)
        program_filter.set('All')
        year_filter.set('All')
        refresh_student_records()
    
    button_frame = tk.Frame(self.content_area, bg='white')
    button_frame.pack(pady=10)
    
    tk.Button(button_frame, text="🔍 Search", command=refresh_student_records,
             bg=self.batstateu_colors['info'], fg='white',
             font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)
    
    tk.Button(button_frame, text="🔄 Reset", command=reset_filters,
             bg=self.batstateu_colors['warning'], fg='black',
             font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)
    
    def export_student_records():
        export_text = "SR Code,Full Name,Year,Program,Check-in Counts\n"
        for student in self.student_records:
            export_text += f"{student['sr_code']},{student['full_name']},{student['year']},{student['program']},{student['checkin_counts']}\n"
        
        filename = f"student_records_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(export_text)
        messagebox.showinfo("Export", f"Student records exported to {filename}")
    
    tk.Button(button_frame, text="📎 Export to CSV", command=export_student_records,
             bg=self.batstateu_colors['success'], fg='white',
             font=('Arial', 10, 'bold'), padx=10, pady=5).pack(side='left', padx=5)
    
    summary_label = tk.Label(self.content_area, text=f"Total Students: {len(self.student_records)}", 
                             font=('Arial', 11), bg='white', fg='gray')
    summary_label.pack(pady=10)
    
    search_entry.bind('<KeyRelease>', lambda e: refresh_student_records())
    program_filter.bind('<<ComboboxSelected>>', lambda e: refresh_student_records())
    year_filter.bind('<<ComboboxSelected>>', lambda e: refresh_student_records())
    
    refresh_student_records()