from clinic_db import get_connection

def patient_checkin(sr_code, name, year_level, program):
    conn = get_connection()
    cursor = conn.cursor()

    try:
        # ✅ Use execute() for OUT params — but drop stored_results()
        cursor.execute(
            "CALL PatientCheckIn(%s, %s, %s, %s, @control_id)",
            (sr_code, name, year_level, program)
        )

        # ✅ Fetch the OUT param separately
        cursor.execute("SELECT @control_id AS control_id")
        control_id = cursor.fetchone()[0]

        conn.commit()
        return True, control_id

    except Exception as e:
        conn.rollback()
        return False, str(e)

    finally:
        cursor.close()
        conn.close()