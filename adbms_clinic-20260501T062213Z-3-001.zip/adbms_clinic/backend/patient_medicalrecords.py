from clinic_db import get_connection
from tkinter import messagebox


def fetch_all(query, params=None):
    conn = None
    cursor = None

    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params or ())
        rows = cursor.fetchall()
        return rows

    except Exception as e:
        messagebox.showerror("Database Error", f"Failed to fetch data:\n{e}")
        return []

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


def execute_query(query, params=None):
    conn = None
    cursor = None

    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(query, params or ())
        conn.commit()
        return True

    except Exception as e:
        if conn:
            conn.rollback()
        messagebox.showerror("Database Error", f"Database action failed:\n{e}")
        return False

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


def get_patient_queue(search_text=""):
    query = """
        SELECT
            c.CheckInID,
            c.PatientID AS PatientID,
            c.ControlID AS control_number,
            p.SRCode AS sr_code,
            p.Name AS name,
            p.YearLevel AS year,
            p.Program AS program,
            c.Status AS status,
            DATE_FORMAT(c.CheckInDateTime, '%Y-%m-%d %h:%i %p') AS timestamp
        FROM CheckIn c
        INNER JOIN Patient p ON c.PatientID = p.PatientID
        WHERE
            c.Status IN ('Waiting', 'In Progress')
            AND (
                p.SRCode LIKE %s
                OR p.Name LIKE %s
                OR c.ControlID LIKE %s
                OR p.Program LIKE %s
                OR p.YearLevel LIKE %s
            )
        ORDER BY c.CheckInDateTime ASC
    """

    search = f"%{search_text}%"
    return fetch_all(query, (search, search, search, search, search))


def update_checkin_status(checkin_id, patient_id, new_status):
    update_query = """
        UPDATE CheckIn
        SET Status = %s
        WHERE CheckInID = %s
    """

    updated = execute_query(update_query, (new_status, checkin_id))

    if updated:
        history_query = """
            INSERT INTO CheckInHistory
            (CheckInID, PatientID, Status, Action)
            VALUES (%s, %s, %s, %s)
        """

        action = f"Status updated to {new_status}"
        execute_query(history_query, (checkin_id, patient_id, new_status, action))

    return updated


def get_checkin_by_id(checkin_id):
    query = """
        SELECT
            c.CheckInID,
            c.PatientID,
            c.ControlID,
            p.SRCode,
            p.Name,
            c.Status
        FROM CheckIn c
        INNER JOIN Patient p ON c.PatientID = p.PatientID
        WHERE c.CheckInID = %s
    """

    rows = fetch_all(query, (checkin_id,))
    return rows[0] if rows else None