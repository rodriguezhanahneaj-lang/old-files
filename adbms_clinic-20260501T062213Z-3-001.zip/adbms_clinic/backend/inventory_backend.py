from clinic_db import get_connection


# ─────────────────────────────────────────────────────────────────
#  READ OPERATIONS
# ─────────────────────────────────────────────────────────────────

def get_all_inventory():
    """
    Returns all inventory items using vw_inventory_all view.
    Returns: (True, list of dicts) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                ItemID,
                ItemName,
                Description,
                StockQuantity,
                ExpiryDate,
                StockStatus
            FROM vw_inventory_all
            ORDER BY ItemName
        """)
        rows = cursor.fetchall()
        return True, rows
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def get_inventory_lowest_to_highest():
    """
    Returns inventory sorted from lowest to highest stock using vw_inventory_lowest_to_highest view.
    Returns: (True, list of dicts) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                ItemID,
                ItemName,
                Description,
                StockQuantity,
                StockStatus,
                Recommendation
            FROM vw_inventory_lowest_to_highest
        """)
        rows = cursor.fetchall()
        return True, rows
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def get_inventory_highest_to_lowest():
    """
    Returns inventory sorted from highest to lowest stock using vw_inventory_highest_to_lowest view.
    Returns: (True, list of dicts) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                ItemID,
                ItemName,
                Description,
                StockQuantity,
                StockStatus
            FROM vw_inventory_highest_to_lowest
        """)
        rows = cursor.fetchall()
        return True, rows
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def get_items_need_reorder():
    """
    Returns items that need reordering (stock < 10) using vw_items_need_reorder view.
    Returns: (True, list of dicts) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                ItemID,
                ItemName,
                StockQuantity,
                StockStatus,
                PriorityLevel,
                ActionRequired,
                RecommendedOrderQuantity
            FROM vw_items_need_reorder
            ORDER BY PriorityLevel ASC, StockQuantity ASC
        """)
        rows = cursor.fetchall()
        return True, rows
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def get_critical_low_stock():
    """
    Returns critical/urgent low stock items using vw_critical_low_stock view.
    Returns: (True, list of dicts) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                ItemID,
                ItemName,
                StockQuantity,
                StockStatus,
                ActionRequired
            FROM vw_critical_low_stock
        """)
        rows = cursor.fetchall()
        return True, rows
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def get_inventory_with_usage():
    """
    Returns inventory items joined with their usage data using vw_inventory_with_usage view.
    Returns: (True, list of dicts) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                ItemID,
                ItemName,
                Description,
                CurrentStock,
                TotalUsed,
                TimesUsed,
                UsageLevel
            FROM vw_inventory_with_usage
            ORDER BY TotalUsed DESC
        """)
        rows = cursor.fetchall()
        return True, rows
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def get_inventory_transactions():
    """
    Returns all inventory usage transactions using vw_inventory_transactions view.
    Returns: (True, list of dicts) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                TransactionID,
                ItemID,
                ItemName,
                QuantityUsed,
                Reason,
                ControlID
            FROM vw_inventory_transactions
            ORDER BY TransactionID DESC
        """)
        rows = cursor.fetchall()
        return True, rows
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def get_recent_transactions():
    """
    Returns last 10 inventory transactions using vw_recent_transactions view.
    Returns: (True, list of dicts) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                UsageID,
                ItemName,
                QuantityUsed,
                Reason,
                ControlID
            FROM vw_recent_transactions
        """)
        rows = cursor.fetchall()
        return True, rows
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def get_transaction_summary_by_item():
    """
    Returns per-item transaction summary using vw_transaction_summary_by_item view.
    Returns: (True, list of dicts) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                ItemID,
                ItemName,
                TotalTransactions,
                TotalQuantityUsed,
                AverageQuantityPerUse,
                LargestSingleUse,
                SmallestSingleUse,
                UniqueVisits
            FROM vw_transaction_summary_by_item
        """)
        rows = cursor.fetchall()
        return True, rows
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def get_top_used_items():
    """
    Returns top 10 most used inventory items using vw_top_used_items view.
    Returns: (True, list of dicts) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                ItemID,
                ItemName,
                TotalUsed,
                TimesUsed,
                CurrentStock,
                UsageRate
            FROM vw_top_used_items
        """)
        rows = cursor.fetchall()
        return True, rows
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def get_complete_inventory_report():
    """
    Returns full inventory report using vw_complete_inventory_report view.
    Returns: (True, list of dicts) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                ItemID,
                ItemName,
                Description,
                CurrentStock,
                TotalUsed,
                TimesUsed,
                Status,
                ActivityLevel
            FROM vw_complete_inventory_report
            ORDER BY ItemName
        """)
        rows = cursor.fetchall()
        return True, rows
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def get_dashboard_inventory_stats():
    """
    Returns quick dashboard stats using vw_dashboard_inventory_stats view.
    Returns: (True, dict) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                TotalProducts,
                TotalStockUnits,
                ItemsNeedReorder,
                CriticalItems
            FROM vw_dashboard_inventory_stats
        """)
        row = cursor.fetchone()
        return True, row
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def get_inventory_by_status():
    """
    Returns inventory grouped by stock status using vw_inventory_by_status view.
    Returns: (True, list of dicts) or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT 
                StockStatus,
                ProductCount,
                TotalUnits,
                ProductNames
            FROM vw_inventory_by_status
        """)
        rows = cursor.fetchall()
        return True, rows
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


# ─────────────────────────────────────────────────────────────────
#  WRITE OPERATIONS
# ─────────────────────────────────────────────────────────────────

def add_inventory_item(item_name, description, stock_quantity):
    """
    Adds a new inventory item using the StoreInventory stored procedure.

    Parameters
    ----------
    item_name      : str
    description    : str
    stock_quantity : int

    Returns: (True, "Item added successfully") or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "CALL StoreInventory(%s, %s, %s)",
            (item_name, description, stock_quantity)
        )
        for result in cursor.stored_results():
            result.fetchall()
        conn.commit()
        return True, "Item added successfully"
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def update_inventory_item(item_id, item_name, description, stock_quantity):
    """
    Updates an existing inventory item.
    The trg_inventory_after_update trigger will automatically log the change
    to inventory_audit, and trg_inventory_low_stock_alert will fire if stock
    drops below threshold.

    Parameters
    ----------
    item_id        : int
    item_name      : str
    description    : str
    stock_quantity : int  (must be >= 0; trg_inventory_before_update enforces this)

    Returns: (True, "Item updated") or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            """
            UPDATE inventory
            SET ItemName = %s, Description = %s, StockQuantity = %s
            WHERE ItemID = %s
            """,
            (item_name, description, stock_quantity, item_id)
        )
        conn.commit()
        return True, "Item updated"
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def delete_inventory_item(item_id):
    """
    Permanently deletes an inventory item.
    Will fail (returns False) if the item has existing usage history.

    Parameters
    ----------
    item_id : int

    Returns: (True, "Item deleted") or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        # Check for existing usage history first
        cursor.execute(
            "SELECT COUNT(*) AS cnt FROM inventoryusage WHERE ItemID = %s",
            (item_id,)
        )
        row = cursor.fetchone()
        if row and row['cnt'] > 0:
            return False, "Cannot delete item with usage history."

        # Check if item exists
        cursor.execute(
            "SELECT ItemID FROM inventory WHERE ItemID = %s",
            (item_id,)
        )
        item = cursor.fetchone()
        if not item:
            return False, "Item not found"

        cursor.execute("DELETE FROM inventory WHERE ItemID = %s", (item_id,))
        conn.commit()
        return True, "Item deleted"
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def use_inventory_item(item_id, control_id, quantity, reason):
    """
    Records inventory usage via the RecordInventoryUsage stored procedure.
    The procedure will:
      - Check there is enough stock
      - Insert a row into inventoryusage
      - Deduct quantity from inventory (which fires the audit + low-stock triggers)

    Parameters
    ----------
    item_id    : int
    control_id : str   (patient control number, e.g. "AR-NASUGBU-2026-00001")
    quantity   : int   (must be > 0)
    reason     : str

    Returns: (True, "Inventory usage recorded") or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "CALL RecordInventoryUsage(%s, %s, %s, %s)",
            (item_id, control_id, quantity, reason)
        )
        for result in cursor.stored_results():
            result.fetchall()
        conn.commit()
        return True, "Inventory usage recorded"
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def soft_delete_inventory_item(item_id):
    """
    Soft deletes an inventory item by setting IsDeleted = 1.
    This hides the item from active inventory views but preserves history.

    Parameters
    ----------
    item_id : int

    Returns: (True, "Item soft deleted") or (False, error string)
    """
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE inventory SET IsDeleted = 1 WHERE ItemID = %s",
            (item_id,)
        )
        conn.commit()
        return True, "Item soft deleted"
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        cursor.close()
        conn.close()
