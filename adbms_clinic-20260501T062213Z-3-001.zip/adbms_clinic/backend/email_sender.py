import smtplib
import ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

SENDER_EMAIL = "medtracksystem@gmail.com"
SENDER_PASSWORD = "ttfeutwsvpblvfsb"


def send_verification_email(recipient_email, verification_code):
    """Used during signup — sends email verification OTP"""
    subject = "MedTrack - Email Verification"
    plain_text = f"Your verification code is: {verification_code}\n\nExpires in 2 minutes."
    html_content = f"""
    <html>
    <body style="font-family: Arial; background-color: #f4f4f4; padding: 20px;">
        <div style="max-width: 400px; margin: auto; background: white; padding: 20px;
                    border-radius: 10px; text-align: center;">
            <h2 style="color: #4CAF50;">Email Verification</h2>
            <p>Your OTP Code:</p>
            <div style="font-size: 28px; font-weight: bold; background: #4CAF50;
                        color: white; padding: 10px; border-radius: 5px; letter-spacing: 5px;">
                {verification_code}
            </div>
            <p style="margin-top: 15px;">Expires in <b>2 minutes</b></p>
        </div>
    </body>
    </html>
    """
    return _send_email(recipient_email, subject, plain_text, html_content)


def send_reset_otp_email(recipient_email, otp_code):
    """Used during forgot password — sends password reset OTP"""
    subject = "MedTrack - Password Reset OTP"
    plain_text = f"""
Your OTP for password reset is: {otp_code}

This code expires in 5 minutes. Do not share it with anyone.
If you did not request this, please ignore this email.

- MedTrack Clinic System
"""
    html_content = f"""
    <html>
    <body style="font-family: Arial; background-color: #f4f4f4; padding: 20px;">
        <div style="max-width: 400px; margin: auto; background: white; padding: 20px;
                    border-radius: 10px; text-align: center;">
            <h2 style="color: #2196F3;">Password Reset</h2>
            <p>Your OTP Code:</p>
            <div style="font-size: 28px; font-weight: bold; background: #2196F3;
                        color: white; padding: 10px; border-radius: 5px; letter-spacing: 5px;">
                {otp_code}
            </div>
            <p style="margin-top: 15px;">Expires in <b>5 minutes</b></p>
            <p style="color: gray; font-size: 12px;">
                If you did not request this, ignore this email.
            </p>
        </div>
    </body>
    </html>
    """
    return _send_email(recipient_email, subject, plain_text, html_content)


def _send_email(recipient_email, subject, plain_text, html_content):
    """Internal helper — actual sending logic"""
    message = MIMEMultipart("alternative")
    message["From"] = SENDER_EMAIL
    message["To"] = recipient_email
    message["Subject"] = subject
    message.attach(MIMEText(plain_text, "plain"))
    message.attach(MIMEText(html_content, "html"))

    context = ssl.create_default_context()
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login(SENDER_EMAIL, SENDER_PASSWORD)
            server.sendmail(SENDER_EMAIL, recipient_email, message.as_string())
        return True
    except Exception as e:
        print("Email error:", e)
        return False