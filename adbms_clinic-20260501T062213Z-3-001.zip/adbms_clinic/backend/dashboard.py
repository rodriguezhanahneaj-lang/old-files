from clinic_db import get_connection
from tkinter import messagebox


def fetch_all(query, params=None, self=None):
    try:
        connection_factory = get_connection

        if self is not None and hasattr(self, "get_db_connection"):
            connection_factory = self.get_db_connection

        conn = connection_factory()
        cursor = conn.cursor(dictionary=True)

        cursor.execute(query, params or ())
        rows = cursor.fetchall()

        cursor.close()
        conn.close()

        return rows

    except Exception as e:
        messagebox.showerror("Database Error", f"Failed to load data:\n{e}")
        return []


def get_dashboard_stats(self=None):
    query = """
        SELECT 
            TodayVisits,
            WaitingPatients,
            PendingForms,
            CompletedCases
        FROM vw_clinic_dashboard
    """

    rows = fetch_all(query, self=self)

    if rows:
        return rows[0]

    return {
        "TodayVisits": 0,
        "WaitingPatients": 0,
        "PendingForms": 0,
        "CompletedCases": 0
    }


def get_checkin_visits_per_month(self=None):
    query = """
        SELECT VisitYear, VisitMonth, MonthName, TotalVisits
        FROM vw_checkin_visits_per_month
    """
    return fetch_all(query, self=self)


def get_stock_counts(self=None):
    query = """
        SELECT ItemID, ItemName, StockQuantity
        FROM vw_stock_counts
    """
    return fetch_all(query, self=self)


def get_common_medical_cause(self=None):
    query = """
        SELECT MedicalCause, TotalCases
        FROM vw_common_medical_cause
    """
    return fetch_all(query, self=self)


def get_year_level_visits(self=None):
    query = """
        SELECT YearLevel, TotalVisits
        FROM vw_year_level_visits
    """
    return fetch_all(query, self=self)


def get_peak_time_per_month(self=None):
    query = """
        SELECT VisitYear, VisitMonth, MonthName, VisitHour, TotalVisits
        FROM vw_peak_time_per_month
    """
    return fetch_all(query, self=self)