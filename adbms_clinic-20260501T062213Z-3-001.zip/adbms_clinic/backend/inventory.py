from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector
import jwt
import random
from datetime import datetime, timedelta
from functools import wraps
import io
import csv
import subprocess
import threading
import os

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = 'your_secret_key_here'

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="clinicmanagement_db",
    autocommit=False
)
cursor = db.cursor(dictionary=True)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'success': False, 'error': 'Token missing'}), 401
        try:
            token = token.replace('Bearer ', '')
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            request.nurse_id = data['nurseId']
        except:
            return jsonify({'success': False, 'error': 'Invalid token'}), 401
        return f(*args, **kwargs)
    return decorated

def generate_control_number():
    cursor.execute("SELECT COUNT(*) as count FROM checkin")
    result = cursor.fetchone()
    count = result['count'] + 1
    return f"ARASOF-NASUGBU-{str(count).zfill(6)}"

def open_ui():
    try:
        subprocess.Popen(["python", "mmm.py"])
        print("UI opened successfully")
    except Exception as e:
        print(f"Failed to open UI: {e}")

@app.route('/api/student/checkin', methods=['POST'])
def student_checkin():
    data = request.json
    sr_code = data.get('srCode')
    name = data.get('name')
    year_level = data.get('yearLevel')
    program = data.get('program')
    
    try:
        cursor.callproc('PatientCheckIn', (sr_code, name, year_level, program, None))
        control_number = None
        for result in cursor.stored_results():
            row = result.fetchone()
            if row and 'ControlNumber' in row:
                control_number = row['ControlNumber']
        db.commit()
        
        return jsonify({
            'success': True,
            'controlNumber': control_number,
            'message': f'Check-in successful. Your control number is: {control_number}'
        })
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/student/purposes', methods=['GET'])
def get_purposes():
    try:
        cursor.execute("SELECT * FROM purpose ORDER BY PurposeName")
        purposes = cursor.fetchall()
        return jsonify({'success': True, 'data': purposes})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/student/submit-form', methods=['POST'])
def submit_student_form():
    data = request.json
    
    try:
        cursor.execute("""
            INSERT INTO Form (
                ControlID, PurposeID, Email, SRCode,
                FirstName, LastName, MiddleName,
                Age, Sex, CivilStatus, Address, Height, Weight
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            data.get('controlId'),
            data.get('purposeId'),
            data.get('email'),
            data.get('srCode'),
            data.get('firstName'),
            data.get('lastName'),
            data.get('middleName'),
            data.get('age'),
            data.get('sex'),
            data.get('civilStatus'),
            data.get('address'),
            data.get('height'),
            data.get('weight')
        ))
        
        form_id = cursor.lastrowid
        db.commit()
        
        return jsonify({
            'success': True,
            'formId': form_id,
            'message': 'Form submitted successfully'
        })
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/student/check-status/<control_number>', methods=['GET'])
def check_medical_status(control_number):
    try:
        cursor.execute("""
            SELECT md.DocumentID, md.Status, dt.DocumentName, md.CreatedAt
            FROM medicaldocument md
            JOIN documenttype dt ON md.DocumentTypeID = dt.DocumentTypeID
            WHERE md.ControlID = %s
        """, (control_number,))
        
        documents = cursor.fetchall()
        return jsonify({'success': True, 'data': documents})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/nurse/signup', methods=['POST'])
def nurse_signup():
    data = request.json
    
    try:
        cursor.execute("""
            INSERT INTO nurse (Email, Username, Password) 
            VALUES (%s, %s, SHA2(%s, 256))
        """, (data['email'], data['username'], data['password']))
        db.commit()
        
        return jsonify({'success': True, 'message': 'Account created. Please login.'})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 400

@app.route('/api/nurse/login', methods=['POST'])
def nurse_login():
    data = request.json
    
    try:
        cursor.execute("""
            SELECT NurseID, Username, Email 
            FROM nurse 
            WHERE Email = %s AND Password = SHA2(%s, 256)
        """, (data['email'], data['password']))
        
        nurse = cursor.fetchone()
        
        if not nurse:
            return jsonify({'success': False, 'error': 'Invalid credentials'}), 401
        
        token = jwt.encode(
            {'nurseId': nurse['NurseID'], 'email': nurse['Email']},
            app.config['SECRET_KEY'],
            algorithm='HS256'
        )
        
        return jsonify({
            'success': True,
            'token': token,
            'nurse': {
                'id': nurse['NurseID'],
                'username': nurse['Username'],
                'email': nurse['Email']
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory', methods=['GET'])
@token_required
def get_inventory():
    try:
        cursor.execute("SELECT * FROM inventory ORDER BY ItemName")
        items = cursor.fetchall()
        return jsonify({'success': True, 'data': items})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/lowest-to-highest', methods=['GET'])
@token_required
def get_inventory_lowest_to_highest():
    try:
        cursor.execute("SELECT * FROM vw_inventory_lowest_to_highest")
        items = cursor.fetchall()
        return jsonify({'success': True, 'data': items})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/highest-to-lowest', methods=['GET'])
@token_required
def get_inventory_highest_to_lowest():
    try:
        cursor.execute("SELECT * FROM vw_inventory_highest_to_lowest")
        items = cursor.fetchall()
        return jsonify({'success': True, 'data': items})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/summary', methods=['GET'])
@token_required
def get_inventory_summary():
    try:
        cursor.execute("SELECT * FROM vw_inventory_summary")
        summary = cursor.fetchone()
        return jsonify({'success': True, 'data': summary})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/by-status', methods=['GET'])
@token_required
def get_inventory_by_status():
    try:
        cursor.execute("SELECT * FROM vw_inventory_by_status")
        items = cursor.fetchall()
        return jsonify({'success': True, 'data': items})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/with-usage', methods=['GET'])
@token_required
def get_inventory_with_usage():
    try:
        cursor.execute("SELECT * FROM vw_inventory_with_usage")
        items = cursor.fetchall()
        return jsonify({'success': True, 'data': items})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/transactions', methods=['GET'])
@token_required
def get_inventory_transactions():
    try:
        cursor.execute("SELECT * FROM vw_inventory_transactions")
        transactions = cursor.fetchall()
        return jsonify({'success': True, 'data': transactions})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/transaction-summary', methods=['GET'])
@token_required
def get_transaction_summary():
    try:
        cursor.execute("SELECT * FROM vw_transaction_summary_by_item")
        summary = cursor.fetchall()
        return jsonify({'success': True, 'data': summary})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/need-reorder', methods=['GET'])
@token_required
def get_items_need_reorder():
    try:
        cursor.execute("SELECT * FROM vw_items_need_reorder")
        items = cursor.fetchall()
        return jsonify({'success': True, 'data': items})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/critical-low-stock', methods=['GET'])
@token_required
def get_critical_low_stock():
    try:
        cursor.execute("SELECT * FROM vw_critical_low_stock")
        items = cursor.fetchall()
        return jsonify({'success': True, 'data': items})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/top-used', methods=['GET'])
@token_required
def get_top_used_items():
    try:
        cursor.execute("SELECT * FROM vw_top_used_items")
        items = cursor.fetchall()
        return jsonify({'success': True, 'data': items})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/complete-report', methods=['GET'])
@token_required
def get_complete_inventory_report():
    try:
        cursor.execute("SELECT * FROM vw_complete_inventory_report")
        report = cursor.fetchall()
        return jsonify({'success': True, 'data': report})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/dashboard-stats', methods=['GET'])
@token_required
def get_inventory_dashboard_stats():
    try:
        cursor.execute("SELECT * FROM vw_dashboard_inventory_stats")
        stats = cursor.fetchone()
        return jsonify({'success': True, 'data': stats})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/recent-transactions', methods=['GET'])
@token_required
def get_recent_transactions():
    try:
        cursor.execute("SELECT * FROM vw_recent_transactions")
        transactions = cursor.fetchall()
        return jsonify({'success': True, 'data': transactions})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory', methods=['POST'])
@token_required
def add_inventory():
    data = request.json
    
    try:
        cursor.execute("""
            INSERT INTO inventory (ItemName, Description, StockQuantity) 
            VALUES (%s, %s, %s)
        """, (data['itemName'], data.get('description'), data['stockQuantity']))
        db.commit()
        
        return jsonify({'success': True, 'message': 'Item added to inventory'})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/<int:item_id>', methods=['PUT'])
@token_required
def update_inventory(item_id):
    data = request.json
    
    try:
        cursor.execute("""
            UPDATE inventory 
            SET ItemName = %s, Description = %s, StockQuantity = %s 
            WHERE ItemID = %s
        """, (data['itemName'], data.get('description'), data['stockQuantity'], item_id))
        db.commit()
        
        return jsonify({'success': True, 'message': 'Item updated'})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/<int:item_id>', methods=['DELETE'])
@token_required
def delete_inventory(item_id):
    try:
        cursor.execute("SELECT COUNT(*) as count FROM inventoryusage WHERE ItemID = %s", (item_id,))
        usage = cursor.fetchone()
        
        if usage['count'] > 0:
            return jsonify({'success': False, 'error': 'Cannot delete item with usage history'}), 400
        
        cursor.execute("DELETE FROM inventory WHERE ItemID = %s", (item_id,))
        db.commit()
        return jsonify({'success': True, 'message': 'Item deleted'})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/use', methods=['POST'])
@token_required
def use_inventory():
    data = request.json
    item_id = data.get('itemId')
    control_id = data.get('controlId')
    quantity = data.get('quantity')
    reason = data.get('reason')
    
    try:
        cursor.callproc('RecordInventoryUsage', (item_id, control_id, quantity, reason))
        db.commit()
        
        return jsonify({'success': True, 'message': 'Inventory usage recorded'})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/export/low-stock', methods=['GET'])
@token_required
def export_low_stock_report():
    try:
        cursor.execute("SELECT * FROM vw_items_need_reorder")
        items = cursor.fetchall()
        
        output = io.StringIO()
        output.write("Item ID,Item Name,Current Stock,Priority Level,Action Required,Recommended Order\n")
        
        for item in items:
            output.write(f"{item['ItemID']},{item['ItemName']},{item['StockQuantity']},{item['PriorityLevel']},{item['ActionRequired']},{item.get('RecommendedOrderQuantity', '')}\n")
        
        response = app.response_class(
            response=output.getvalue(),
            status=200,
            mimetype='text/csv'
        )
        response.headers["Content-Disposition"] = "attachment; filename=low_stock_report.csv"
        return response
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/inventory/export/transactions', methods=['GET'])
@token_required
def export_transactions_report():
    try:
        cursor.execute("SELECT * FROM vw_inventory_transactions")
        transactions = cursor.fetchall()
        
        output = io.StringIO()
        output.write("Transaction ID,Item ID,Item Name,Quantity Used,Reason,Control ID\n")
        
        for trans in transactions:
            output.write(f"{trans['TransactionID']},{trans['ItemID']},{trans['ItemName']},{trans['QuantityUsed']},{trans['Reason']},{trans['ControlID']}\n")
        
        response = app.response_class(
            response=output.getvalue(),
            status=200,
            mimetype='text/csv'
        )
        response.headers["Content-Disposition"] = "attachment; filename=inventory_transactions.csv"
        return response
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/medical-documents/purposes', methods=['GET'])
@token_required
def get_purposes_nurse():
    try:
        cursor.execute("SELECT * FROM purpose ORDER BY PurposeName")
        purposes = cursor.fetchall()
        return jsonify({'success': True, 'data': purposes})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/medical-documents/types', methods=['GET'])
@token_required
def get_document_types():
    try:
        cursor.execute("SELECT * FROM documenttype")
        types = cursor.fetchall()
        return jsonify({'success': True, 'data': types})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/medical-documents/create', methods=['POST'])
@token_required
def create_medical_document():
    data = request.json
    
    try:
        cursor.callproc('ChooseMedicalDocument', (
            data['controlId'],
            data['formId'],
            data['documentTypeId'],
            request.nurse_id,
            None,
            None
        ))
        
        document_id = None
        message = None
        
        for result in cursor.stored_results():
            row = result.fetchone()
            if row:
                document_id = row.get('document_id')
                message = row.get('message')
        
        db.commit()
        
        return jsonify({
            'success': True,
            'documentId': document_id,
            'message': message
        })
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/medical-documents/certificate', methods=['POST'])
@token_required
def add_medical_certificate():
    data = request.json
    
    try:
        cursor.callproc('MedicalCertificateForm', (
            data['documentId'],
            data['diagnosis'],
            data['remarks'],
            data['effectiveDate'],
            data['attendingPhysician'],
            data['licenseNo'],
            None
        ))
        db.commit()
        
        return jsonify({'success': True, 'message': 'Medical certificate added'})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/medical-documents/examination', methods=['POST'])
@token_required
def add_medical_examination():
    data = request.json
    
    try:
        cursor.callproc('MedicalExaminationForm', (
            data['documentId'],
            data.get('cellphoneNo'),
            data.get('birthday'),
            data.get('telNo'),
            data.get('positionProgramCampus'),
            data['effectiveDate'],
            data['attendingPhysician'],
            data['licenseNo'],
            None
        ))
        db.commit()
        
        return jsonify({'success': True, 'message': 'Medical examination added'})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/medical-documents/tracking', methods=['GET'])
@token_required
def get_document_tracking():
    try:
        cursor.execute("SELECT * FROM documenttracking ORDER BY CreatedAt DESC")
        documents = cursor.fetchall()
        return jsonify({'success': True, 'data': documents})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/medical-documents/update-status', methods=['PUT'])
@token_required
def update_document_status():
    data = request.json
    document_id = data.get('documentId')
    status = data.get('status')
    
    try:
        cursor.execute("""
            UPDATE medicaldocument 
            SET Status = %s 
            WHERE DocumentID = %s
        """, (status, document_id))
        db.commit()
        
        return jsonify({'success': True, 'message': f'Document {status}'})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/search/patient', methods=['GET'])
@token_required
def search_patient():
    keyword = request.args.get('keyword', '')
    
    try:
        cursor.callproc('SearchPatient', (keyword,))
        
        results = []
        for result in cursor.stored_results():
            patients = result.fetchall()
            results.extend(patients)
        
        return jsonify({'success': True, 'data': results})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/patient/details/<control_number>', methods=['GET'])
@token_required
def get_patient_details(control_number):
    try:
        cursor.execute("""
            SELECT * FROM patientfulldetails 
            WHERE ControlID = %s
        """, (control_number,))
        
        patient = cursor.fetchone()
        
        if not patient:
            return jsonify({'success': False, 'error': 'Patient not found'}), 404
        
        return jsonify({'success': True, 'data': patient})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/patient/visits/<sr_code>', methods=['GET'])
@token_required
def get_patient_visits(sr_code):
    try:
        cursor.execute("""
            SELECT * FROM patientvisitcount 
            WHERE SRCode = %s
        """, (sr_code,))
        
        visits = cursor.fetchone()
        return jsonify({'success': True, 'data': visits})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/dashboard/stats', methods=['GET'])
@token_required
def get_dashboard_stats():
    try:
        cursor.execute("SELECT COUNT(*) as count FROM checkin WHERE DATE(CheckInDateTime) = CURDATE()")
        today_visits = cursor.fetchone()
        
        cursor.execute("SELECT COUNT(*) as count FROM students")
        total_students = cursor.fetchone()
        
        cursor.execute("SELECT * FROM vw_dashboard_inventory_stats")
        inventory_stats = cursor.fetchone()
        
        cursor.execute("SELECT COUNT(*) as count FROM medicaldocument WHERE Status = 'Pending'")
        pending_docs = cursor.fetchone()
        
        return jsonify({
            'success': True,
            'data': {
                'todayVisits': today_visits['count'] if today_visits else 0,
                'totalStudents': total_students['count'] if total_students else 0,
                'inventory': inventory_stats if inventory_stats else {},
                'pendingDocuments': pending_docs['count'] if pending_docs else 0
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/dashboard/inventory-summary', methods=['GET'])
@token_required
def get_dashboard_inventory():
    try:
        cursor.execute("SELECT * FROM vw_inventory_summary")
        summary = cursor.fetchone()
        
        cursor.execute("SELECT * FROM vw_items_need_reorder LIMIT 5")
        urgent_items = cursor.fetchall()
        
        cursor.execute("SELECT * FROM vw_recent_transactions")
        recent_transactions = cursor.fetchall()
        
        return jsonify({
            'success': True,
            'data': {
                'summary': summary,
                'urgentItems': urgent_items,
                'recentTransactions': recent_transactions
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

def add_inventory_triggers():
    triggers = [
        """
        CREATE TRIGGER IF NOT EXISTS trg_inventory_before_update 
        BEFORE UPDATE ON inventory 
        FOR EACH ROW 
        BEGIN
            IF NEW.StockQuantity < 0 THEN
                SIGNAL SQLSTATE '45000' 
                SET MESSAGE_TEXT = 'Stock quantity cannot be negative';
            END IF;
        END
        """,
        """
        CREATE TRIGGER IF NOT EXISTS trg_inventory_after_update 
        AFTER UPDATE ON inventory 
        FOR EACH ROW 
        BEGIN
            IF OLD.StockQuantity != NEW.StockQuantity THEN
                INSERT INTO inventory_audit (ItemID, OldQuantity, NewQuantity, ChangedBy, ChangeReason)
                VALUES (NEW.ItemID, OLD.StockQuantity, NEW.StockQuantity, USER(), 'Stock updated');
            END IF;
        END
        """,
        """
        CREATE TRIGGER IF NOT EXISTS trg_inventoryusage_before_insert 
        BEFORE INSERT ON inventoryusage 
        FOR EACH ROW 
        BEGIN
            DECLARE current_stock INT;
            SELECT StockQuantity INTO current_stock FROM inventory WHERE ItemID = NEW.ItemID;
            IF current_stock < NEW.QuantityUsed THEN
                SIGNAL SQLSTATE '45000' 
                SET MESSAGE_TEXT = 'Cannot use more than available stock';
            END IF;
        END
        """
    ]
    
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS inventory_audit (
                AuditID INT PRIMARY KEY AUTO_INCREMENT,
                ItemID INT,
                OldQuantity INT,
                NewQuantity INT,
                ChangedBy VARCHAR(100),
                ChangeReason VARCHAR(255),
                ChangedAt DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.commit()
    except:
        pass
    
    for trigger in triggers:
        try:
            cursor.execute(trigger)
            db.commit()
        except:
            pass

try:
    add_inventory_triggers()
    print("Inventory triggers checked/added")
except:
    pass

@app.route('/api/open-ui', methods=['GET'])
def open_ui_endpoint():
    try:
        subprocess.Popen(["python", "mmm.py"])
        return jsonify({'success': True, 'message': 'UI opened successfully'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    print("\n")
    print("="*60)
    print("CLINIC MANAGEMENT SYSTEM BACKEND")
    print("="*60)
    print("\nDatabase: clinicmanagement_db")
    print("Connected to MySQL")
    print("Inventory validation triggers active")
    print("Inventory views ready")
    print("\nServer running on http://localhost:5000")
    print("\nOpening UI...")
    print("="*60)
    
    threading.Timer(2, open_ui).start()
    
    app.run(debug=True, port=5000)