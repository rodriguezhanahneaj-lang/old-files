import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from clinic_db import get_connection

def get_patient_queue():
    """Fetch all checkins using view."""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM vw_patient_queue")
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()


def get_todays_queue():
    """Fetch today's checkins only."""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM vw_todays_queue")
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()


def search_patient_queue(keyword):
    """Search using view."""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        like = f"%{keyword}%"
        cursor.execute("""
            SELECT * FROM vw_patient_queue
            WHERE Name LIKE %s
               OR SRCode LIKE %s
               OR ControlID LIKE %s
        """, (like, like, like))
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()


def update_checkin_status(checkin_id, new_status):
    """Update status — trigger trg_checkin_status_update will auto-log it."""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            UPDATE CheckIn SET Status = %s
            WHERE CheckInID = %s
        """, (new_status, checkin_id))
        conn.commit()
        return True, "Status updated."
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        cursor.close()
        conn.close()