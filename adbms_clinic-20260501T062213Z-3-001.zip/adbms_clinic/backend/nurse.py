from clinic_db import get_connection
import mysql.connector

def nurse_signup(email, username, password, first_name, last_name, emp_id):
    """Returns (success, message)"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        # ✅ Fixed: procedure name + parameter order
        cursor.callproc('NurseSignup', (first_name, last_name, emp_id, email, username, password))
        for r in cursor.stored_results():
            r.fetchall()
        conn.commit()
        return True, "Signup successful."
    except mysql.connector.Error as e:
        return False, e.msg
    finally:
        cursor.close()
        conn.close()


def nurse_login(username, password):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.callproc('NurseLogin', (username, password))
        for r in cursor.stored_results():  # ✅ still needed
            r.fetchall()
        conn.commit()
        return True, "Login successful."
    except mysql.connector.Error as e:
        conn.rollback()
        return False, e.msg
    finally:
        cursor.close()
        conn.close()


def unlock_nurse(username):
    """Call this after 3-min cooldown expires"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        # ✅ Fixed: procedure name
        cursor.callproc('UnlockNurse', (username,))
        for r in cursor.stored_results():
            r.fetchall()
        conn.commit()
    except mysql.connector.Error as e:
        print("Unlock error:", e.msg)
    finally:
        cursor.close()
        conn.close()


def reset_password(email, new_password):
    """Returns (success, message)"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        # ✅ Fixed: procedure name
        cursor.callproc('ResetPassword', (email, new_password))
        for r in cursor.stored_results():
            r.fetchall()
        conn.commit()
        return True, "Password reset successfully."
    except mysql.connector.Error as e:
        return False, e.msg
    finally:
        cursor.close()
        conn.close()