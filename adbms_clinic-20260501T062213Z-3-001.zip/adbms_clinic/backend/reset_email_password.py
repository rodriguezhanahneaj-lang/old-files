import sys
import os
import random
from datetime import datetime, timedelta

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from clinic_db import get_connection
from email_sender import send_reset_otp_email


# TEMPORARY OTP STORAGE (BACKEND ONLY)
otp_store = {}  
# format:
# { email: { "otp": "123456", "expiry": datetime } }


# =========================
# STEP 1: REQUEST OTP
# =========================
def request_password_reset(email):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        cursor.execute(
            "SELECT NurseID FROM Nurse WHERE Email = %s",
            (email,)
        )
        nurse = cursor.fetchone()
    finally:
        cursor.close()
        conn.close()

    if not nurse:
        return False, "No account found with that email."

    # Generate OTP
    otp = str(random.randint(100000, 999999))
    expiry = datetime.now() + timedelta(minutes=5)

    # STORE IN BACKEND ONLY
    otp_store[email] = {
        "otp": otp,
        "expiry": expiry
    }

    # Send email
    sent = send_reset_otp_email(email, otp)
    if not sent:
        return False, "Failed to send email."

    return True, "OTP sent to your email."


# =========================
# STEP 2: CONFIRM OTP
# =========================
# STEP 2: CONFIRM OTP
def confirm_otp(email, entered_otp):
    if email not in otp_store:
        return False, "No OTP request found."

    data = otp_store[email]

    if datetime.now() > data["expiry"]:
        otp_store.pop(email, None)  # ✅ Clean up expired OTP
        return False, "OTP expired."

    if data["otp"] != entered_otp:
        return False, "Invalid OTP."

    # ✅ Mark as verified so change_password knows OTP was confirmed
    otp_store[email]["verified"] = True

    return True, "OTP verified."


# STEP 3: RESET PASSWORD
def change_password(email, new_password, confirm_password):
    # ✅ Gate: must have gone through confirm_otp first
    if email not in otp_store or not otp_store[email].get("verified"):
        return False, "OTP not verified."

    if new_password != confirm_password:
        return False, "Passwords do not match."

    if len(new_password) < 8 or len(new_password) > 16:
        return False, "Password must be 8-16 characters."

    if not any(c.isupper() for c in new_password):
        return False, "Must contain uppercase letter."

    if not any(c.isdigit() for c in new_password):
        return False, "Must contain number."

    if new_password.isalnum():
        return False, "Must contain special character."

    conn = get_connection()
    cursor = conn.cursor()

    try:
        cursor.callproc("ResetPassword", (email, new_password))
        for r in cursor.stored_results():  # ✅ drain results
            r.fetchall()
        conn.commit()
    except Exception as e:
        return False, str(e)
    finally:
        cursor.close()
        conn.close()

    otp_store.pop(email, None)
    return True, "Password reset successful."