-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2026 at 01:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clinicmanagement_db`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddMedicalForm` (IN `p_email` VARCHAR(100), IN `p_sr_code` VARCHAR(50), IN `p_control_no` VARCHAR(50), IN `p_purpose` VARCHAR(100), IN `p_lastname` VARCHAR(50), IN `p_firstname` VARCHAR(50), IN `p_middlename` VARCHAR(50), IN `p_age` INT, IN `p_sex` VARCHAR(10), IN `p_civil_status` VARCHAR(20), IN `p_address` TEXT, IN `p_height` DECIMAL(5,2), IN `p_weight` DECIMAL(5,2))   BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error occurred while saving medical form';
    END;

    -- VALIDATION
    IF p_age <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid age';
    END IF;

    IF p_height <= 0 OR p_weight <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid height or weight';
    END IF;

    START TRANSACTION;

    INSERT INTO MedicalForm (
        Email, SR_Code, ControlNo, Purpose,
        LastName, FirstName, MiddleName,
        Age, Sex, CivilStatus,
        Address, Height, Weight
    )
    VALUES (
        p_email, p_sr_code, p_control_no, p_purpose,
        p_lastname, p_firstname, p_middlename,
        p_age, p_sex, p_civil_status,
        p_address, p_height, p_weight
    );

    -- UPDATE CHECKIN STATUS
    UPDATE CheckIn
    SET Status = 'In Progress'
    WHERE ControlID = p_control_no;

    COMMIT;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ArchiveItem` (IN `item_id` INT)   BEGIN
    UPDATE inventory
    SET IsArchived = TRUE
    WHERE ItemID = item_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `NurseLogin` (IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(255))   BEGIN
    DECLARE v_id INT;
    DECLARE v_pass VARCHAR(255);
    DECLARE v_locked BOOLEAN;
    DECLARE v_attempts INT;
    DECLARE v_verified BOOLEAN;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- FETCH USER
    SELECT NurseID, Password, IsLocked, FailedAttempts, IsVerified
    INTO v_id, v_pass, v_locked, v_attempts, v_verified
    FROM Nurse
    WHERE Username = p_username;

    IF v_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid credentials';
    END IF;

    IF v_locked THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account locked';
    END IF;

    -- PASSWORD CHECK
    IF v_pass <> SHA2(p_password, 256) THEN

        -- Commit failure tracking in its OWN transaction so ROLLBACK won't undo it
        START TRANSACTION;
            UPDATE Nurse
            SET FailedAttempts = FailedAttempts + 1,
                IsLocked = CASE WHEN FailedAttempts + 1 >= 3 THEN TRUE ELSE IsLocked END
            WHERE NurseID = v_id;

            INSERT INTO NurseLoginLog (NurseID, Action)
            VALUES (v_id, 'FAILED LOGIN');

            INSERT INTO AuditLog(Entity, ActionType, Description, ReferenceID, PerformedBy)
            VALUES ('Nurse', 'LOGIN', 'Failed login', v_id, p_username);
        COMMIT;  

        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid credentials';
    END IF;

    IF NOT v_verified THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Account not verified';
    END IF;

    -- SUCCESS
    START TRANSACTION;
        UPDATE Nurse SET FailedAttempts = 0 WHERE NurseID = v_id;

        INSERT INTO NurseLoginLog (NurseID, Action)
        VALUES (v_id, 'LOGIN SUCCESS');

        INSERT INTO AuditLog(Entity, ActionType, Description, ReferenceID, PerformedBy)
        VALUES ('Nurse', 'LOGIN', 'Login successful', v_id, p_username);
    COMMIT;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `NurseSignup` (IN `p_firstname` VARCHAR(50), IN `p_lastname` VARCHAR(50), IN `p_employeeid` VARCHAR(50), IN `p_email` VARCHAR(100), IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(255))   BEGIN
    DECLARE v_exists INT;

    -- HANDLE SQL ERRORS
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Signup failed';
    END;

    START TRANSACTION;

    -- VALIDATE EMAIL
    IF p_email IS NULL OR p_email = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Email is required';
    END IF;

    -- VALIDATE USERNAME
    IF p_username IS NULL OR p_username = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Username is required';
    END IF;

    -- PASSWORD LENGTH CHECK (8-16 chars)
    IF LENGTH(p_password) < 8 OR LENGTH(p_password) > 16 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Password must be 8-16 characters long';
    END IF;

    -- PASSWORD MUST HAVE 1 UPPERCASE LETTER
    IF p_password NOT REGEXP BINARY '[A-Z]' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Password must contain at least 1 uppercase letter';
    END IF;

    -- PASSWORD MUST HAVE 1 NUMBER
    IF p_password NOT REGEXP '[0-9]' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Password must contain at least 1 number';
    END IF;

    -- PASSWORD MUST HAVE 1 SPECIAL CHARACTER
    IF p_password NOT REGEXP '[^A-Za-z0-9]' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Password must contain at least 1 special character';
    END IF;

    -- CHECK DUPLICATE EMAIL
    SELECT COUNT(*) INTO v_exists
    FROM Nurse
    WHERE Email = p_email;

    IF v_exists > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Email already exists';
    END IF;

    -- INSERT NEW NURSE
    INSERT INTO Nurse (
        FirstName, LastName, EmployeeID,
        Email, Username, Password, IsVerified
    )
    VALUES (
        p_firstname, p_lastname, p_employeeid,
        p_email, p_username,
        SHA2(p_password, 256),
        TRUE
    );

    -- AUDIT LOG
    INSERT INTO AuditLog(Entity, ActionType, Description, ReferenceID, PerformedBy)
    VALUES (
        'Nurse',
        'INSERT',
        'New nurse registered',
        LAST_INSERT_ID(),
        p_username
    );

    COMMIT;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `PatientCheckIn` (IN `sr_code` VARCHAR(20), IN `patient_name` VARCHAR(100), IN `year_level` VARCHAR(50), IN `program` VARCHAR(50), OUT `control_id` VARCHAR(30))   BEGIN
    DECLARE patient_id INT;
    DECLARE checkin_id INT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'ERROR: Check-in transaction failed.';
    END;

    START TRANSACTION;

    -- Validate required inputs
    IF sr_code IS NULL OR sr_code = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'SR Code is required.';
    END IF;

    IF patient_name IS NULL OR patient_name = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Patient name is required.';
    END IF;

    -- Check if patient exists
    SELECT PatientID INTO patient_id
    FROM Patient
    WHERE SRCode = sr_code
    LIMIT 1;

    -- Insert or update patient
    IF patient_id IS NULL THEN

        INSERT INTO Patient(SRCode, Name, YearLevel, Program)
        VALUES (sr_code, patient_name, year_level, program);

        SET patient_id = LAST_INSERT_ID();

        INSERT INTO AuditLog(Entity, ActionType, Description, ReferenceID, PerformedBy)
        VALUES ('Patient', 'INSERT',
        CONCAT('New patient created: ', sr_code),
        patient_id, 'SYSTEM');

    ELSE

        UPDATE Patient
        SET Name = patient_name,
            YearLevel = year_level,
            Program = program
        WHERE PatientID = patient_id;

        INSERT INTO AuditLog(Entity, ActionType, Description, ReferenceID, PerformedBy)
        VALUES ('Patient', 'UPDATE',
        CONCAT('Patient updated: ', sr_code),
        patient_id, 'SYSTEM');

    END IF;

    -- Create CheckIn record
    INSERT INTO CheckIn(PatientID)
    VALUES (patient_id);

    SET checkin_id = LAST_INSERT_ID();

    -- Generate Control ID
    SET control_id = CONCAT('AR-NASUGBU-', YEAR(NOW()), '-', LPAD(checkin_id, 5, '0'));

    UPDATE CheckIn
    SET ControlID = control_id
    WHERE CheckInID = checkin_id;

    -- Audit log for check-in
    INSERT INTO AuditLog(Entity, ActionType, Description, ReferenceID, PerformedBy)
    VALUES ('CheckIn', 'INSERT',
    CONCAT('Check-in success: ', control_id),
    checkin_id, 'SYSTEM');

    COMMIT;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RecordInventoryUsage` (IN `item_id` INT, IN `control_id` VARCHAR(22), IN `qty` INT, IN `reason` VARCHAR(255))   BEGIN
    DECLARE current_stock INT;
    DECLARE item_expiry DATE;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Transaction failed while processing inventory usage';
    END;

    START TRANSACTION;

    -- EXPIRY CHECK 
    SELECT ExpiryDate INTO item_expiry
    FROM inventory
    WHERE ItemID = item_id
    FOR UPDATE;

    IF item_expiry IS NOT NULL AND item_expiry < CURDATE() THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot use expired item';
    END IF;

    -- validation
    IF qty <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Quantity must be greater than 0';
    END IF;

    -- stock check
    SELECT StockQuantity INTO current_stock
    FROM inventory
    WHERE ItemID = item_id
    FOR UPDATE;

    IF current_stock IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Item not found';
    END IF;

    IF current_stock < qty THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Not enough stock';
    END IF;

    -- insert usage
    INSERT INTO inventoryusage(ItemID, ControlID, QuantityUsed, Reason)
    VALUES (item_id, control_id, qty, reason);

    -- update stock
    UPDATE inventory
    SET StockQuantity = StockQuantity - qty
    WHERE ItemID = item_id;

    COMMIT;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ResetPassword` (IN `p_email` VARCHAR(100), IN `p_new_password` VARCHAR(255))   BEGIN
    DECLARE v_id INT;

    START TRANSACTION;

    -- CHECK IF USER EXISTS
    SELECT NurseID INTO v_id
    FROM Nurse
    WHERE Email = p_email;

    IF v_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Email not found';
    END IF;

    -- PASSWORD STRENGTH VALIDATION

    IF LENGTH(p_new_password) < 8 OR LENGTH(p_new_password) > 16 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Password must be 8-16 characters long';
    END IF;

    IF p_new_password NOT REGEXP BINARY '[A-Z]' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Password must contain at least 1 uppercase letter';
    END IF;

    IF p_new_password NOT REGEXP '[0-9]' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Password must contain at least 1 number';
    END IF;

    IF p_new_password NOT REGEXP '[^A-Za-z0-9]' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Password must contain at least 1 special character';
    END IF;

    -- UPDATE PASSWORD
    UPDATE Nurse
    SET Password = SHA2(p_new_password, 256),
        FailedAttempts = 0,
        IsLocked = FALSE
    WHERE NurseID = v_id;

    -- AUDIT LOG
    INSERT INTO AuditLog(Entity, ActionType, Description, ReferenceID, PerformedBy)
    VALUES (
        'Nurse',
        'UPDATE',
        'Password reset with strong validation',
        v_id,
        p_email
    );

    COMMIT;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RestoreItem` (IN `item_id` INT)   BEGIN
    UPDATE inventory
    SET IsDeleted = FALSE, IsArchived = FALSE
    WHERE ItemID = item_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SoftDeleteItem` (IN `item_id` INT)   BEGIN
    UPDATE inventory
    SET IsDeleted = TRUE
    WHERE ItemID = item_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `StoreInventory` (IN `item_name` VARCHAR(100), IN `description` VARCHAR(255), IN `stock_quantity` INT)   BEGIN

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Failed to insert inventory item';
    END;

    -- validation
    IF item_name IS NULL OR item_name = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Item name is required';
    END IF;

    IF stock_quantity < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Stock cannot be negative';
    END IF;

    IF EXISTS (
        SELECT 1 FROM inventory WHERE ItemName = item_name
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Item already exists';
    END IF;

    INSERT INTO inventory(ItemName, Description, StockQuantity)
    VALUES (item_name, description, stock_quantity);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UnlockNurse` (IN `p_username` VARCHAR(50))   BEGIN
    START TRANSACTION;

    UPDATE Nurse
    SET IsLocked = FALSE, FailedAttempts = 0
    WHERE Username = p_username;

    IF ROW_COUNT() = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Username not found';
    END IF;

    COMMIT;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `auditlog`
--

CREATE TABLE `auditlog` (
  `LogID` int(11) NOT NULL,
  `Entity` varchar(50) DEFAULT NULL,
  `ActionType` varchar(50) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `ReferenceID` varchar(50) DEFAULT NULL,
  `PerformedBy` varchar(100) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auditlog`
--

INSERT INTO `auditlog` (`LogID`, `Entity`, `ActionType`, `Description`, `ReferenceID`, `PerformedBy`, `CreatedAt`) VALUES
(1, 'Patient', 'INSERT', 'New patient registered: 24-74745', '5', 'SYSTEM', '2026-04-24 17:42:42'),
(2, 'Patient', 'INSERT', 'New patient created: 24-74745', '5', 'SYSTEM', '2026-04-24 17:42:42'),
(3, 'CheckIn', 'INSERT', 'Check-in success: AR-NASUGBU-2026-00001', '1', 'SYSTEM', '2026-04-24 17:42:43'),
(4, 'Nurse', 'INSERT', 'New nurse registered', '1', 'manel', '2026-04-24 17:44:07'),
(5, 'Nurse', 'LOGIN', 'Login successful', '1', 'manel', '2026-04-24 17:44:46'),
(6, 'Nurse', 'INSERT', 'New nurse registered', '2', 'yuki', '2026-04-24 17:56:03'),
(7, 'Nurse', 'INSERT', 'New nurse registered', '3', 'yuki', '2026-04-24 19:32:43'),
(10, 'Nurse', 'UPDATE', 'Password reset with strong validation', '3', 'yuki.kngnm@gmail.com', '2026-04-24 19:34:04'),
(11, 'Nurse', 'UPDATE', 'Password reset with strong validation', '3', 'yuki.kngnm@gmail.com', '2026-04-25 07:35:39'),
(12, 'Nurse', 'INSERT', 'New nurse registered', '4', 'manel', '2026-04-25 09:16:00'),
(13, 'Nurse', 'INSERT', 'New nurse registered', '5', 'manel', '2026-04-25 11:36:04'),
(14, 'Nurse', 'UPDATE', 'Password reset with strong validation', '5', '24-74745@g.batstate-u.edu.ph', '2026-04-26 04:36:21'),
(15, 'Nurse', 'INSERT', 'New nurse registered', '6', 'manel', '2026-04-26 05:20:54'),
(16, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-26 05:21:04'),
(17, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-26 06:45:57'),
(18, 'Patient', 'INSERT', 'New patient registered: 12345', '6', 'SYSTEM', '2026-04-26 06:46:52'),
(19, 'Patient', 'INSERT', 'New patient created: 12345', '6', 'SYSTEM', '2026-04-26 06:46:52'),
(20, 'CheckIn', 'INSERT', 'Check-in success: AR-NASUGBU-2026-00002', '2', 'SYSTEM', '2026-04-26 06:46:52'),
(21, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-26 06:47:44'),
(22, 'Patient', 'UPDATE', 'Patient updated: MARINEL CODIZAL', '24-74745', 'SYSTEM', '2026-04-26 18:15:13'),
(23, 'Patient', 'UPDATE', 'Patient updated: 24-74745', '5', 'SYSTEM', '2026-04-26 18:15:13'),
(24, 'CheckIn', 'INSERT', 'Check-in success: AR-NASUGBU-2026-00003', '3', 'SYSTEM', '2026-04-26 18:15:13'),
(25, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-26 18:16:06'),
(26, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-27 22:13:25'),
(27, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 00:00:08'),
(28, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 00:04:49'),
(29, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 00:06:49'),
(30, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 04:01:18'),
(31, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 04:27:23'),
(32, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 04:29:26'),
(33, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 04:30:12'),
(34, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 04:56:28'),
(35, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 04:58:12'),
(36, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 05:01:35'),
(37, 'Patient', 'INSERT', 'New patient registered: 23456', '7', 'SYSTEM', '2026-04-28 05:06:13'),
(38, 'Patient', 'INSERT', 'New patient created: 23456', '7', 'SYSTEM', '2026-04-28 05:06:13'),
(39, 'CheckIn', 'INSERT', 'Check-in success: AR-NASUGBU-2026-00004', '4', 'SYSTEM', '2026-04-28 05:06:13'),
(40, 'Patient', 'INSERT', 'New patient registered: 09876', '8', 'SYSTEM', '2026-04-28 05:07:08'),
(41, 'Patient', 'INSERT', 'New patient created: 09876', '8', 'SYSTEM', '2026-04-28 05:07:08'),
(42, 'CheckIn', 'INSERT', 'Check-in success: AR-NASUGBU-2026-00005', '5', 'SYSTEM', '2026-04-28 05:07:08'),
(43, 'Patient', 'INSERT', 'New patient registered: 78654', '9', 'SYSTEM', '2026-04-28 05:07:33'),
(44, 'Patient', 'INSERT', 'New patient created: 78654', '9', 'SYSTEM', '2026-04-28 05:07:33'),
(45, 'CheckIn', 'INSERT', 'Check-in success: AR-NASUGBU-2026-00006', '6', 'SYSTEM', '2026-04-28 05:07:33'),
(46, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 05:07:49'),
(47, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 05:23:43'),
(48, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 05:43:42'),
(49, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 06:00:57'),
(50, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 06:06:17'),
(51, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 06:13:46'),
(52, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 06:30:56'),
(53, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 06:36:21'),
(54, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 07:34:39'),
(55, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 07:35:22'),
(56, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 08:11:10'),
(57, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-04-28 08:21:33'),
(58, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-05-01 06:37:54'),
(59, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-05-01 06:46:44'),
(60, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-05-01 06:54:45'),
(61, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-05-01 07:02:45'),
(62, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-05-01 07:09:44'),
(63, 'Patient', 'UPDATE', 'Patient updated: YUKI', '12345', 'SYSTEM', '2026-05-01 07:10:32'),
(64, 'Patient', 'UPDATE', 'Patient updated: 12345', '6', 'SYSTEM', '2026-05-01 07:10:32'),
(65, 'CheckIn', 'INSERT', 'Check-in success: AR-NASUGBU-2026-00007', '7', 'SYSTEM', '2026-05-01 07:10:32'),
(66, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-05-01 07:11:22'),
(67, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-05-01 07:20:54'),
(68, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-05-01 07:23:51'),
(69, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-05-01 07:34:01'),
(70, 'Nurse', 'LOGIN', 'Login successful', '6', 'manel', '2026-05-01 07:35:07');

-- --------------------------------------------------------

--
-- Table structure for table `checkin`
--

CREATE TABLE `checkin` (
  `CheckInID` int(11) NOT NULL,
  `ControlID` varchar(30) DEFAULT NULL,
  `PatientID` int(11) NOT NULL,
  `CheckInDateTime` datetime DEFAULT current_timestamp(),
  `Status` varchar(20) DEFAULT 'Waiting'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `checkin`
--

INSERT INTO `checkin` (`CheckInID`, `ControlID`, `PatientID`, `CheckInDateTime`, `Status`) VALUES
(1, 'AR-NASUGBU-2026-00001', 5, '2026-04-24 17:42:42', 'Completed'),
(2, 'AR-NASUGBU-2026-00002', 6, '2026-04-26 06:46:52', 'Completed'),
(3, 'AR-NASUGBU-2026-00003', 5, '2026-04-26 18:15:13', 'Completed'),
(4, 'AR-NASUGBU-2026-00004', 7, '2026-04-28 05:06:13', 'Completed'),
(5, 'AR-NASUGBU-2026-00005', 8, '2026-04-28 05:07:08', 'Completed'),
(6, 'AR-NASUGBU-2026-00006', 9, '2026-04-28 05:07:33', 'Waiting'),
(7, 'AR-NASUGBU-2026-00007', 6, '2026-05-01 07:10:32', 'Completed');

--
-- Triggers `checkin`
--
DELIMITER $$
CREATE TRIGGER `trg_checkin_history` AFTER INSERT ON `checkin` FOR EACH ROW BEGIN
    INSERT INTO CheckInHistory (
        CheckInID,
        PatientID,
        Status,
        Action
    )
    VALUES (
        NEW.CheckInID,
        NEW.PatientID,
        NEW.Status,
        'CHECK-IN CREATED'
    );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_checkin_status_update` AFTER UPDATE ON `checkin` FOR EACH ROW BEGIN
    IF OLD.Status <> NEW.Status THEN
        INSERT INTO CheckInHistory (
            CheckInID,
            PatientID,
            Status,
            Action
        )
        VALUES (
            NEW.CheckInID,
            NEW.PatientID,
            NEW.Status,
            CONCAT('STATUS CHANGED: ', OLD.Status, ' → ', NEW.Status)
        );
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `checkinhistory`
--

CREATE TABLE `checkinhistory` (
  `HistoryID` int(11) NOT NULL,
  `CheckInID` int(11) DEFAULT NULL,
  `PatientID` int(11) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `CheckInDate` datetime DEFAULT current_timestamp(),
  `Action` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `checkinhistory`
--

INSERT INTO `checkinhistory` (`HistoryID`, `CheckInID`, `PatientID`, `Status`, `CheckInDate`, `Action`) VALUES
(1, 1, 5, 'Waiting', '2026-04-24 17:42:42', 'CHECK-IN CREATED'),
(2, 2, 6, 'Waiting', '2026-04-26 06:46:52', 'CHECK-IN CREATED'),
(3, 3, 5, 'Waiting', '2026-04-26 18:15:13', 'CHECK-IN CREATED'),
(4, 4, 7, 'Waiting', '2026-04-28 05:06:13', 'CHECK-IN CREATED'),
(5, 5, 8, 'Waiting', '2026-04-28 05:07:08', 'CHECK-IN CREATED'),
(6, 6, 9, 'Waiting', '2026-04-28 05:07:33', 'CHECK-IN CREATED'),
(7, 1, 5, 'Completed', '2026-04-28 06:14:00', 'STATUS CHANGED: Waiting → Completed'),
(8, 1, 5, 'Completed', '2026-04-28 06:14:00', 'Status updated to Completed'),
(9, 5, 8, 'Completed', '2026-04-28 06:14:11', 'STATUS CHANGED: Waiting → Completed'),
(10, 5, 8, 'Completed', '2026-04-28 06:14:11', 'Status updated to Completed'),
(11, 3, 5, 'Completed', '2026-04-28 08:16:41', 'STATUS CHANGED: Waiting → Completed'),
(12, 3, 5, 'Completed', '2026-04-28 08:16:41', 'Status updated to Completed'),
(13, 4, 7, 'Completed', '2026-05-01 06:38:29', 'STATUS CHANGED: Waiting → Completed'),
(14, 4, 7, 'Completed', '2026-05-01 06:38:29', 'Status updated to Completed'),
(15, 2, 6, 'Completed', '2026-05-01 07:10:04', 'STATUS CHANGED: Waiting → Completed'),
(16, 2, 6, 'Completed', '2026-05-01 07:10:04', 'Status updated to Completed'),
(17, 7, 6, 'Waiting', '2026-05-01 07:10:32', 'CHECK-IN CREATED'),
(18, 7, 6, 'Completed', '2026-05-01 07:11:30', 'STATUS CHANGED: Waiting → Completed'),
(19, 7, 6, 'Completed', '2026-05-01 07:11:30', 'Status updated to Completed');

-- --------------------------------------------------------

--
-- Table structure for table `documenttype`
--

CREATE TABLE `documenttype` (
  `DocumentTypeID` int(11) NOT NULL,
  `DocumentName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `documenttype`
--

INSERT INTO `documenttype` (`DocumentTypeID`, `DocumentName`) VALUES
(1, 'MedicalDocument'),
(2, 'MedicalExaminationForm');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `ItemID` int(11) NOT NULL,
  `ItemName` varchar(100) NOT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `StockQuantity` int(11) DEFAULT 0,
  `ExpiryDate` date DEFAULT NULL,
  `IsDeleted` tinyint(1) DEFAULT 0,
  `IsArchived` tinyint(1) DEFAULT 0,
  `UpdatedAt` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `inventory`
--
DELIMITER $$
CREATE TRIGGER `trg_inventory_after_update` AFTER UPDATE ON `inventory` FOR EACH ROW BEGIN
    IF OLD.StockQuantity != NEW.StockQuantity THEN
        INSERT INTO inventory_audit (
    ItemID, OldQuantity, NewQuantity, ChangedBy, ChangeReason, ActionType
)
VALUES (
    NEW.ItemID,
    OLD.StockQuantity,
    NEW.StockQuantity,
    USER(),
    'Stock updated',
    'UPDATE'
);
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_inventory_auditlog` AFTER UPDATE ON `inventory` FOR EACH ROW BEGIN
    IF OLD.StockQuantity <> NEW.StockQuantity THEN
        INSERT INTO AuditLog(Entity, ActionType, Description, ReferenceID, PerformedBy)
        VALUES (
            'Inventory',
            'UPDATE',
            CONCAT(
                'Stock changed from ',
                OLD.StockQuantity,
                ' to ',
                NEW.StockQuantity,
                ' for item: ',
                NEW.ItemName
            ),
            NEW.ItemID,
            USER()
        );
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_inventory_before_update` BEFORE UPDATE ON `inventory` FOR EACH ROW BEGIN
    IF NEW.StockQuantity < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Stock quantity cannot be negative';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_inventory_low_stock_alert` AFTER UPDATE ON `inventory` FOR EACH ROW BEGIN
    IF NEW.StockQuantity < 10 AND OLD.StockQuantity >= 10 THEN
        INSERT INTO low_stock_alerts (ItemID, AlertType, AlertMessage)
        VALUES (NEW.ItemID, 'LOW_STOCK', CONCAT('Item ', NEW.ItemName, ' has low stock: ', NEW.StockQuantity, ' units remaining'));
    END IF;

    IF NEW.StockQuantity = 0 AND OLD.StockQuantity > 0 THEN
        INSERT INTO low_stock_alerts (ItemID, AlertType, AlertMessage)
        VALUES (NEW.ItemID, 'OUT_OF_STOCK', CONCAT('Item ', NEW.ItemName, ' is now OUT OF STOCK'));
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `inventoryusage`
--

CREATE TABLE `inventoryusage` (
  `UsageID` int(11) NOT NULL,
  `ItemID` int(11) DEFAULT NULL,
  `ControlID` varchar(30) DEFAULT NULL,
  `QuantityUsed` int(11) DEFAULT NULL CHECK (`QuantityUsed` > 0),
  `Reason` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `inventoryusage`
--
DELIMITER $$
CREATE TRIGGER `trg_inventoryusage_before_insert` BEFORE INSERT ON `inventoryusage` FOR EACH ROW BEGIN
    DECLARE current_stock INT;

    SELECT StockQuantity INTO current_stock
    FROM inventory
    WHERE ItemID = NEW.ItemID;

    IF current_stock < NEW.QuantityUsed THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot use more than available stock';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_audit`
--

CREATE TABLE `inventory_audit` (
  `AuditID` int(11) NOT NULL,
  `ItemID` int(11) DEFAULT NULL,
  `OldQuantity` int(11) DEFAULT NULL,
  `NewQuantity` int(11) DEFAULT NULL,
  `ChangedBy` varchar(100) DEFAULT NULL,
  `ChangeReason` varchar(255) DEFAULT NULL,
  `ActionType` varchar(50) DEFAULT NULL,
  `ChangedAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_monthly_snapshots`
--

CREATE TABLE `inventory_monthly_snapshots` (
  `SnapshotID` int(11) NOT NULL,
  `SnapshotDate` date DEFAULT NULL,
  `TotalProducts` int(11) DEFAULT NULL,
  `TotalStock` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_notifications`
--

CREATE TABLE `inventory_notifications` (
  `NotificationID` int(11) NOT NULL,
  `Message` text DEFAULT NULL,
  `IsRead` tinyint(1) DEFAULT 0,
  `CreatedAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `low_stock_alerts`
--

CREATE TABLE `low_stock_alerts` (
  `AlertID` int(11) NOT NULL,
  `ItemID` int(11) DEFAULT NULL,
  `AlertType` enum('LOW_STOCK','OUT_OF_STOCK') DEFAULT NULL,
  `AlertMessage` varchar(255) DEFAULT NULL,
  `IsResolved` tinyint(1) DEFAULT 0,
  `CreatedAt` datetime DEFAULT current_timestamp(),
  `ResolvedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medicalauditlog`
--

CREATE TABLE `medicalauditlog` (
  `AuditID` int(11) NOT NULL,
  `MedicalFormID` int(11) DEFAULT NULL,
  `Action` varchar(50) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `CreatedAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medicalcertificate`
--

CREATE TABLE `medicalcertificate` (
  `Template1ID` int(11) NOT NULL,
  `DocumentID` int(11) DEFAULT NULL,
  `Date` date DEFAULT curdate(),
  `Diagnosis` varchar(255) NOT NULL,
  `Remarks` varchar(255) NOT NULL,
  `EffectiveDate` date DEFAULT NULL,
  `AttendingPhysician` varchar(100) DEFAULT NULL,
  `LicenseNo` varchar(50) DEFAULT NULL,
  `Signature` longblob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medicaldocument`
--

CREATE TABLE `medicaldocument` (
  `DocumentID` int(11) NOT NULL,
  `ControlID` varchar(30) DEFAULT NULL,
  `FormID` int(11) DEFAULT NULL,
  `DocumentTypeID` int(11) DEFAULT NULL,
  `CreatedBy` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT current_timestamp(),
  `Status` enum('Pending','Approved','Rejected') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medicalexamination`
--

CREATE TABLE `medicalexamination` (
  `Template2ID` int(11) NOT NULL,
  `DocumentID` int(11) DEFAULT NULL,
  `Date` date DEFAULT curdate(),
  `CellphoneNo` varchar(15) DEFAULT NULL,
  `Birthday` date DEFAULT NULL,
  `TelNo` varchar(15) DEFAULT NULL,
  `PositionProgramCampus` varchar(50) DEFAULT NULL,
  `EffectiveDate` date DEFAULT NULL,
  `AttendingPhysician` varchar(100) DEFAULT NULL,
  `LicenseNo` varchar(50) DEFAULT NULL,
  `Signature` longblob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medicalform`
--

CREATE TABLE `medicalform` (
  `MedicalFormID` int(11) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `SR_Code` varchar(50) NOT NULL,
  `ControlNo` varchar(50) NOT NULL,
  `Purpose` enum('OJT Medical','Pre-employment','Annual Physical Examination (APE)','Local-off Campus Activity','International Travel / Exchange Student Program','Scholarship Application','Return to Work','Sports Participation','ROTC','UCCL','BUSCAA Season 27') NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `MiddleName` varchar(50) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Sex` enum('Male','Female','Other') DEFAULT NULL,
  `CivilStatus` enum('Single','Married','Widowed','Separated') DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `Height` decimal(5,2) DEFAULT NULL,
  `Weight` decimal(5,2) DEFAULT NULL,
  `DateCreated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `medicalform`
--
DELIMITER $$
CREATE TRIGGER `trg_medical_form_audit` AFTER INSERT ON `medicalform` FOR EACH ROW BEGIN
    INSERT INTO MedicalAuditLog (
        MedicalFormID,
        Action,
        Description
    )
    VALUES (
        NEW.MedicalFormID,
        'INSERT',
        CONCAT('Form submitted for ControlNo: ', NEW.ControlNo)
    );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_update_checkin_status` AFTER INSERT ON `medicalform` FOR EACH ROW BEGIN
    UPDATE CheckIn
    SET Status = 'In Progress'
    WHERE ControlID = NEW.ControlNo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `nurse`
--

CREATE TABLE `nurse` (
  `NurseID` int(11) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `EmployeeID` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `CreatedAt` datetime DEFAULT current_timestamp(),
  `FailedAttempts` int(11) DEFAULT 0,
  `IsLocked` tinyint(1) DEFAULT 0,
  `IsVerified` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nurse`
--

INSERT INTO `nurse` (`NurseID`, `FirstName`, `LastName`, `EmployeeID`, `Email`, `Username`, `Password`, `CreatedAt`, `FailedAttempts`, `IsLocked`, `IsVerified`) VALUES
(6, 'MARINEL', 'CODIZAL', '24-74745', '24-74745@g.batstate-u.edu.ph', 'manel', '0201e4b102a049f6b39cfe272c5f117c76c61736288e1d5eb088632812e07a2f', '2026-04-26 05:20:54', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nurseloginlog`
--

CREATE TABLE `nurseloginlog` (
  `LogID` int(11) NOT NULL,
  `NurseID` int(11) DEFAULT NULL,
  `LoginTime` datetime DEFAULT current_timestamp(),
  `Action` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nurseloginlog`
--

INSERT INTO `nurseloginlog` (`LogID`, `NurseID`, `LoginTime`, `Action`) VALUES
(4, 6, '2026-04-26 05:21:04', 'LOGIN SUCCESS'),
(5, 6, '2026-04-26 06:45:57', 'LOGIN SUCCESS'),
(6, 6, '2026-04-26 06:47:44', 'LOGIN SUCCESS'),
(7, 6, '2026-04-26 18:16:06', 'LOGIN SUCCESS'),
(8, 6, '2026-04-27 22:13:25', 'LOGIN SUCCESS'),
(9, 6, '2026-04-28 00:00:08', 'LOGIN SUCCESS'),
(10, 6, '2026-04-28 00:04:49', 'LOGIN SUCCESS'),
(11, 6, '2026-04-28 00:06:49', 'LOGIN SUCCESS'),
(12, 6, '2026-04-28 04:01:18', 'LOGIN SUCCESS'),
(13, 6, '2026-04-28 04:27:23', 'LOGIN SUCCESS'),
(14, 6, '2026-04-28 04:29:26', 'LOGIN SUCCESS'),
(15, 6, '2026-04-28 04:30:12', 'LOGIN SUCCESS'),
(16, 6, '2026-04-28 04:56:28', 'LOGIN SUCCESS'),
(17, 6, '2026-04-28 04:58:12', 'LOGIN SUCCESS'),
(18, 6, '2026-04-28 05:01:35', 'LOGIN SUCCESS'),
(19, 6, '2026-04-28 05:07:49', 'LOGIN SUCCESS'),
(20, 6, '2026-04-28 05:23:43', 'LOGIN SUCCESS'),
(21, 6, '2026-04-28 05:43:42', 'LOGIN SUCCESS'),
(22, 6, '2026-04-28 06:00:57', 'LOGIN SUCCESS'),
(23, 6, '2026-04-28 06:06:17', 'LOGIN SUCCESS'),
(24, 6, '2026-04-28 06:13:46', 'LOGIN SUCCESS'),
(25, 6, '2026-04-28 06:30:56', 'LOGIN SUCCESS'),
(26, 6, '2026-04-28 06:36:21', 'LOGIN SUCCESS'),
(27, 6, '2026-04-28 07:34:39', 'LOGIN SUCCESS'),
(28, 6, '2026-04-28 07:35:22', 'LOGIN SUCCESS'),
(29, 6, '2026-04-28 08:11:10', 'LOGIN SUCCESS'),
(30, 6, '2026-04-28 08:21:33', 'LOGIN SUCCESS'),
(31, 6, '2026-05-01 06:37:54', 'LOGIN SUCCESS'),
(32, 6, '2026-05-01 06:46:44', 'LOGIN SUCCESS'),
(33, 6, '2026-05-01 06:54:45', 'LOGIN SUCCESS'),
(34, 6, '2026-05-01 07:02:45', 'LOGIN SUCCESS'),
(35, 6, '2026-05-01 07:09:44', 'LOGIN SUCCESS'),
(36, 6, '2026-05-01 07:11:22', 'LOGIN SUCCESS'),
(37, 6, '2026-05-01 07:20:54', 'LOGIN SUCCESS'),
(38, 6, '2026-05-01 07:23:51', 'LOGIN SUCCESS'),
(39, 6, '2026-05-01 07:34:01', 'LOGIN SUCCESS'),
(40, 6, '2026-05-01 07:35:07', 'LOGIN SUCCESS');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `PatientID` int(11) NOT NULL,
  `SRCode` varchar(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `YearLevel` varchar(50) NOT NULL,
  `Program` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`PatientID`, `SRCode`, `Name`, `YearLevel`, `Program`) VALUES
(5, '24-74745', 'MARINEL CODIZAL', '2nd Year', 'BSIT'),
(6, '12345', 'YUKI', '1st Year', 'BSIT'),
(7, '23456', 'ALLIAH RENZON', '1st Year', 'BSCS'),
(8, '09876', 'LEON KENNEDY', '4th Year', 'BSEMC'),
(9, '78654', 'ADA WONG', '3rd Year', 'BSEMC');

--
-- Triggers `patient`
--
DELIMITER $$
CREATE TRIGGER `trg_patient_insert` AFTER INSERT ON `patient` FOR EACH ROW BEGIN
    INSERT INTO AuditLog(Entity, ActionType, Description, ReferenceID, PerformedBy)
    VALUES (
        'Patient',
        'INSERT',
        CONCAT('New patient registered: ', NEW.SRCode),
        NEW.PatientID,
        'SYSTEM'
    );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_patient_update` AFTER UPDATE ON `patient` FOR EACH ROW BEGIN
    INSERT INTO AuditLog(Entity, ActionType, Description, ReferenceID, PerformedBy)
    VALUES (
        'Patient',
        'UPDATE',
        CONCAT('Patient updated: ', NEW.Name),
        NEW.SRCode,
        'SYSTEM'
    );
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_checkin_visits_per_month`
-- (See below for the actual view)
--
CREATE TABLE `vw_checkin_visits_per_month` (
`VisitYear` int(4)
,`VisitMonth` int(2)
,`MonthName` varchar(64)
,`TotalVisits` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_clinic_dashboard`
-- (See below for the actual view)
--
CREATE TABLE `vw_clinic_dashboard` (
`TodayVisits` bigint(21)
,`WaitingPatients` bigint(21)
,`PendingForms` bigint(21)
,`CompletedCases` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_common_medical_cause`
-- (See below for the actual view)
--
CREATE TABLE `vw_common_medical_cause` (
`MedicalCause` varchar(255)
,`TotalCases` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_expiry_critical_items`
-- (See below for the actual view)
--
CREATE TABLE `vw_expiry_critical_items` (
`ItemID` int(11)
,`ItemName` varchar(100)
,`StockQuantity` int(11)
,`ExpiryDate` date
,`ExpiryStatus` varchar(13)
,`StockStatus` varchar(12)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_inventory_base`
-- (See below for the actual view)
--
CREATE TABLE `vw_inventory_base` (
`ItemID` int(11)
,`ItemName` varchar(100)
,`Description` varchar(255)
,`StockQuantity` int(11)
,`ExpiryDate` date
,`StockStatus` varchar(12)
,`ExpiryStatus` varchar(13)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_inventory_transactions`
-- (See below for the actual view)
--
CREATE TABLE `vw_inventory_transactions` (
`TransactionID` int(11)
,`ItemID` int(11)
,`ItemName` varchar(100)
,`QuantityUsed` int(11)
,`Reason` varchar(255)
,`ControlID` varchar(30)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_inventory_with_usage`
-- (See below for the actual view)
--
CREATE TABLE `vw_inventory_with_usage` (
`ItemID` int(11)
,`ItemName` varchar(100)
,`Description` varchar(255)
,`CurrentStock` int(11)
,`TotalUsed` decimal(32,0)
,`TimesUsed` bigint(21)
,`UsageLevel` varchar(12)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_low_items`
-- (See below for the actual view)
--
CREATE TABLE `vw_low_items` (
`ItemID` int(11)
,`ItemName` varchar(100)
,`StockQuantity` int(11)
,`StockStatus` varchar(12)
,`PriorityLevel` int(1)
,`NotificationMessage` varchar(40)
,`RecommendedOrderQuantity` int(2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_medical_full_record`
-- (See below for the actual view)
--
CREATE TABLE `vw_medical_full_record` (
`MedicalFormID` int(11)
,`Name` varchar(100)
,`ControlNo` varchar(50)
,`Purpose` enum('OJT Medical','Pre-employment','Annual Physical Examination (APE)','Local-off Campus Activity','International Travel / Exchange Student Program','Scholarship Application','Return to Work','Sports Participation','ROTC','UCCL','BUSCAA Season 27')
,`Status` varchar(20)
,`DateCreated` timestamp
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_peak_time_per_month`
-- (See below for the actual view)
--
CREATE TABLE `vw_peak_time_per_month` (
`VisitYear` int(4)
,`VisitMonth` int(2)
,`MonthName` varchar(64)
,`VisitHour` int(2)
,`TotalVisits` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_stock_counts`
-- (See below for the actual view)
--
CREATE TABLE `vw_stock_counts` (
`ItemID` int(11)
,`ItemName` varchar(100)
,`StockQuantity` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_student_records`
-- (See below for the actual view)
--
CREATE TABLE `vw_student_records` (
`SRCode` varchar(20)
,`FullName` varchar(100)
,`Year` varchar(50)
,`Program` varchar(50)
,`CheckInCounts` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_year_level_visits`
-- (See below for the actual view)
--
CREATE TABLE `vw_year_level_visits` (
`YearLevel` varchar(50)
,`TotalVisits` bigint(21)
);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auditlog`
--
ALTER TABLE `auditlog`
  ADD PRIMARY KEY (`LogID`);

--
-- Indexes for table `checkin`
--
ALTER TABLE `checkin`
  ADD PRIMARY KEY (`CheckInID`),
  ADD UNIQUE KEY `ControlID` (`ControlID`),
  ADD KEY `PatientID` (`PatientID`);

--
-- Indexes for table `checkinhistory`
--
ALTER TABLE `checkinhistory`
  ADD PRIMARY KEY (`HistoryID`);

--
-- Indexes for table `documenttype`
--
ALTER TABLE `documenttype`
  ADD PRIMARY KEY (`DocumentTypeID`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`ItemID`);

--
-- Indexes for table `inventoryusage`
--
ALTER TABLE `inventoryusage`
  ADD PRIMARY KEY (`UsageID`),
  ADD KEY `ItemID` (`ItemID`);

--
-- Indexes for table `inventory_audit`
--
ALTER TABLE `inventory_audit`
  ADD PRIMARY KEY (`AuditID`),
  ADD KEY `ItemID` (`ItemID`);

--
-- Indexes for table `inventory_monthly_snapshots`
--
ALTER TABLE `inventory_monthly_snapshots`
  ADD PRIMARY KEY (`SnapshotID`);

--
-- Indexes for table `inventory_notifications`
--
ALTER TABLE `inventory_notifications`
  ADD PRIMARY KEY (`NotificationID`);

--
-- Indexes for table `low_stock_alerts`
--
ALTER TABLE `low_stock_alerts`
  ADD PRIMARY KEY (`AlertID`),
  ADD KEY `ItemID` (`ItemID`);

--
-- Indexes for table `medicalauditlog`
--
ALTER TABLE `medicalauditlog`
  ADD PRIMARY KEY (`AuditID`);

--
-- Indexes for table `medicalcertificate`
--
ALTER TABLE `medicalcertificate`
  ADD PRIMARY KEY (`Template1ID`),
  ADD KEY `DocumentID` (`DocumentID`);

--
-- Indexes for table `medicaldocument`
--
ALTER TABLE `medicaldocument`
  ADD PRIMARY KEY (`DocumentID`),
  ADD KEY `ControlID` (`ControlID`),
  ADD KEY `FormID` (`FormID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `DocumentTypeID` (`DocumentTypeID`);

--
-- Indexes for table `medicalexamination`
--
ALTER TABLE `medicalexamination`
  ADD PRIMARY KEY (`Template2ID`),
  ADD KEY `DocumentID` (`DocumentID`);

--
-- Indexes for table `medicalform`
--
ALTER TABLE `medicalform`
  ADD PRIMARY KEY (`MedicalFormID`),
  ADD UNIQUE KEY `ControlNo` (`ControlNo`),
  ADD KEY `SR_Code` (`SR_Code`);

--
-- Indexes for table `nurse`
--
ALTER TABLE `nurse`
  ADD PRIMARY KEY (`NurseID`),
  ADD UNIQUE KEY `EmployeeID` (`EmployeeID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Indexes for table `nurseloginlog`
--
ALTER TABLE `nurseloginlog`
  ADD PRIMARY KEY (`LogID`),
  ADD KEY `NurseID` (`NurseID`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`PatientID`),
  ADD UNIQUE KEY `SRCode` (`SRCode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auditlog`
--
ALTER TABLE `auditlog`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `checkin`
--
ALTER TABLE `checkin`
  MODIFY `CheckInID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `checkinhistory`
--
ALTER TABLE `checkinhistory`
  MODIFY `HistoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `documenttype`
--
ALTER TABLE `documenttype`
  MODIFY `DocumentTypeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `ItemID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventoryusage`
--
ALTER TABLE `inventoryusage`
  MODIFY `UsageID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory_audit`
--
ALTER TABLE `inventory_audit`
  MODIFY `AuditID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory_monthly_snapshots`
--
ALTER TABLE `inventory_monthly_snapshots`
  MODIFY `SnapshotID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory_notifications`
--
ALTER TABLE `inventory_notifications`
  MODIFY `NotificationID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `low_stock_alerts`
--
ALTER TABLE `low_stock_alerts`
  MODIFY `AlertID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicalauditlog`
--
ALTER TABLE `medicalauditlog`
  MODIFY `AuditID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicalcertificate`
--
ALTER TABLE `medicalcertificate`
  MODIFY `Template1ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicaldocument`
--
ALTER TABLE `medicaldocument`
  MODIFY `DocumentID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicalexamination`
--
ALTER TABLE `medicalexamination`
  MODIFY `Template2ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicalform`
--
ALTER TABLE `medicalform`
  MODIFY `MedicalFormID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nurse`
--
ALTER TABLE `nurse`
  MODIFY `NurseID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `nurseloginlog`
--
ALTER TABLE `nurseloginlog`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `PatientID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

-- --------------------------------------------------------

--
-- Structure for view `vw_checkin_visits_per_month`
--
DROP TABLE IF EXISTS `vw_checkin_visits_per_month`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_checkin_visits_per_month`  AS SELECT year(`checkin`.`CheckInDateTime`) AS `VisitYear`, month(`checkin`.`CheckInDateTime`) AS `VisitMonth`, date_format(`checkin`.`CheckInDateTime`,'%M') AS `MonthName`, count(0) AS `TotalVisits` FROM `checkin` GROUP BY year(`checkin`.`CheckInDateTime`), month(`checkin`.`CheckInDateTime`), date_format(`checkin`.`CheckInDateTime`,'%M') ORDER BY year(`checkin`.`CheckInDateTime`) ASC, month(`checkin`.`CheckInDateTime`) ASC ;

-- --------------------------------------------------------

--
-- Structure for view `vw_clinic_dashboard`
--
DROP TABLE IF EXISTS `vw_clinic_dashboard`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_clinic_dashboard`  AS SELECT (select count(0) from `checkin` where cast(`checkin`.`CheckInDateTime` as date) = curdate()) AS `TodayVisits`, (select count(0) from `checkin` where `checkin`.`Status` = 'Waiting') AS `WaitingPatients`, (select count(0) from (`medicalform` `mf` left join `medicaldocument` `md` on(`mf`.`MedicalFormID` = `md`.`FormID`)) where `md`.`FormID` is null) AS `PendingForms`, (select count(0) from `checkin` where `checkin`.`Status` = 'Completed') AS `CompletedCases` ;

-- --------------------------------------------------------

--
-- Structure for view `vw_common_medical_cause`
--
DROP TABLE IF EXISTS `vw_common_medical_cause`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_common_medical_cause`  AS SELECT `inventoryusage`.`Reason` AS `MedicalCause`, count(0) AS `TotalCases` FROM `inventoryusage` WHERE `inventoryusage`.`Reason` is not null AND `inventoryusage`.`Reason` <> '' GROUP BY `inventoryusage`.`Reason` ORDER BY count(0) DESC ;

-- --------------------------------------------------------

--
-- Structure for view `vw_expiry_critical_items`
--
DROP TABLE IF EXISTS `vw_expiry_critical_items`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_expiry_critical_items`  AS SELECT `vw_inventory_base`.`ItemID` AS `ItemID`, `vw_inventory_base`.`ItemName` AS `ItemName`, `vw_inventory_base`.`StockQuantity` AS `StockQuantity`, `vw_inventory_base`.`ExpiryDate` AS `ExpiryDate`, `vw_inventory_base`.`ExpiryStatus` AS `ExpiryStatus`, `vw_inventory_base`.`StockStatus` AS `StockStatus` FROM `vw_inventory_base` WHERE `vw_inventory_base`.`ExpiryStatus` in ('EXPIRED','EXPIRING SOON') ;

-- --------------------------------------------------------

--
-- Structure for view `vw_inventory_base`
--
DROP TABLE IF EXISTS `vw_inventory_base`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_inventory_base`  AS SELECT `inventory`.`ItemID` AS `ItemID`, `inventory`.`ItemName` AS `ItemName`, `inventory`.`Description` AS `Description`, `inventory`.`StockQuantity` AS `StockQuantity`, `inventory`.`ExpiryDate` AS `ExpiryDate`, CASE WHEN `inventory`.`StockQuantity` = 0 THEN 'OUT OF STOCK' WHEN `inventory`.`StockQuantity` < 5 THEN 'CRITICAL LOW' WHEN `inventory`.`StockQuantity` < 10 THEN 'LOW STOCK' WHEN `inventory`.`StockQuantity` < 20 THEN 'RUNNING LOW' ELSE 'SUFFICIENT' END AS `StockStatus`, CASE WHEN `inventory`.`ExpiryDate` is null THEN 'NO EXPIRY' WHEN `inventory`.`ExpiryDate` < curdate() THEN 'EXPIRED' WHEN `inventory`.`ExpiryDate` <= curdate() + interval 30 day THEN 'EXPIRING SOON' ELSE 'VALID' END AS `ExpiryStatus` FROM `inventory` WHERE `inventory`.`IsDeleted` = 0 AND `inventory`.`IsArchived` = 0 ;

-- --------------------------------------------------------

--
-- Structure for view `vw_inventory_transactions`
--
DROP TABLE IF EXISTS `vw_inventory_transactions`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_inventory_transactions`  AS SELECT `iu`.`UsageID` AS `TransactionID`, `iu`.`ItemID` AS `ItemID`, `i`.`ItemName` AS `ItemName`, `iu`.`QuantityUsed` AS `QuantityUsed`, `iu`.`Reason` AS `Reason`, `iu`.`ControlID` AS `ControlID` FROM (`inventoryusage` `iu` join `inventory` `i` on(`iu`.`ItemID` = `i`.`ItemID`)) ORDER BY `iu`.`UsageID` DESC ;

-- --------------------------------------------------------

--
-- Structure for view `vw_inventory_with_usage`
--
DROP TABLE IF EXISTS `vw_inventory_with_usage`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_inventory_with_usage`  AS SELECT `i`.`ItemID` AS `ItemID`, `i`.`ItemName` AS `ItemName`, `i`.`Description` AS `Description`, `i`.`StockQuantity` AS `CurrentStock`, coalesce(sum(`iu`.`QuantityUsed`),0) AS `TotalUsed`, coalesce(count(`iu`.`UsageID`),0) AS `TimesUsed`, CASE WHEN coalesce(sum(`iu`.`QuantityUsed`),0) = 0 THEN 'Never Used' WHEN coalesce(sum(`iu`.`QuantityUsed`),0) < 10 THEN 'Low Usage' WHEN coalesce(sum(`iu`.`QuantityUsed`),0) < 50 THEN 'Medium Usage' ELSE 'High Usage' END AS `UsageLevel` FROM (`inventory` `i` left join `inventoryusage` `iu` on(`i`.`ItemID` = `iu`.`ItemID`)) GROUP BY `i`.`ItemID`, `i`.`ItemName`, `i`.`Description`, `i`.`StockQuantity` ;

-- --------------------------------------------------------

--
-- Structure for view `vw_low_items`
--
DROP TABLE IF EXISTS `vw_low_items`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_low_items`  AS SELECT `vw_inventory_base`.`ItemID` AS `ItemID`, `vw_inventory_base`.`ItemName` AS `ItemName`, `vw_inventory_base`.`StockQuantity` AS `StockQuantity`, `vw_inventory_base`.`StockStatus` AS `StockStatus`, CASE WHEN `vw_inventory_base`.`StockQuantity` = 0 THEN 1 WHEN `vw_inventory_base`.`StockQuantity` < 5 THEN 2 WHEN `vw_inventory_base`.`StockQuantity` < 10 THEN 3 ELSE 4 END AS `PriorityLevel`, CASE WHEN `vw_inventory_base`.`StockQuantity` = 0 THEN 'OUT OF STOCK: Immediate restock required' WHEN `vw_inventory_base`.`StockQuantity` < 5 THEN 'CRITICAL LOW: Order immediately' WHEN `vw_inventory_base`.`StockQuantity` < 10 THEN 'LOW STOCK: Schedule restock' END AS `NotificationMessage`, CASE WHEN `vw_inventory_base`.`StockQuantity` = 0 THEN 20 WHEN `vw_inventory_base`.`StockQuantity` < 5 THEN 15 WHEN `vw_inventory_base`.`StockQuantity` < 10 THEN 10 ELSE 0 END AS `RecommendedOrderQuantity` FROM `vw_inventory_base` WHERE `vw_inventory_base`.`StockQuantity` <= 9 ;

-- --------------------------------------------------------

--
-- Structure for view `vw_medical_full_record`
--
DROP TABLE IF EXISTS `vw_medical_full_record`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_medical_full_record`  AS SELECT `mf`.`MedicalFormID` AS `MedicalFormID`, `p`.`Name` AS `Name`, `mf`.`ControlNo` AS `ControlNo`, `mf`.`Purpose` AS `Purpose`, `ci`.`Status` AS `Status`, `mf`.`DateCreated` AS `DateCreated` FROM ((`medicalform` `mf` join `patient` `p` on(`mf`.`SR_Code` = `p`.`SRCode`)) join `checkin` `ci` on(`mf`.`ControlNo` = `ci`.`ControlID`)) ;

-- --------------------------------------------------------

--
-- Structure for view `vw_peak_time_per_month`
--
DROP TABLE IF EXISTS `vw_peak_time_per_month`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_peak_time_per_month`  AS SELECT year(`checkin`.`CheckInDateTime`) AS `VisitYear`, month(`checkin`.`CheckInDateTime`) AS `VisitMonth`, date_format(`checkin`.`CheckInDateTime`,'%M') AS `MonthName`, hour(`checkin`.`CheckInDateTime`) AS `VisitHour`, count(0) AS `TotalVisits` FROM `checkin` GROUP BY year(`checkin`.`CheckInDateTime`), month(`checkin`.`CheckInDateTime`), date_format(`checkin`.`CheckInDateTime`,'%M'), hour(`checkin`.`CheckInDateTime`) ORDER BY year(`checkin`.`CheckInDateTime`) ASC, month(`checkin`.`CheckInDateTime`) ASC, hour(`checkin`.`CheckInDateTime`) ASC ;

-- --------------------------------------------------------

--
-- Structure for view `vw_stock_counts`
--
DROP TABLE IF EXISTS `vw_stock_counts`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_stock_counts`  AS SELECT `inventory`.`ItemID` AS `ItemID`, `inventory`.`ItemName` AS `ItemName`, `inventory`.`StockQuantity` AS `StockQuantity` FROM `inventory` WHERE `inventory`.`IsDeleted` = 0 AND `inventory`.`IsArchived` = 0 ORDER BY `inventory`.`StockQuantity` ASC ;

-- --------------------------------------------------------

--
-- Structure for view `vw_student_records`
--
DROP TABLE IF EXISTS `vw_student_records`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_student_records`  AS SELECT `p`.`SRCode` AS `SRCode`, `p`.`Name` AS `FullName`, `p`.`YearLevel` AS `Year`, `p`.`Program` AS `Program`, count(`ci`.`CheckInID`) AS `CheckInCounts` FROM (`patient` `p` left join `checkin` `ci` on(`p`.`PatientID` = `ci`.`PatientID`)) GROUP BY `p`.`SRCode`, `p`.`Name`, `p`.`YearLevel`, `p`.`Program` ;

-- --------------------------------------------------------

--
-- Structure for view `vw_year_level_visits`
--
DROP TABLE IF EXISTS `vw_year_level_visits`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_year_level_visits`  AS SELECT `p`.`YearLevel` AS `YearLevel`, count(`c`.`CheckInID`) AS `TotalVisits` FROM (`checkin` `c` join `patient` `p` on(`c`.`PatientID` = `p`.`PatientID`)) GROUP BY `p`.`YearLevel` ORDER BY count(`c`.`CheckInID`) DESC ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `checkin`
--
ALTER TABLE `checkin`
  ADD CONSTRAINT `checkin_ibfk_1` FOREIGN KEY (`PatientID`) REFERENCES `patient` (`PatientID`);

--
-- Constraints for table `inventoryusage`
--
ALTER TABLE `inventoryusage`
  ADD CONSTRAINT `inventoryusage_ibfk_1` FOREIGN KEY (`ItemID`) REFERENCES `inventory` (`ItemID`);

--
-- Constraints for table `inventory_audit`
--
ALTER TABLE `inventory_audit`
  ADD CONSTRAINT `inventory_audit_ibfk_1` FOREIGN KEY (`ItemID`) REFERENCES `inventory` (`ItemID`);

--
-- Constraints for table `low_stock_alerts`
--
ALTER TABLE `low_stock_alerts`
  ADD CONSTRAINT `low_stock_alerts_ibfk_1` FOREIGN KEY (`ItemID`) REFERENCES `inventory` (`ItemID`);

--
-- Constraints for table `medicalcertificate`
--
ALTER TABLE `medicalcertificate`
  ADD CONSTRAINT `medicalcertificate_ibfk_1` FOREIGN KEY (`DocumentID`) REFERENCES `medicaldocument` (`DocumentID`);

--
-- Constraints for table `medicaldocument`
--
ALTER TABLE `medicaldocument`
  ADD CONSTRAINT `medicaldocument_ibfk_1` FOREIGN KEY (`ControlID`) REFERENCES `checkin` (`ControlID`),
  ADD CONSTRAINT `medicaldocument_ibfk_2` FOREIGN KEY (`FormID`) REFERENCES `medicalform` (`MedicalFormID`),
  ADD CONSTRAINT `medicaldocument_ibfk_3` FOREIGN KEY (`CreatedBy`) REFERENCES `nurse` (`NurseID`),
  ADD CONSTRAINT `medicaldocument_ibfk_4` FOREIGN KEY (`DocumentTypeID`) REFERENCES `documenttype` (`DocumentTypeID`);

--
-- Constraints for table `medicalexamination`
--
ALTER TABLE `medicalexamination`
  ADD CONSTRAINT `medicalexamination_ibfk_1` FOREIGN KEY (`DocumentID`) REFERENCES `medicaldocument` (`DocumentID`);

--
-- Constraints for table `medicalform`
--
ALTER TABLE `medicalform`
  ADD CONSTRAINT `medicalform_ibfk_1` FOREIGN KEY (`SR_Code`) REFERENCES `patient` (`SRCode`),
  ADD CONSTRAINT `medicalform_ibfk_2` FOREIGN KEY (`ControlNo`) REFERENCES `checkin` (`ControlID`);

--
-- Constraints for table `nurseloginlog`
--
ALTER TABLE `nurseloginlog`
  ADD CONSTRAINT `nurseloginlog_ibfk_1` FOREIGN KEY (`NurseID`) REFERENCES `nurse` (`NurseID`);

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `reset_old_checkins` ON SCHEDULE EVERY 1 DAY STARTS '2026-04-25 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    UPDATE CheckIn
    SET Status = 'Completed'
    WHERE Status = 'Waiting'
      AND DATE(CheckInDateTime) < CURDATE();
END$$

CREATE DEFINER=`root`@`localhost` EVENT `clear_expired_otp` ON SCHEDULE EVERY 1 HOUR STARTS '2026-04-24 16:08:51' ON COMPLETION NOT PRESERVE ENABLE DO UPDATE Nurse
SET OTP = NULL, OTPExpiry = NULL
WHERE OTPExpiry < NOW()$$

CREATE DEFINER=`root`@`localhost` EVENT `ev_auto_complete_checkin` ON SCHEDULE EVERY 1 DAY STARTS '2026-04-24 16:49:52' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    UPDATE CheckIn
    SET Status = 'Completed'
    WHERE Status = 'In Progress'
    AND CheckInDate < DATE_SUB(NOW(), INTERVAL 2 DAY);
END$$

CREATE DEFINER=`root`@`localhost` EVENT `auto_resolve_low_stock_alerts` ON SCHEDULE EVERY 1 DAY STARTS '2026-04-24 14:40:06' ON COMPLETION NOT PRESERVE ENABLE DO UPDATE low_stock_alerts 
  SET IsResolved = 1, ResolvedAt = NOW()
  WHERE IsResolved = 0 
    AND CreatedAt < DATE_SUB(NOW(), INTERVAL 7 DAY)$$

CREATE DEFINER=`root`@`localhost` EVENT `auto_clean_audit_logs` ON SCHEDULE EVERY 1 WEEK STARTS '2026-04-24 14:40:16' ON COMPLETION NOT PRESERVE ENABLE DO DELETE FROM inventory_audit 
  WHERE ChangedAt < DATE_SUB(NOW(), INTERVAL 30 DAY)$$

CREATE DEFINER=`root`@`localhost` EVENT `auto_monthly_inventory_report` ON SCHEDULE EVERY 1 MONTH STARTS '2026-05-01 01:00:00' ON COMPLETION NOT PRESERVE ENABLE DO INSERT INTO inventory_monthly_snapshots (SnapshotDate, TotalProducts, TotalStock)
  SELECT CURDATE(), COUNT(*), SUM(StockQuantity) FROM inventory$$

CREATE DEFINER=`root`@`localhost` EVENT `auto_low_stock_notification` ON SCHEDULE EVERY 1 DAY STARTS '2026-04-24 14:40:38' ON COMPLETION NOT PRESERVE ENABLE DO INSERT INTO inventory_notifications (Message, CreatedAt)
  SELECT CONCAT('Low stock alert: ', ItemName, ' only has ', StockQuantity, ' units left'), NOW()
  FROM inventory
  WHERE StockQuantity < 10
  AND NOT EXISTS (
SELECT 1 FROM inventory_notifications
WHERE Message LIKE CONCAT('%', ItemName, '%')
AND CreatedAt >= DATE_SUB(NOW(), INTERVAL 1 DAY)
)$$

CREATE DEFINER=`root`@`localhost` EVENT `auto_expiry_notification` ON SCHEDULE EVERY 1 DAY STARTS '2026-04-24 14:40:50' ON COMPLETION NOT PRESERVE ENABLE DO INSERT INTO inventory_notifications (Message, CreatedAt)
SELECT 
    CONCAT(
        'Expiry Alert: ', ItemName, 
        ' expires on ', ExpiryDate
    ),
    NOW()
FROM inventory
WHERE ExpiryDate IS NOT NULL
AND ExpiryDate <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)

AND NOT EXISTS (
    SELECT 1 FROM inventory_notifications
    WHERE Message LIKE CONCAT('%', ItemName, '%')
    AND CreatedAt >= DATE_SUB(NOW(), INTERVAL 1 DAY)
)$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
